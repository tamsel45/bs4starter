import React, { useState } from 'react';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Dropdown } from 'primereact/dropdown';
import { Calendar } from 'primereact/calendar';
import './OnboardingDialog.css';

const dropdownOptions = {
  btgName: ['BTG1', 'BTG2', 'BTG3', 'BTG4'],
  team: ['Development Team', 'QA Team', 'DevOps Team', 'UI/UX Team'],
  managerName: ['John Smith', 'Sarah Johnson', 'Mike Wilson', 'Emily Davis'],
  hiringType: ['Permanent', 'Contract', 'Intern'],
  hiringEntity: ['EY', 'Wipro', 'TCS'],
  location: ['Bangalore', 'Chennai', 'Hyderabad', 'Mumbai', 'Pune'],
  onboardingStatus: ['Active', 'On-Hold', 'Onboarding', 'Completed'],
  currentBand: ['Band 1', 'Band 2', 'Band 3', 'Band 4'],
  targetBand: ['Band 1', 'Band 2', 'Band 3', 'Band 4'],
  gbsTypeOfHiring: ['Type 1', 'Type 2', 'Type 3'],
  resOnboardingWave: ['Wave 1', 'Wave 2'],
  resOnboardingCluster: ['Cluster A', 'Cluster B', 'Cluster C'],
  onboardingStatus1: ['Active', 'On-Hold', 'Pending'],
  role: ['Developer', 'Tester', 'Business Analyst', 'Project Manager'],
};

const fields = [
  { name: 'resourceName', label: 'Resource Name', type: 'input', required: true, tooltip: 'Full name of the resource' },
  { name: 'skillset', label: 'Skillset', type: 'textarea', required: true, tooltip: 'Technical skills and expertise' },
  { name: 'btgName', label: 'BTG Name', type: 'dropdown', required: true, tooltip: 'Business Technology Group assignment' },
  { name: 'wmp', label: 'WMP', type: 'input', required: true, tooltip: 'Workforce Management Program identifier' },
  { name: 'workdayId', label: 'Workday ID', type: 'input', required: true, tooltip: 'Unique Workday system identifier' },
  { name: 'team', label: 'Team', type: 'dropdown', required: true, tooltip: 'Assigned team for the resource' },
  { name: 'managerName', label: 'Manager Name', type: 'dropdown', required: true, tooltip: 'Direct reporting manager' },
  { name: 'hiringType', label: 'Hiring Type', type: 'dropdown', required: true, tooltip: 'Employment type classification' },
  { name: 'hiringEntity', label: 'Hiring Entity', type: 'dropdown', required: true, tooltip: 'Organization handling the hiring' },
  { name: 'location', label: 'Location', type: 'dropdown', required: true, tooltip: 'Work location assignment' },
  { name: 'onboardingStatus', label: 'Onboarding Status', type: 'dropdown', required: true, tooltip: 'Current onboarding progress status' },
  { name: 'currentBand', label: 'Current Band', type: 'dropdown', required: true, tooltip: 'Current job band level' },
  { name: 'targetBand', label: 'Target Band', type: 'dropdown', required: true, tooltip: 'Target job band level' },
  { name: 'gbsTypeOfHiring', label: 'GBS Type of Hiring', type: 'dropdown', required: true, tooltip: 'Global Business Services hiring classification' },
  { name: 'previousManagerName', label: 'Previous Manager Name', type: 'input', required: false, tooltip: 'Name of previous manager (if applicable)' },
  { name: 'resOnboardingWave', label: 'RES Onboarding Wave', type: 'dropdown', required: true, tooltip: 'Resource onboarding wave assignment' },
  { name: 'resOnboardingCluster', label: 'RES Onboarding Cluster', type: 'dropdown', required: true, tooltip: 'Resource onboarding cluster assignment' },
  { name: 'assignedBuddy', label: 'Assigned Buddy', type: 'input', required: false, tooltip: 'Onboarding buddy assigned to resource' },
  { name: 'assignedBuddyEmail', label: 'Assigned Buddy Email-ID', type: 'input', required: false, tooltip: 'Contact email for assigned buddy' },
  { name: 'rbkIs', label: 'RBK-IS', type: 'input', required: false, tooltip: 'RBK Information System identifier' },
  { name: 'ibNumber', label: 'IB Number', type: 'input', required: false, tooltip: 'Internal business number' },
  { name: 'resourceEmail', label: 'Resource Email ID', type: 'input', required: true, tooltip: 'Official email address of resource' },
  { name: 'applicantWorkstationDetails', label: 'Applicant Workstation Details', type: 'input', required: false, tooltip: 'Workstation setup information' },
  { name: 'previousManagerEmail', label: 'Previous Manager Email-Id', type: 'input', required: false, tooltip: 'Contact email for previous manager' },
  { name: 'offBoardDate', label: 'Off-Board Date', type: 'calendar', required: false, tooltip: 'Expected or actual off-boarding date' },
  { name: 'onboardingStatusText', label: 'Onboarding Status Notes', type: 'input', required: false, tooltip: 'Additional status notes' },
  { name: 'onboardingStatus1', label: 'Secondary Onboarding Status', type: 'dropdown', required: false, tooltip: 'Secondary status classification' },
  { name: 'updatedExpectedDOJ', label: 'Updated Expected DOJ', type: 'calendar', required: false, tooltip: 'Revised date of joining' },
  { name: 'role', label: 'Role', type: 'dropdown', required: true, tooltip: 'Job role assignment' },
  { name: 'comments', label: 'Comments', type: 'input', required: false, tooltip: 'Additional comments or notes' },
  { name: 'mobileNumber', label: 'Mobile Number', type: 'input', required: false, tooltip: 'Contact mobile number' },
  { name: 'expectedDOJ', label: 'Expected DOJ', type: 'calendar', required: false, tooltip: 'Expected date of joining' },
  { name: 'actualDOJ', label: 'Actual DOJ', type: 'calendar', required: false, tooltip: 'Actual date of joining' },
  { name: 'resBillingDetails', label: 'RES Billing Details Date', type: 'calendar', required: false, tooltip: 'Billing details completion date' },
];

function OnboardingDialog({ visible, onHide, onSubmit }) {
  const [form, setForm] = useState({});
  const [errors, setErrors] = useState({});

  const handleChange = (name, value) => {
    setForm(prev => ({ ...prev, [name]: value }));
    setErrors(prev => ({ ...prev, [name]: false }));
  };

  const validate = () => {
    const newErrors = {};
    fields.forEach(f => {
      if (f.required && !form[f.name]) {
        newErrors[f.name] = true;
      }
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) {
      onSubmit(form, 'EYRegular');
      setForm({});
      setErrors({});
    }
  };

  const handleCancel = () => {
    setForm({});
    setErrors({});
    onHide();
  };

  const renderField = (field) => {
    const commonProps = {
      id: field.name,
      className: errors[field.name] ? 'p-invalid' : '',
      'aria-required': field.required
    };

    switch (field.type) {
      case 'input':
        return (
          <InputText
            {...commonProps}
            value={form[field.name] || ''}
            onChange={e => handleChange(field.name, e.target.value)}
            placeholder={`Enter ${field.label}`}
          />
        );
      case 'textarea':
        return (
          <InputTextarea
            {...commonProps}
            value={form[field.name] || ''}
            onChange={e => handleChange(field.name, e.target.value)}
            placeholder={`Enter ${field.label}`}
            rows={3}
          />
        );
      case 'dropdown':
        return (
          <Dropdown
            {...commonProps}
            value={form[field.name] || null}
            options={dropdownOptions[field.name]?.map(opt => ({ label: opt, value: opt })) || []}
            onChange={e => handleChange(field.name, e.value)}
            placeholder={`Select ${field.label}`}
            filter
            showClear
          />
        );
      case 'calendar':
        return (
          <Calendar
            {...commonProps}
            value={form[field.name] || null}
            onChange={e => handleChange(field.name, e.value)}
            showIcon
            placeholder={`Select ${field.label}`}
            dateFormat="dd/mm/yy"
          />
        );
      default:
        return null;
    }
  };

  const footer = (
    <div className="dialog-footer">
      <Button 
        label="Submit" 
        icon="pi pi-check" 
        className="p-button-success submit-btn" 
        onClick={handleSubmit}
        loading={false}
      />
      <Button 
        label="Cancel" 
        icon="pi pi-times" 
        className="p-button-secondary cancel-btn" 
        onClick={handleCancel} 
      />
    </div>
  );

  return (
    <Dialog 
      header={
        <div className="dialog-header-custom">
          <i className="pi pi-users dialog-header-icon"></i>
          <span>Team Onboarding Tracker</span>
        </div>
      }
      visible={visible} 
      style={{ width: '80vw', maxWidth: '1200px' }} 
      onHide={handleCancel} 
      footer={footer} 
      modal
      className="onboarding-dialog"
      maximizable
    >
      <div className="dialog-content">
        <div className="form-section">
          <h4 className="section-title">
            <i className="pi pi-user"></i>
            Basic Information
          </h4>
          <div className="form-grid">
            {fields.slice(0, 8).map(field => (
              <div key={field.name} className="form-field">
                <label htmlFor={field.name} className={field.required ? 'required' : ''}>
                  {field.label}
                  <i className="pi pi-info-circle help-icon" title={field.tooltip}></i>
                </label>
                {renderField(field)}
                {errors[field.name] && <small className="p-error">{field.label} is required.</small>}
              </div>
            ))}
          </div>
        </div>

        <div className="form-section">
          <h4 className="section-title">
            <i className="pi pi-briefcase"></i>
            Employment Details
          </h4>
          <div className="form-grid">
            {fields.slice(8, 16).map(field => (
              <div key={field.name} className="form-field">
                <label htmlFor={field.name} className={field.required ? 'required' : ''}>
                  {field.label}
                  <i className="pi pi-info-circle help-icon" title={field.tooltip}></i>
                </label>
                {renderField(field)}
                {errors[field.name] && <small className="p-error">{field.label} is required.</small>}
              </div>
            ))}
          </div>
        </div>

        <div className="form-section">
          <h4 className="section-title">
            <i className="pi pi-cog"></i>
            Additional Information
          </h4>
          <div className="form-grid">
            {fields.slice(16).map(field => (
              <div key={field.name} className="form-field">
                <label htmlFor={field.name} className={field.required ? 'required' : ''}>
                  {field.label}
                  <i className="pi pi-info-circle help-icon" title={field.tooltip}></i>
                </label>
                {renderField(field)}
                {errors[field.name] && <small className="p-error">{field.label} is required.</small>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </Dialog>
  );
}

export default OnboardingDialog;
