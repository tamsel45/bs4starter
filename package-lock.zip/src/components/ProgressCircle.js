import React, { useState, useRef, useEffect } from 'react';
import { Button } from 'primereact/button';
import { ProgressBar } from 'primereact/progressbar';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, DoughnutController } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend, DoughnutController);

function ProgressCircle() {
  const [selectedWave, setSelectedWave] = useState(1);
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  const wave1Data = {
    onboarded: 45,
    target: 60,
    remaining: 15,
    percentage: 75
  };

  const wave2Data = {
    onboarded: 32,
    target: 50,
    remaining: 18,
    percentage: 64
  };

  const progressData = selectedWave === 1 ? wave1Data : wave2Data;

  useEffect(() => {
    if (chartRef.current) {
      const ctx = chartRef.current.getContext('2d');
      
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }

      chartInstance.current = new ChartJS(ctx, {
        type: 'doughnut',
        data: {
          datasets: [{
            data: [progressData.percentage, 100 - progressData.percentage],
            backgroundColor: [
              '#556ee6',
              '#e9ecef'
            ],
            borderWidth: 0,
            cutout: '75%'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: { enabled: false }
          }
        }
      });
    }

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [selectedWave, progressData.percentage]);

  return (
    <div className="chart-card">
      <div className="card-header">
        <h3>Onboarding Progress</h3>
        <div className="wave-selector">
          <Button
            label="Wave 1"
            className={`p-button-sm ${selectedWave === 1 ? 'p-button-raised' : 'p-button-outlined'}`}
            onClick={() => setSelectedWave(1)}
            style={{ 
              fontSize: '0.75rem', 
              padding: '0.375rem 0.75rem',
              backgroundColor: selectedWave === 1 ? '#556ee6' : 'transparent',
              borderColor: '#556ee6',
              color: selectedWave === 1 ? '#fff' : '#556ee6'
            }}
          />
          <Button
            label="Wave 2"
            className={`p-button-sm ${selectedWave === 2 ? 'p-button-raised' : 'p-button-outlined'}`}
            onClick={() => setSelectedWave(2)}
            style={{ 
              fontSize: '0.75rem', 
              padding: '0.375rem 0.75rem',
              backgroundColor: selectedWave === 2 ? '#556ee6' : 'transparent',
              borderColor: '#556ee6',
              color: selectedWave === 2 ? '#fff' : '#556ee6'
            }}
          />
        </div>
      </div>
      
      <div style={{ padding: '1.5rem' }}>
        <div className="progress-content">
          <div className="chart-container">
            <canvas ref={chartRef} width="300" height="300"></canvas>
            <div className="chart-overlay">
              <div className="progress-center">
                <span className="progress-value">{progressData.percentage}%</span>
                <span className="progress-label">Completed</span>
              </div>
            </div>
          </div>
          
          <div className="progress-stats">
            <div className="stat-card onboarded">
              <div className="stat-icon">
                <i className="pi pi-check-circle"></i>
              </div>
              <div className="stat-content">
                <h4>Onboarded</h4>
                <div className="stat-value">{progressData.onboarded}</div>
                <ProgressBar value={(progressData.onboarded / progressData.target) * 100} className="stat-progress" />
              </div>
            </div>
            
            <div className="stat-card target">
              <div className="stat-icon">
                <i className="pi pi-flag"></i>
              </div>
              <div className="stat-content">
                <h4>Target</h4>
                <div className="stat-value">{progressData.target}</div>
                <ProgressBar value={100} className="stat-progress target-progress" />
              </div>
            </div>
            
            <div className="stat-card remaining">
              <div className="stat-icon">
                <i className="pi pi-clock"></i>
              </div>
              <div className="stat-content">
                <h4>Remaining</h4>
                <div className="stat-value">{progressData.remaining}</div>
                <ProgressBar value={(progressData.remaining / progressData.target) * 100} className="stat-progress remaining-progress" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProgressCircle;
