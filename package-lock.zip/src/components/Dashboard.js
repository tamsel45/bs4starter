import React, { useState } from 'react';
import ProgressCircle from './ProgressCircle';
import MetricsCards from './MetricsCards';
import ResourceTables from './ResourceTables';
import OnboardingDialog from './OnboardingDialog';
import './Dashboard.css';
import { Button } from 'primereact/button';
import { Card } from 'primereact/card';
import { Divider } from 'primereact/divider';
import { Avatar } from 'primereact/avatar';
import { Badge } from 'primereact/badge';

function Dashboard() {
  const [dialogVisible, setDialogVisible] = useState(false);
  const [activeSection, setActiveSection] = useState('dashboard');
  const [tableData, setTableData] = useState({
    EYRegular: [],
    EYAdditional: [],
    WiproRegular: []
  });

  const navigationItems = [
    {
      label: 'Dashboard',
      icon: 'pi pi-home',
      section: 'dashboard',
      active: true
    },
    {
      label: 'Resources',
      icon: 'pi pi-users',
      section: 'resources'
    },
    {
      label: 'Progress',
      icon: 'pi pi-chart-line',
      section: 'progress'
    },
    {
      label: 'Reports',
      icon: 'pi pi-chart-bar',
      section: 'reports'
    },
    {
      label: 'Analytics',
      icon: 'pi pi-sitemap',
      section: 'analytics'
    },
    {
      label: 'Settings',
      icon: 'pi pi-cog',
      section: 'settings'
    }
  ];

  const handleDialogSubmit = (data, tableType) => {
    setTableData(prev => ({
      ...prev,
      [tableType]: [...prev[tableType], data]
    }));
    setDialogVisible(false);
  };

  return (
    <div className="modern-layout">
      {/* Top Navigation Header */}
      <header className="top-navbar">
        <div className="navbar-content">
          <div className="navbar-left">
            <div className="brand">
              <div className="brand-icon">
                <i className="pi pi-chart-pie"></i>
              </div>
              <div className="brand-text">
                <h2>Resource Tracker</h2>
                <span>Onboarding Management</span>
              </div>
            </div>
            
            <nav className="main-navigation">
              {navigationItems.map((item, index) => (
                <button
                  key={index}
                  className={`nav-item ${activeSection === item.section ? 'active' : ''}`}
                  onClick={() => setActiveSection(item.section)}
                >
                  <i className={item.icon}></i>
                  <span>{item.label}</span>
                </button>
              ))}
            </nav>
          </div>
          
          <div className="navbar-right">
            <Button
              label="Add Resource"
              icon="pi pi-plus"
              className="add-resource-btn"
              onClick={() => setDialogVisible(true)}
              size="small"
            />
            
            <div className="user-profile">
              <Badge value="3" className="notification-badge">
                <i className="pi pi-bell notification-icon"></i>
              </Badge>
              <div className="user-info">
                <span className="user-name">Admin User</span>
                <span className="user-role">System Administrator</span>
              </div>
              <div className="user-avatar">
                <i className="pi pi-user"></i>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="main-content">
        <div className="page-content">
          <div className="page-header">
            <h1 className="page-title">
              {navigationItems.find(item => item.section === activeSection)?.label || 'Dashboard'}
            </h1>
            <p className="page-subtitle">
              {activeSection === 'dashboard' && 'Monitor onboarding progress and key metrics'}
              {activeSection === 'resources' && 'Manage team resources and assignments'}
              {activeSection === 'progress' && 'Track onboarding wave progress'}
              {activeSection === 'reports' && 'Generate comprehensive reports'}
              {activeSection === 'analytics' && 'Analyze trends and performance data'}
              {activeSection === 'settings' && 'Configure application preferences'}
            </p>
          </div>

          {activeSection === 'dashboard' && (
            <div className="dashboard-grid">
              {/* Stats Cards Row */}
              <div className="stats-row">
                <MetricsCards />
              </div>
              
              {/* Charts and Progress Row */}
              <div className="charts-row">
                <Card className="chart-card">
                  <div className="card-header">
                    <h3>Onboarding Progress Overview</h3>
                    <div className="card-actions">
                      <Button 
                        icon="pi pi-ellipsis-v" 
                        className="p-button-text p-button-sm"
                      />
                    </div>
                  </div>
                  <ProgressCircle />
                </Card>
                
                <Card className="activity-card">
                  <div className="card-header">
                    <h3>Recent Activities</h3>
                  </div>
                  <div className="activity-list">
                    <div className="activity-item">
                      <div className="activity-icon success">
                        <i className="pi pi-check"></i>
                      </div>
                      <div className="activity-content">
                        <h4>John Smith onboarded successfully</h4>
                        <p>Completed Wave 1 requirements</p>
                        <span className="activity-time">2 hours ago</span>
                      </div>
                    </div>
                    <div className="activity-item">
                      <div className="activity-icon warning">
                        <i className="pi pi-exclamation-triangle"></i>
                      </div>
                      <div className="activity-content">
                        <h4>BGV pending for 3 candidates</h4>
                        <p>Background verification in progress</p>
                        <span className="activity-time">4 hours ago</span>
                      </div>
                    </div>
                    <div className="activity-item">
                      <div className="activity-icon info">
                        <i className="pi pi-info-circle"></i>
                      </div>
                      <div className="activity-content">
                        <h4>New batch assigned to Wave 2</h4>
                        <p>15 resources moved to next phase</p>
                        <span className="activity-time">6 hours ago</span>
                      </div>
                    </div>
                  </div>
                </Card>
              </div>
              
              {/* Tables Row */}
              <div className="tables-row">
                <Card className="table-card">
                  <div className="card-header">
                    <h3>Resource Details by Team</h3>
                    <div className="card-actions">
                      <Button 
                        label="Export" 
                        icon="pi pi-download" 
                        className="p-button-outlined p-button-sm"
                      />
                    </div>
                  </div>
                  <ResourceTables tableData={tableData} />
                </Card>
              </div>
            </div>
          )}

          {activeSection === 'resources' && (
            <Card className="full-width-card">
              <div className="card-header">
                <h3>Resource Management</h3>
              </div>
              <ResourceTables tableData={tableData} />
            </Card>
          )}

          {activeSection === 'progress' && (
            <Card className="full-width-card">
              <div className="card-header">
                <h3>Onboarding Progress</h3>
              </div>
              <ProgressCircle />
            </Card>
          )}

          {activeSection !== 'dashboard' && activeSection !== 'resources' && activeSection !== 'progress' && (
            <Card className="full-width-card">
              <div className="card-header">
                <h3>{navigationItems.find(item => item.section === activeSection)?.label}</h3>
              </div>
              <div className="coming-soon">
                <i className="pi pi-info-circle"></i>
                <h3>Coming Soon</h3>
                <p>This feature will be available in the next release.</p>
              </div>
            </Card>
          )}
        </div>
      </main>

      <OnboardingDialog 
        visible={dialogVisible} 
        onHide={() => setDialogVisible(false)} 
        onSubmit={handleDialogSubmit} 
      />
    </div>
  );
}

export default Dashboard;
