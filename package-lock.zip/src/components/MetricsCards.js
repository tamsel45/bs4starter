import React from 'react';
import { Card } from 'primereact/card';
import './MetricsCards.css';

const metrics = [
  { 
    label: 'Active', 
    value: 120, 
    icon: 'pi pi-user-check', 
    color: '#2A9D8F',
    trend: '+5%',
    description: 'Currently active resources'
  },
  { 
    label: 'On-Hold', 
    value: 10, 
    icon: 'pi pi-pause-circle', 
    color: '#F4A261',
    trend: '-2%',
    description: 'Resources on temporary hold'
  },
  { 
    label: 'Onboarding', 
    value: 15, 
    icon: 'pi pi-user-plus', 
    color: '#E76F51',
    trend: '+8%',
    description: 'In onboarding process'
  },
  { 
    label: 'Open Requirement', 
    value: 8, 
    icon: 'pi pi-clipboard', 
    color: '#264653',
    trend: '+3%',
    description: 'Positions to be filled'
  },
  { 
    label: 'Resigned', 
    value: 5, 
    icon: 'pi pi-user-minus', 
    color: '#E63946',
    trend: '+1%',
    description: 'Recently resigned'
  },
  { 
    label: 'Terminated', 
    value: 2, 
    icon: 'pi pi-ban', 
    color: '#D62828',
    trend: '0%',
    description: 'Terminated employees'
  },
  { 
    label: 'WMP', 
    value: 7, 
    icon: 'pi pi-briefcase', 
    color: '#6F4E37',
    trend: '+4%',
    description: 'Workforce management'
  },
  { 
    label: 'BGV', 
    value: 6, 
    icon: 'pi pi-shield', 
    color: '#457B9D',
    trend: '+2%',
    description: 'Background verification'
  },
];

function MetricsCards() {
  const getTrendClass = (trend) => {
    if (trend.startsWith('+')) return 'positive';
    if (trend.startsWith('-')) return 'negative';
    return 'neutral';
  };

  return (
    <div className="metrics-container">
      <div className="metrics-grid">
        {metrics.map((metric, idx) => (
          <Card key={metric.label} className="metric-card" style={{'--card-color': metric.color}}>
            <div className="metric-content">
              <div className="metric-header">
                <div className="metric-icon-wrapper">
                  <i className={`${metric.icon} metric-icon`}></i>
                </div>
                <div className="metric-trend">
                  <span className={`trend-value ${getTrendClass(metric.trend)}`}>
                    {metric.trend}
                  </span>
                </div>
              </div>
              
              <div className="metric-body">
                <div className="metric-value">{metric.value}</div>
                <div className="metric-label">{metric.label}</div>
                <div className="metric-description">{metric.description}</div>
              </div>
              
              <div className="metric-footer">
                <div className="metric-progress-bar">
                  <div 
                    className="metric-progress-fill" 
                    style={{width: `${Math.min((metric.value / 150) * 100, 100)}%`}}
                  ></div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default MetricsCards;
