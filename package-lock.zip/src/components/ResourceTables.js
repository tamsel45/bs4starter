import React from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Card } from 'primereact/card';
import PropTypes from 'prop-types';
import './ResourceTables.css';

const columns = [
  { field: 'requireDate', header: 'Require Date' },
  { field: 'team', header: 'Team' },
  { field: 'wave1', header: 'Wave1' },
  { field: 'wave2', header: 'Wave2' },
  { field: 'total', header: 'Total' },
  { field: 'totalSelected', header: 'Total Selected' },
  { field: 'dropOuts', header: 'Drop-Outs' },
  { field: 'r1YetToSchedule', header: 'R1-Yet to Schedule' },
  { field: 'r1Schedule', header: 'R1-Schedule' },
  { field: 'r1Reject', header: 'R1 Reject' },
  { field: 'r2YetToSchedule', header: 'R2-Yet to Schedule' },
  { field: 'r2Schedule', header: 'R2-Schedule' },
  { field: 'r2Reject', header: 'R2 Reject' },
  { field: 'r2Select', header: 'R2 Select' },
  { field: 'wave1Completed', header: 'Wave1 Completed %' },
  { field: 'wave2Completed', header: 'Wave2 Completed %' },
];

const tableConfigs = [
  {
    title: 'EY (Regular)',
    dataKey: 'EYRegular',
    icon: 'pi pi-building',
    description: 'Regular onboarding for EY resources'
  },
  {
    title: 'EY (Additional 40)',
    dataKey: 'EYAdditional',
    icon: 'pi pi-plus-circle',
    description: 'Additional 40 resources for EY'
  },
  {
    title: 'Wipro (Regular)',
    dataKey: 'WiproRegular',
    icon: 'pi pi-users',
    description: 'Regular onboarding for Wipro resources'
  }
];

function ResourceTables({ tableData }) {
  const emptyTemplate = (tableName) => (
    <div className="empty-table-message">
      <i className="pi pi-inbox empty-table-icon"></i>
      <div>No resources found for {tableName}</div>
      <div>Use the "Add New Resource" button to add resources</div>
    </div>
  );

  return (
    <div className="resource-tables-wrapper">
      {tableConfigs.map(config => (
        <Card key={config.dataKey} className="resource-table-card">
          <div className="table-header">
            <h3>
              <i className={config.icon}></i>
              {config.title}
            </h3>
            <p className="table-description">{config.description}</p>
          </div>
          
          <DataTable 
            value={tableData[config.dataKey]} 
            paginator 
            rows={10} 
            emptyMessage={emptyTemplate(config.title)}
            className="resource-data-table"
            stripedRows
            showGridlines
            scrollable
            scrollHeight="400px"
          >
            {columns.map(col => (
              <Column 
                key={col.field} 
                field={col.field} 
                header={col.header}
                sortable
                style={{ minWidth: '120px' }}
              />
            ))}
          </DataTable>
        </Card>
      ))}
    </div>
  );
}

ResourceTables.propTypes = {
  tableData: PropTypes.shape({
    EYRegular: PropTypes.array,
    EYAdditional: PropTypes.array,
    WiproRegular: PropTypes.array
  }).isRequired
};

export default ResourceTables;
