# Resource Onboarding Tracker

A beautiful web dashboard to track resource onboarding progress, metrics, and details for EY and Wipro teams.

## Features
- Progress circle for onboarding status
- Eight metric cards with icons
- Three tables for EY (Regular), EY (Additional 40), Wipro (Regular)
- Modal dialog for onboarding resource creation
- Accessible, keyboard-navigable, and high-contrast UI
- Built with React, PrimeReact, PrimeIcons, and React Icons

## Getting Started
1. Install dependencies:
   ```sh
   npm install
   ```
2. Start the development server:
   ```sh
   npm start
   ```

## Tech Stack
- React
- PrimeReact
- PrimeIcons
- React Icons

## License
MIT
