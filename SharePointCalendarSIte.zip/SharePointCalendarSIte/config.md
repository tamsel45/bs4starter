# SharePoint Training Calendar Configuration

## SharePoint List Setup

### 1. Create SharePoint List
Create a new SharePoint list named **"TrainingEvents"** with the following columns:

#### Required Columns:
| Column Name | Type | Description |
|------------|------|-------------|
| **Title** | Single line of text | Event title (e.g., "Generative AI - Fundamentals") |
| **Description** | Multiple lines of text | Detailed event description |
| **EventDate** | Date and Time | Event start date and time |
| **EndDate** | Date and Time | Event end date and time |
| **TrainerDetails** | Multiple lines of text | Trainer name and credentials |
| **WebExLink** | Hyperlink | WebEx meeting URL |
| **Location** | Single line of text | Physical/Virtual location |
| **Category** | Choice | Domain type (generativeAI, containerization, devOps, testAutomation) |
| **SessionType** | Choice | Session type (Fundamentals, Advanced Concepts, Practical Implementation) |
| **WeekNumber** | Number | Training week (1-6) |
| **DayNumber** | Number | Day of week (1-5, Monday-Friday) |
| **Materials** | Hyperlink | Link to training materials |

#### Choice Field Values:

**Category choices:**
- generativeAI
- containerization  
- devOps
- testAutomation

**SessionType choices:**
- Fundamentals
- Advanced Concepts
- Practical Implementation

### 2. SharePoint Site Configuration

Update the SharePoint configuration in `app.js`:

```javascript
const sharePointConfig = {
  siteUrl: "https://[your-tenant].sharepoint.com/sites/[your-site]",
  listName: "TrainingEvents",
  fields: [
    'Id', 'Title', 'Description', 'EventDate', 'EndDate', 
    'TrainerDetails', 'WebExLink', 'Location', 'Category',
    'SessionType', 'WeekNumber', 'DayNumber', 'Materials'
  ]
};
```

### 3. Sample Data Structure

Here's an example of how to structure your SharePoint list data:

| Title | Description | EventDate | EndDate | TrainerDetails | WebExLink | Location | Category | SessionType |
|-------|-------------|-----------|---------|----------------|-----------|----------|----------|-------------|
| Generative AI - Fundamentals | Introduction to GenAI fundamentals... | 2025-09-01T09:30:00 | 2025-09-01T13:30:00 | Dr. Sarah Chen - AI Expert | https://meet.webex.com/meet/genai-training-2025-09-01 | Training Room A | generativeAI | Fundamentals |
| Containerization - Fundamentals | Docker and container basics... | 2025-09-01T09:30:00 | 2025-09-01T13:30:00 | Mike Rodriguez - DevOps Expert | https://meet.webex.com/meet/container-training-2025-09-01 | Training Room B | containerization | Fundamentals |

### 4. Testing the Connection

To test if the SharePoint integration is working:

1. Open browser developer tools (F12)
2. Go to Console tab
3. Load the calendar application
4. Look for these messages:
   - ✅ "Successfully loaded X events from SharePoint"
   - ❌ "Unable to connect to SharePoint" (will use mock data)

### 5. Deployment Options

#### Option A: Same-Origin (Recommended)
- Host the calendar application on the same SharePoint site
- Uses automatic SharePoint authentication
- No additional configuration needed

#### Option B: Cross-Origin
- Host on external server
- Configure CORS settings in SharePoint Admin
- May require additional authentication setup

### 6. Quick Start Checklist

- [ ] Create SharePoint list "TrainingEvents"
- [ ] Add all required columns with correct types
- [ ] Configure choice field values
- [ ] Set appropriate permissions
- [ ] Update `sharePointConfig` in app.js
- [ ] Test the connection
- [ ] Import training data
- [ ] Verify calendar displays correctly

For additional support, refer to [SharePoint REST API documentation](https://docs.microsoft.com/en-us/sharepoint/dev/sp-add-ins/get-to-know-the-sharepoint-rest-service).

If using SharePoint data, replace the placeholder values in `app.js`:

```javascript
const sharePointConfig = {
  siteUrl: "https://yourtenant.sharepoint.com/sites/yoursite", // Replace with your site URL
  listName: "Calendar Events", // Your list name
  fields: [
    'Id',
    'Title',
    'Description',
    'EventDate',
    'EndDate',
    'TrainerDetails',
    'WebExLink',
    'Location'
  ]
};
```

## Step 3: Deploy Files

1. Upload all files to your web server
2. Ensure the files are accessible via HTTP/HTTPS
3. Open `index.html` in a browser

## Features Included

### ✅ No Authentication Required
- Direct access to calendar
- No login process
- No Azure AD setup needed

### ✅ Calendar Display
- FullCalendar.js integration
- Month, week, and day views
- Responsive design

### ✅ Event Details Modal
- Click any event to see details
- Shows all event information:
  - Title
  - Description
  - Trainer details
  - Date and time
  - WebEx link (clickable)
  - Location

### ✅ Mock Data Support
- Includes sample events for demonstration
- Works out of the box without SharePoint connection

### ✅ Auto-Refresh
- Events automatically refresh every 5 minutes
- Configurable refresh interval

## Step 4: SharePoint Integration (Optional)

To connect to real SharePoint data instead of mock data:

### Option A: SharePoint REST API (Same Domain)
If hosting on the same SharePoint site, you can use direct REST API calls:

```javascript
async function fetchSharePointListItems() {
  try {
    const response = await fetch(
      `${sharePointConfig.siteUrl}/_api/web/lists/getbytitle('${sharePointConfig.listName}')/items`,
      {
        headers: {
          'Accept': 'application/json;odata=verbose',
          'Content-Type': 'application/json;odata=verbose'
        }
      }
    );
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    return data.d.results.map(item => ({
      Id: item.Id,
      Title: item.Title,
      Description: item.Description,
      EventDate: item.EventDate,
      EndDate: item.EndDate,
      TrainerDetails: item.TrainerDetails,
      WebExLink: item.WebExLink && item.WebExLink.Url,
      Location: item.Location
    }));
  } catch (error) {
    console.error('Error fetching SharePoint data:', error);
    return getMockEvents(); // Fallback to mock data
  }
}
```

### Option B: Power Automate Flow
Create a Power Automate flow to expose SharePoint data via HTTP endpoint:

1. Create a new flow with "When an HTTP request is received" trigger
2. Add "Get items" action for your SharePoint list
3. Add "Response" action to return the data as JSON
4. Use the HTTP endpoint URL in your JavaScript

### Option C: SharePoint Framework (SPFx)
For full SharePoint integration, consider building an SPFx web part.

## Deployment Options

### Option 1: Simple File Hosting
```bash
# Any web server
python -m http.server 8000
# or
npx serve .
```

### Option 2: SharePoint Document Library
1. Upload files to SharePoint document library
2. Create modern SharePoint page
3. Add Script Editor or File Viewer web part

### Option 3: Azure Static Web Apps
1. Create Azure Static Web App
2. Deploy files
3. Configure custom domain if needed

## Testing

1. Open `index.html` in a web browser
2. Calendar should load immediately (no login required)
3. Click on any event to see details modal
4. Sample events should be visible

## Customization

### Adding More Mock Events
Edit the `getMockEvents()` function in `app.js`:

```javascript
function getMockEvents() {
  return [
    {
      Id: 5,
      Title: "Your New Event",
      Description: "Event description",
      EventDate: "2025-08-25T10:00:00",
      EndDate: "2025-08-25T12:00:00",
      TrainerDetails: "Trainer Name",
      WebExLink: "https://meet.webex.com/meet/your-link",
      Location: "Your Location"
    }
    // Add more events here
  ];
}
```

### Changing Refresh Interval
Edit the refresh interval in `app.js`:

```javascript
// Change from 5 minutes to desired interval
setInterval(async function() {
  // Auto-refresh code
}, 2 * 60 * 1000); // 2 minutes
```
