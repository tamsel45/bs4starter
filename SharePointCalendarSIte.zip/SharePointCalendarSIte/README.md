# 6-Week Training Program Calendar

A comprehensive calendar application for managing a 6-week training program with four domains: Generative AI, Containerization, DevOps, and Test Automation. Event details are pulled from SharePoint lists with automatic updates.

## Training Program Overview

**Duration**: September 1 - October 15, 2025 (6 weeks)  
**Daily Schedule**: 9:30 AM - 1:30 PM (4 hours per day)  
**Structure**: All four domains run parallel sessions daily  
**Total**: 120 hours per domain  

### Four Training Domains
- 🔵 **Generative AI** - Dr. Sarah Chen
- 🟢 **Containerization** - Mike Rodriguez  
- 🟡 **DevOps** - Jennifer Williams
- 🔵 **Test Automation** - Alex Thompson

## Features

✅ **SharePoint Integration**
- Real-time data from SharePoint "TrainingEvents" list
- Automatic calendar updates when list is modified
- Fallback to sample data for demonstrations

✅ **Domain Management**
- Filter events by training domain
- Color-coded sessions for easy identification
- Domain-specific trainer and material information

✅ **Material Downloads**
- Download training materials per domain
- PDF guides, practical exercises, and resources
- Organized by domain expertise

✅ **Interactive Calendar**
- Multiple views: Month, week, day, and list
- Click events for detailed session information
- Responsive design for desktop and mobile

✅ **Event Details Modal**
- Session title and description
- Trainer credentials and expertise
- Unique WebEx links per domain
- Room assignments and virtual options
- Session type and week progression

✅ **Modern Bootstrap UI**
- Professional Bootstrap 5.3.0 design
- Accessibility-compliant interface
- Mobile-responsive layout
- Loading states and error handling
- Accessibility features

## File Structure

```
SharePointCalendarSIte/
├── index.html          # Main HTML file
├── app.js             # JavaScript application logic
├── styles.css         # CSS styles
├── config.md          # Configuration guide
└── README.md          # This file
```

## Quick Start

1. **Download/clone** this repository
2. **Host the files** on any web server (no special configuration needed)
3. **Open `index.html`** in a web browser
4. **View the calendar** with sample events immediately
5. **Optional**: Connect to SharePoint lists following `config.md`

## Prerequisites

### Basic Setup (Works Immediately)
- Web browser
- Web server (any simple HTTP server)
- No authentication setup required

### SharePoint Integration (Optional)
- SharePoint Online site
- Custom list with event data
- Basic web server configuration

### Required SharePoint List Columns

| Column Name | Type | Required | Description |
|-------------|------|----------|-------------|
| Title | Single line of text | Yes | Event title |
| Description | Multiple lines of text | No | Event description |
| EventDate | Date and Time | Yes | Event start date/time |
| EndDate | Date and Time | No | Event end date/time |
| TrainerDetails | Single line of text | No | Trainer information |
| WebExLink | Hyperlink | No | WebEx meeting link |
| Location | Single line of text | No | Event location |

## Configuration

### 1. Basic Setup (No Configuration Needed)

The application works immediately with mock data. No setup required!

### 2. SharePoint Integration (Optional)

If you want to connect to real SharePoint data:

1. Create SharePoint list with required columns (see `config.md`)
2. Update `sharePointConfig` in `app.js` with your site URL and list name
3. Modify `fetchSharePointListItems()` function for your data source

### 3. Hosting Options

**Simple Local Server:**
```bash
# Python
python -m http.server 8000

# Node.js
npx serve .

# PHP
php -S localhost:8000
```

**Online Hosting:**
- Upload to any web hosting service
- Works with GitHub Pages, Netlify, Azure Static Web Apps
- Can be hosted in SharePoint document library

## Deployment Options

### Option 1: Local Development
```bash
# Start a simple HTTP server
python -m http.server 8000
# or
npx serve .
```

### Option 2: Azure Static Web Apps
1. Create Azure Static Web App
2. Connect to your repository
3. Deploy automatically

### Option 3: SharePoint Pages
1. Upload files to SharePoint document library
2. Create modern SharePoint page
3. Add Script Editor web part

### Option 4: IIS / Apache
1. Copy files to web server directory
2. Ensure HTTPS is configured
3. Update redirect URIs in Azure AD

## Testing

The application includes mock data and works immediately:

1. Open `index.html` in any web browser
2. Calendar loads automatically (no login required)
3. View sample events on the calendar
4. Click events to see detailed information modal
5. Test responsiveness on different screen sizes

## Connecting to Real SharePoint Data

To use actual SharePoint lists instead of mock data:

1. Create SharePoint list with required columns (see `config.md`)
2. Update configuration in `app.js`
3. Modify the data fetching function
4. Test the connection

See `config.md` for detailed instructions.

## Troubleshooting

### Common Issues

**Calendar Not Loading**
- Check console for JavaScript errors
- Ensure all files are properly hosted
- Verify file paths are correct

**Events Not Displaying**
- Check mock data in `getMockEvents()` function
- Verify date formats are correct
- Look for console errors

**Modal Not Opening**
- Check if FullCalendar library loaded correctly
- Verify click event handlers are working
- Check browser developer tools

**Responsive Issues**
- Test on different screen sizes
- Check CSS media queries
- Verify viewport meta tag is present

### Debug Mode

Enable debug logging:
```javascript
// Add to app.js
console.log('Debug mode enabled');
// Add logging throughout the application
```

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Security Considerations

- Uses MSAL.js for secure authentication
- Tokens are stored in session storage
- HTTPS required for production
- API permissions follow principle of least privilege

## Performance

- Lazy loading of calendar events
- Auto-refresh configurable (default: 5 minutes)
- Responsive design for optimal mobile performance
- Efficient event rendering with FullCalendar.js

## Customization

### Styling
- Edit `styles.css` to match your brand colors
- Modify CSS variables for consistent theming
- Add custom animations or transitions

### Functionality
- Add event creation/editing capabilities
- Implement event filtering and search
- Add email notifications
- Include recurring event support

### Integration
- Connect to other Microsoft 365 services
- Add Teams integration
- Include Outlook calendar sync

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review SharePoint and Azure AD documentation
3. Test with mock data first
4. Verify all prerequisites are met

## License

This project is open source. Feel free to modify and distribute according to your needs.

## Version History

- **v1.0** - Initial release with basic calendar and SharePoint integration
- **v1.1** - Added authentication and event details modal
- **v1.2** - Improved responsive design and error handling
