// Modern SharePoint Calendar Application (Bootstrap + FullCalendar 6.1.19)
// Author: GitHub Copilot
// Description: Advanced calendar with Bootstrap UI and full FullCalendar features

// SharePoint Configuration - Replace with your SharePoint details
const sharePointConfig = {
  siteUrl: "https://yourtenant.sharepoint.com/sites/yoursite",
  listName: "TrainingEvents", // Updated list name for training program
  fields: [
    'Id', 'Title', 'Description', 'EventDate', 'EndDate', 
    'TrainerDetails', 'WebExLink', 'Location', 'Category',
    'SessionType', 'WeekNumber', 'DayNumber', 'Materials'
  ]
};

// Global variables
let calendar;
let currentEvents = [];
let eventCategories = {
  generativeAI: { color: '#007BFF', name: 'Generative AI' },        // Solid Blue
  containerization: { color: '#28A745', name: 'Containerization' }, // Solid Green
  devOps: { color: '#FD7E14', name: 'DevOps' },                    // Solid Orange
  testAutomation: { color: '#6F42C1', name: 'Test Automation' }     // Solid Purple
};

// Application initialization
document.addEventListener('DOMContentLoaded', function() {
  initializeApp();
});

async function initializeApp() {
  try {
    console.log('🚀 Initializing Modern Calendar Application...');
    
    // Set up event listeners
    setupEventListeners();
    
    // Initialize calendar
    await initializeMainCalendar();
    
    // Load events
    await loadEvents();
    
    // Initialize Bootstrap tooltips and popovers
    initializeBootstrapComponents();
    
    // Show welcome message
    showAlert('Welcome to SharePoint Calendar! 🎉', 'success');
    
  } catch (error) {
    console.error('❌ Error initializing app:', error);
    showAlert('Failed to initialize application. Please refresh the page.', 'danger');
  }
}

function setupEventListeners() {
  // View mode toggles
  document.querySelectorAll('input[name="viewMode"]').forEach(radio => {
    radio.addEventListener('change', function() {
      if (this.checked) {
        changeCalendarView(this.id);
      }
    });
  });

  // Quick action buttons
  document.getElementById('todayBtn')?.addEventListener('click', () => {
    calendar.today();
    showAlert('Navigated to today', 'info', 2000);
  });
  
  document.getElementById('refreshBtn')?.addEventListener('click', async () => {
    await loadEvents();
    showAlert('Events refreshed', 'success', 2000);
  });

  // Calendar navigation
  document.getElementById('prevBtn')?.addEventListener('click', () => {
    calendar.prev();
  });
  
  document.getElementById('nextBtn')?.addEventListener('click', () => {
    calendar.next();
  });

  // Event category filters
  document.querySelectorAll('input[type="checkbox"][id$="AI"], input[type="checkbox"][id="containerization"], input[type="checkbox"][id="devOps"], input[type="checkbox"][id="testAutomation"]').forEach(checkbox => {
    checkbox.addEventListener('change', filterEventsByCategory);
  });

  // Modal action buttons
  document.getElementById('joinMeetingBtn')?.addEventListener('click', handleJoinMeeting);
  document.getElementById('addToCalendarBtn')?.addEventListener('click', handleAddToCalendar);
  document.getElementById('shareEventBtn')?.addEventListener('click', handleShareEvent);
  document.getElementById('downloadMaterialBtn')?.addEventListener('click', handleDownloadMaterial);
}

// Calendar initialization with all FullCalendar 6.1.19 features
async function initializeMainCalendar() {
  const calendarEl = document.getElementById('calendar');
  
  calendar = new FullCalendar.Calendar(calendarEl, {
    // Core Options
    initialView: 'dayGridMonth',
    height: 'auto',
    aspectRatio: 1.35,
    
    // Header Configuration
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
    },
    
    // View-specific Options
    views: {
      dayGridMonth: {
        dayMaxEvents: 3,
        moreLinkClick: 'popover',
        moreLinkContent: function(args) {
          return `+${args.num} more events`;
        }
      },
      timeGridWeek: {
        slotMinTime: '06:00:00',
        slotMaxTime: '22:00:00',
        slotDuration: '00:30:00',
        slotLabelInterval: '01:00:00',
        nowIndicator: true,
        scrollTime: '08:00:00'
      },
      timeGridDay: {
        slotMinTime: '06:00:00',
        slotMaxTime: '22:00:00',
        slotDuration: '00:15:00',
        slotLabelInterval: '01:00:00',
        nowIndicator: true,
        scrollTime: '08:00:00'
      },
      listWeek: {
        listDayFormat: { weekday: 'long', month: 'long', day: 'numeric' },
        listDaySideFormat: false,
        noEventsContent: 'No events to display'
      }
    },
    
    // Date/Time Configuration
    locale: 'en',
    timeZone: 'local',
    firstDay: 1, // Monday
    weekNumbers: true,
    weekNumberCalculation: 'ISO',
    
    // Event Configuration
    eventDisplay: 'block',
    eventStartEditable: false,
    eventDurationEditable: false,
    eventResizableFromStart: false,
    
    // Interaction
    selectable: true,
    selectMirror: true,
    unselectAuto: true,
    dayMaxEvents: true,
    
    // Event Handlers
    eventClick: function(info) {
      showEventDetails(info.event);
    },
    
    select: function(info) {
      showNewEventDialog(info.start, info.end);
    },
    
    eventMouseEnter: function(info) {
      // Create tooltip
      const tooltip = createEventTooltip(info.event);
      info.el.appendChild(tooltip);
    },
    
    eventMouseLeave: function(info) {
      // Remove tooltip
      const tooltip = info.el.querySelector('.event-tooltip');
      if (tooltip) {
        tooltip.remove();
      }
    },
    
    datesSet: function(info) {
      updateEventStatistics();
    },
    
    eventDidMount: function(info) {
      // Add custom classes based on event type
      const category = info.event.extendedProps.category || 'meeting';
      info.el.classList.add(`${category}-event`);
      
      // Add accessibility attributes
      info.el.setAttribute('role', 'button');
      info.el.setAttribute('tabindex', '0');
      info.el.setAttribute('aria-label', `Event: ${info.event.title}`);
      
      // Add keyboard navigation
      info.el.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          showEventDetails(info.event);
        }
      });
    },
    
    // Business Hours
    businessHours: {
      daysOfWeek: [1, 2, 3, 4, 5], // Monday - Friday
      startTime: '09:00',
      endTime: '17:00'
    },
    
    // Theming
    themeSystem: 'bootstrap5',
    
    // Custom Buttons
    customButtons: {
      exportButton: {
        text: 'Export',
        click: function() {
          exportCalendarData();
        }
      }
    }
  });
  
  calendar.render();
  
  // Add custom animations
  calendar.getEvents().forEach(event => {
    const eventEl = calendar.getEventEl(event);
    if (eventEl) {
      eventEl.classList.add('fade-in');
    }
  });
}

function changeCalendarView(viewId) {
  const viewMap = {
    'monthView': 'dayGridMonth',
    'weekView': 'timeGridWeek',
    'dayView': 'timeGridDay'
  };
  
  const newView = viewMap[viewId];
  if (newView && calendar) {
    calendar.changeView(newView);
    showAlert(`Switched to ${newView.replace(/([A-Z])/g, ' $1').toLowerCase()} view`, 'info', 2000);
  }
}

// Enhanced event loading with SharePoint integration
async function loadEvents() {
  try {
    showLoading(true);
    hideAllAlerts();

    console.log('🔄 Starting event loading process...');
    
    // Fetch events from SharePoint (with fallback to mock data)
    const events = await fetchSharePointListItems();
    currentEvents = events;
    
    // Clear existing events
    calendar.removeAllEvents();
    
    // Add events to calendar with enhanced properties
    events.forEach(event => {
      const calendarEvent = {
        id: event.Id,
        title: event.Title,
        start: event.EventDate,
        end: event.EndDate,
        backgroundColor: getEventColor(event.Category),
        borderColor: getEventColor(event.Category),
        textColor: '#ffffff',
        extendedProps: {
          description: event.Description,
          trainer: event.TrainerDetails,
          webexLink: event.WebExLink,
          location: event.Location,
          category: event.Category || 'generativeAI',
          sessionType: event.SessionType || 'Fundamentals',
          weekNumber: event.WeekNumber || 1,
          dayNumber: event.DayNumber || 1,
          materials: event.Materials || '',
          attendees: event.Attendees || [],
          isRecurring: event.IsRecurring || false,
          priority: event.Priority || 'normal'
        },
        classNames: [`event-${event.Category || 'generativeAI'}`],
        display: 'block'
      };
      
      calendar.addEvent(calendarEvent);
    });

    // Update statistics
    updateEventStatistics();
    
    showLoading(false);
    
    // Show success message with data source
    const dataSource = events.length > 100 ? 'SharePoint' : 'demonstration data';
    showAlert(`✅ Loaded ${events.length} training sessions from ${dataSource}`, 'success', 3000);
    
  } catch (error) {
    console.error('❌ Error loading events:', error);
    showAlert('Failed to load events. Please check your connection and try again.', 'danger');
    showLoading(false);
  }
}

function getEventColor(category) {
  return eventCategories[category]?.color || eventCategories.generativeAI.color;
}

// Enhanced event details modal
function showEventDetails(event) {
  // Populate modal with event details
  document.getElementById('eventTitle').textContent = event.title;
  document.getElementById('eventDescription').textContent = 
    event.extendedProps.description || 'No description available';
  document.getElementById('eventTrainer').textContent = 
    event.extendedProps.trainer || 'No trainer assigned';
  document.getElementById('eventLocation').textContent = 
    event.extendedProps.location || 'Location TBD';
  
  // Format date and time with enhanced formatting
  const startDate = new Date(event.start);
  const endDate = event.end ? new Date(event.end) : null;
  document.getElementById('eventDateTime').textContent = formatEventDateTime(startDate, endDate);
  
  // WebEx Link with enhanced UI
  const webexContainer = document.getElementById('eventWebEx');
  if (event.extendedProps.webexLink) {
    webexContainer.innerHTML = `
      <a href="${event.extendedProps.webexLink}" 
         target="_blank" 
         class="btn btn-sm btn-outline-primary">
        <i class="bi bi-camera-video me-1"></i>Join Meeting
      </a>`;
  } else {
    webexContainer.innerHTML = '<span class="text-muted">No meeting link available</span>';
  }
  
  // Handle download materials button state
  const downloadBtn = document.getElementById('downloadMaterialBtn');
  const hasMaterials = event.extendedProps.materials && event.extendedProps.materials.trim() !== '';
  
  if (hasMaterials) {
    downloadBtn.disabled = false;
    downloadBtn.classList.remove('disabled');
    downloadBtn.title = 'Download training materials';
  } else {
    downloadBtn.disabled = true;
    downloadBtn.classList.add('disabled');
    downloadBtn.title = 'No materials available for this session';
  }
  
  // Set event metadata
  document.getElementById('eventId').textContent = event.id;
  document.getElementById('eventLastUpdated').textContent = new Date().toLocaleDateString();
  
  // Store current event for modal actions
  const modal = new bootstrap.Modal(document.getElementById('eventModal'));
  modal.currentEvent = event;
  modal.show();
}

// Create event tooltip for hover effects
function createEventTooltip(event) {
  const tooltip = document.createElement('div');
  tooltip.className = 'event-tooltip position-absolute bg-dark text-white p-2 rounded shadow-sm';
  tooltip.style.cssText = `
    top: -40px; left: 50%; transform: translateX(-50%);
    z-index: 1000; font-size: 0.75rem; white-space: nowrap;
    pointer-events: none;
  `;
  
  const startTime = event.start.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
  tooltip.innerHTML = `
    <strong>${event.title}</strong><br>
    <small>${startTime} | ${event.extendedProps.location || 'TBD'}</small>
  `;
  
  return tooltip;
}

// Update event statistics
function updateEventStatistics() {
  const events = calendar.getEvents();
  const now = new Date();
  const upcomingEvents = events.filter(event => new Date(event.start) >= now);
  
  document.getElementById('totalEvents').textContent = events.length;
  document.getElementById('upcomingEvents').textContent = upcomingEvents.length;
  
  // Animate the numbers
  animateNumber('totalEvents', events.length);
  animateNumber('upcomingEvents', upcomingEvents.length);
}

function animateNumber(elementId, finalNumber) {
  const element = document.getElementById(elementId);
  const duration = 1000;
  const increment = finalNumber / (duration / 16);
  let current = 0;
  
  const timer = setInterval(() => {
    current += increment;
    if (current >= finalNumber) {
      current = finalNumber;
      clearInterval(timer);
    }
    element.textContent = Math.floor(current);
  }, 16);
}

// Filter events by category
function filterEventsByCategory() {
  const generativeAIChecked = document.getElementById('generativeAI').checked;
  const containerizationChecked = document.getElementById('containerization').checked;
  const devOpsChecked = document.getElementById('devOps').checked;
  const testAutomationChecked = document.getElementById('testAutomation').checked;
  
  const events = calendar.getEvents();
  
  events.forEach(event => {
    const category = event.extendedProps.category;
    let shouldShow = false;
    
    if (category === 'generativeAI' && generativeAIChecked) shouldShow = true;
    if (category === 'containerization' && containerizationChecked) shouldShow = true;
    if (category === 'devOps' && devOpsChecked) shouldShow = true;
    if (category === 'testAutomation' && testAutomationChecked) shouldShow = true;
    if (!category && generativeAIChecked) shouldShow = true; // Default to generative AI
    
    // Toggle event visibility
    const eventEl = document.querySelector(`[data-event-id="${event.id}"]`);
    if (eventEl) {
      eventEl.style.display = shouldShow ? 'block' : 'none';
    }
  });
  
  updateEventStatistics();
}

// Modal action handlers
function handleJoinMeeting() {
  const modal = bootstrap.Modal.getInstance(document.getElementById('eventModal'));
  const event = modal.currentEvent;
  
  if (event?.extendedProps.webexLink) {
    window.open(event.extendedProps.webexLink, '_blank');
    showAlert('Opening meeting link...', 'info', 2000);
  } else {
    showAlert('No meeting link available for this event', 'warning', 3000);
  }
}

function handleAddToCalendar() {
  const modal = bootstrap.Modal.getInstance(document.getElementById('eventModal'));
  const event = modal.currentEvent;
  
  if (event) {
    // Create Outlook calendar integration URL
    const startDate = new Date(event.start);
    const endDate = event.end ? new Date(event.end) : new Date(startDate.getTime() + 4 * 60 * 60 * 1000);
    
    // Format dates for Outlook (ISO format)
    const startISO = startDate.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
    const endISO = endDate.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
    
    // Prepare event details for Outlook
    const outlookEvent = {
      subject: encodeURIComponent(event.title),
      startdt: startISO,
      enddt: endISO,
      body: encodeURIComponent(`
Training Session: ${event.title}

Description: ${event.extendedProps.description || 'No description available'}

Trainer: ${event.extendedProps.trainer || 'TBD'}

Location: ${event.extendedProps.location || 'Virtual'}

${event.extendedProps.webexLink ? `Meeting Link: ${event.extendedProps.webexLink}` : ''}

Domain: ${eventCategories[event.extendedProps.category]?.name || 'Training'}
Session Type: ${event.extendedProps.sessionType || 'Training Session'}
`),
      location: encodeURIComponent(event.extendedProps.location || 'Virtual Training')
    };
    
    // Create Outlook Web URL
    const outlookWebUrl = `https://outlook.live.com/calendar/0/deeplink/compose?subject=${outlookEvent.subject}&startdt=${outlookEvent.startdt}&enddt=${outlookEvent.enddt}&body=${outlookEvent.body}&location=${outlookEvent.location}`;
    
    // Create Outlook Desktop URL (for Outlook app)
    const outlookDesktopUrl = `outlook://calendar/action/compose?subject=${outlookEvent.subject}&startdt=${outlookEvent.startdt}&enddt=${outlookEvent.enddt}&body=${outlookEvent.body}&location=${outlookEvent.location}`;
    
    // Try to open Outlook desktop first, fallback to web
    try {
      // Try desktop Outlook first
      window.location.href = outlookDesktopUrl;
      
      // Fallback to web Outlook after a short delay
      setTimeout(() => {
        window.open(outlookWebUrl, '_blank');
      }, 1000);
      
      showAlert('📅 Opening in Outlook... If Outlook app doesn\'t open, check your browser for the web version.', 'success', 5000);
    } catch (error) {
      // Direct fallback to web Outlook
      console.warn('Outlook desktop not available, using web version:', error);
      window.open(outlookWebUrl, '_blank');
      showAlert('📅 Opening Outlook Calendar in browser...', 'success', 3000);
    }
    
    // Also create downloadable .ics file as backup
    const icsContent = generateICSContent(event);
    const blob = new Blob([icsContent], { type: 'text/calendar' });
    const url = URL.createObjectURL(blob);
    
    // Create hidden download link as backup
    const link = document.createElement('a');
    link.href = url;
    link.download = `${event.title.replace(/[^a-z0-9]/gi, '_')}.ics`;
    link.style.display = 'none';
    document.body.appendChild(link);
    
    // Remove the link after a delay
    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }, 1000);
  }
}

function handleDownloadMaterial() {
  const modal = bootstrap.Modal.getInstance(document.getElementById('eventModal'));
  const event = modal.currentEvent;
  
  if (event) {
    // Create a mock material download
    const domain = event.extendedProps.category || 'generativeAI';
    const materials = getMaterialsForDomain(domain);
    
    // Create a zip-like structure (for demo, we'll create individual files)
    materials.forEach((material, index) => {
      setTimeout(() => {
        const blob = new Blob([material.content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = material.filename;
        link.click();
        
        URL.revokeObjectURL(url);
      }, index * 500); // Stagger downloads
    });
    
    showAlert(`📥 Downloading ${materials.length} training materials for ${eventCategories[domain]?.name || domain}`, 'success', 4000);
  }
}

function getMaterialsForDomain(domain) {
  const materialsByDomain = {
    generativeAI: [
      {
        filename: 'GenAI_Introduction.pdf',
        content: 'Generative AI Introduction - Fundamentals of machine learning and neural networks...'
      },
      {
        filename: 'GenAI_Practical_Exercises.docx',
        content: 'Hands-on exercises for Generative AI training...'
      },
      {
        filename: 'GenAI_Resources.txt',
        content: 'Additional resources and reading materials for Generative AI...'
      }
    ],
    containerization: [
      {
        filename: 'Docker_Fundamentals.pdf',
        content: 'Docker containerization fundamentals and best practices...'
      },
      {
        filename: 'Kubernetes_Guide.pdf',
        content: 'Kubernetes orchestration and deployment strategies...'
      },
      {
        filename: 'Container_Labs.zip',
        content: 'Practical lab exercises for container technologies...'
      }
    ],
    devOps: [
      {
        filename: 'DevOps_Principles.pdf',
        content: 'Core DevOps principles and methodologies...'
      },
      {
        filename: 'CI_CD_Pipeline_Setup.md',
        content: 'Step-by-step guide to setting up CI/CD pipelines...'
      },
      {
        filename: 'DevOps_Tools_Comparison.xlsx',
        content: 'Comparison of popular DevOps tools and platforms...'
      }
    ],
    testAutomation: [
      {
        filename: 'Test_Automation_Framework.pdf',
        content: 'Building robust test automation frameworks...'
      },
      {
        filename: 'Selenium_WebDriver_Guide.pdf',
        content: 'Comprehensive Selenium WebDriver tutorial...'
      },
      {
        filename: 'API_Testing_Strategies.docx',
        content: 'Best practices for API testing and automation...'
      }
    ]
  };
  
  return materialsByDomain[domain] || materialsByDomain.generativeAI;
}

function handleShareEvent() {
  const modal = bootstrap.Modal.getInstance(document.getElementById('eventModal'));
  const event = modal.currentEvent;
  
  if (event) {
    // Create Outlook email with event details
    const startDate = new Date(event.start);
    const endDate = event.end ? new Date(event.end) : null;
    
    const emailSubject = encodeURIComponent(`Training Session: ${event.title}`);
    
    const meetingLink = event.extendedProps.webexLink ? `🔗 Meeting Link: ${event.extendedProps.webexLink}` : '';
    const emailBody = encodeURIComponent(`Hi,

I wanted to share this training session with you:

📅 Event: ${event.title}
📝 Description: ${event.extendedProps.description || 'No description available'}
👨‍🏫 Trainer: ${event.extendedProps.trainer || 'TBD'}
📍 Location: ${event.extendedProps.location || 'Virtual'}
🕐 Date & Time: ${formatEventDateTime(startDate, endDate)}
🎯 Domain: ${eventCategories[event.extendedProps.category]?.name || 'Training'}
📚 Session Type: ${event.extendedProps.sessionType || 'Training Session'}

${meetingLink}

This is part of our 6-week training program (September 1 - October 15, 2025).

Best regards`);
    
    // Create Outlook email URLs
    const outlookWebUrl = `https://outlook.live.com/mail/0/deeplink/compose?subject=${emailSubject}&body=${emailBody}`;
    const outlookDesktopUrl = `outlook://mail/action/compose?subject=${emailSubject}&body=${emailBody}`;
    
    // Try to open Outlook email
    try {
      // Try desktop Outlook first
      window.location.href = outlookDesktopUrl;
      
      // Fallback to web Outlook after a short delay
      setTimeout(() => {
        window.open(outlookWebUrl, '_blank');
      }, 1000);
      
      showAlert('📧 Opening Outlook email... If Outlook app doesn\'t open, check your browser for the web version.', 'success', 5000);
    } catch (error) {
      console.warn('Outlook desktop not available, using web version:', error);
      // Direct fallback to web Outlook
      window.open(outlookWebUrl, '_blank');
      showAlert('📧 Opening Outlook email in browser...', 'success', 3000);
    }
    
    // Fallback: copy to clipboard
    const meetingLinkText = event.extendedProps.webexLink ? `Meeting Link: ${event.extendedProps.webexLink}` : '';
    const shareText = `Training Session: ${event.title}
Date: ${formatEventDateTime(startDate, endDate)}
Trainer: ${event.extendedProps.trainer || 'TBD'}
Location: ${event.extendedProps.location || 'Virtual'}
${meetingLinkText}`;
    
    navigator.clipboard.writeText(shareText).then(() => {
      console.log('Event details copied to clipboard as backup');
    }).catch(() => {
      console.log('Clipboard copy failed, but Outlook should handle sharing');
    });
  }
}

// Utility functions
function formatEventDateTime(startDate, endDate = null) {
  const options = {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  };
  
  let formatted = startDate.toLocaleDateString('en-US', options);
  
  if (endDate && endDate.getTime() !== startDate.getTime()) {
    const endOptions = {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    };
    formatted += ` - ${endDate.toLocaleString('en-US', endOptions)}`;
  }
  
  return formatted;
}

function generateICSContent(event) {
  const startDate = new Date(event.start);
  const endDate = event.end ? new Date(event.end) : new Date(startDate.getTime() + 60 * 60 * 1000);
  
  const formatICSDate = (date) => {
    return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
  };
  
  return `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//SharePoint Calendar//EN
BEGIN:VEVENT
UID:${event.id}@sharepointcalendar
DTSTAMP:${formatICSDate(new Date())}
DTSTART:${formatICSDate(startDate)}
DTEND:${formatICSDate(endDate)}
SUMMARY:${event.title}
DESCRIPTION:${event.extendedProps.description || ''}
LOCATION:${event.extendedProps.location || ''}
END:VEVENT
END:VCALENDAR`;
}

// Enhanced alert system using Bootstrap
function showAlert(message, type = 'info', duration = 5000) {
  const alertContainer = document.getElementById('alertContainer');
  const alertId = 'alert_' + Date.now();
  
  const alertHTML = `
    <div class="alert alert-${type} alert-dismissible fade show slide-up" role="alert" id="${alertId}">
      <i class="bi bi-${getAlertIcon(type)} me-2"></i>
      ${message}
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  `;
  
  alertContainer.insertAdjacentHTML('beforeend', alertHTML);
  
  // Auto-dismiss after duration
  if (duration > 0) {
    setTimeout(() => {
      const alert = document.getElementById(alertId);
      if (alert) {
        const bsAlert = new bootstrap.Alert(alert);
        bsAlert.close();
      }
    }, duration);
  }
}

function getAlertIcon(type) {
  const icons = {
    success: 'check-circle-fill',
    danger: 'exclamation-triangle-fill',
    warning: 'exclamation-triangle-fill',
    info: 'info-circle-fill'
  };
  return icons[type] || 'info-circle-fill';
}

function hideAllAlerts() {
  const alerts = document.querySelectorAll('#alertContainer .alert');
  alerts.forEach(alert => {
    const bsAlert = new bootstrap.Alert(alert);
    bsAlert.close();
  });
}

function showLoading(show = true) {
  const loadingElement = document.getElementById('loadingMessage');
  if (loadingElement) {
    loadingElement.style.display = show ? 'block' : 'none';
  }
}

// Initialize Bootstrap components
function initializeBootstrapComponents() {
  // Initialize tooltips
  const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });
  
  // Initialize popovers
  const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
  popoverTriggerList.map(function (popoverTriggerEl) {
    return new bootstrap.Popover(popoverTriggerEl);
  });
}

// New event dialog (placeholder for future enhancement)
function showNewEventDialog(start, end) {
  showAlert('Event creation feature coming soon! 🚀', 'info', 3000);
}

// Export calendar data
function exportCalendarData() {
  const events = calendar.getEvents();
  const exportData = events.map(event => ({
    title: event.title,
    start: event.start,
    end: event.end,
    description: event.extendedProps.description,
    location: event.extendedProps.location,
    trainer: event.extendedProps.trainer
  }));
  
  const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = 'calendar_events.json';
  link.click();
  
  URL.revokeObjectURL(url);
  showAlert('Calendar data exported successfully!', 'success', 3000);
}

// SharePoint data functions - Real SharePoint integration
async function fetchSharePointListItems() {
  try {
    console.log('🔄 Fetching events from SharePoint list...');
    
    // Construct SharePoint REST API URL
    const fieldsSelect = sharePointConfig.fields.join(',');
    const apiUrl = `${sharePointConfig.siteUrl}/_api/web/lists/getbytitle('${sharePointConfig.listName}')/items?$select=${fieldsSelect}&$orderby=EventDate asc`;
    
    // Make the API call
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json;odata=verbose',
        'Content-Type': 'application/json;odata=verbose'
      },
      credentials: 'same-origin'
    });

    if (!response.ok) {
      throw new Error(`SharePoint API Error: ${response.status} - ${response.statusText}`);
    }

    const data = await response.json();
    const events = data.d.results;

    console.log(`✅ Successfully loaded ${events.length} events from SharePoint`);
    
    // Transform SharePoint data to calendar format
    return transformSharePointData(events);
    
  } catch (error) {
    console.error('❌ Error fetching from SharePoint:', error);
    
    // Fallback to mock data with user notification
    showAlert('Unable to connect to SharePoint. Using sample data for demonstration.', 'warning', 5000);
    return getEnhancedMockEvents();
  }
}

// Transform SharePoint list data to FullCalendar format
function transformSharePointData(sharePointEvents) {
  return sharePointEvents.map(spEvent => {
    return {
      Id: spEvent.Id,
      Title: spEvent.Title,
      Description: spEvent.Description || '',
      EventDate: spEvent.EventDate,
      EndDate: spEvent.EndDate,
      TrainerDetails: spEvent.TrainerDetails || '',
      WebExLink: spEvent.WebExLink || '',
      Location: spEvent.Location || '',
      Category: spEvent.Category || 'generativeAI',
      SessionType: spEvent.SessionType || '',
      WeekNumber: spEvent.WeekNumber || 1,
      DayNumber: spEvent.DayNumber || 1,
      Materials: spEvent.Materials || ''
    };
  });
}

// Create SharePoint list item (for future enhancement)
async function createSharePointEvent(eventData) {
  try {
    const apiUrl = `${sharePointConfig.siteUrl}/_api/web/lists/getbytitle('${sharePointConfig.listName}')/items`;
    
    // Get form digest for authentication
    const digestResponse = await fetch(`${sharePointConfig.siteUrl}/_api/contextinfo`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json;odata=verbose',
        'Content-Type': 'application/json;odata=verbose'
      },
      credentials: 'same-origin'
    });
    
    const digestData = await digestResponse.json();
    const formDigest = digestData.d.GetContextWebInformation.FormDigestValue;
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Accept': 'application/json;odata=verbose',
        'Content-Type': 'application/json;odata=verbose',
        'X-RequestDigest': formDigest
      },
      credentials: 'same-origin',
      body: JSON.stringify({
        '__metadata': { 'type': 'SP.Data.TrainingEventsListItem' },
        'Title': eventData.Title,
        'Description': eventData.Description,
        'EventDate': eventData.EventDate,
        'EndDate': eventData.EndDate,
        'TrainerDetails': eventData.TrainerDetails,
        'WebExLink': eventData.WebExLink,
        'Location': eventData.Location,
        'Category': eventData.Category
      })
    });

    if (!response.ok) {
      throw new Error(`Failed to create event: ${response.statusText}`);
    }

    const result = await response.json();
    console.log('✅ Event created successfully:', result.d);
    return result.d;
    
  } catch (error) {
    console.error('❌ Error creating SharePoint event:', error);
    throw error;
  }
}

// Update SharePoint list item (for future enhancement)
async function updateSharePointEvent(eventId, eventData) {
  try {
    const apiUrl = `${sharePointConfig.siteUrl}/_api/web/lists/getbytitle('${sharePointConfig.listName}')/items(${eventId})`;
    
    // Get form digest and current item etag
    const digestResponse = await fetch(`${sharePointConfig.siteUrl}/_api/contextinfo`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json;odata=verbose',
        'Content-Type': 'application/json;odata=verbose'
      },
      credentials: 'same-origin'
    });
    
    const digestData = await digestResponse.json();
    const formDigest = digestData.d.GetContextWebInformation.FormDigestValue;
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Accept': 'application/json;odata=verbose',
        'Content-Type': 'application/json;odata=verbose',
        'X-RequestDigest': formDigest,
        'X-HTTP-Method': 'MERGE',
        'If-Match': '*'
      },
      credentials: 'same-origin',
      body: JSON.stringify({
        '__metadata': { 'type': 'SP.Data.TrainingEventsListItem' },
        'Title': eventData.Title,
        'Description': eventData.Description,
        'EventDate': eventData.EventDate,
        'EndDate': eventData.EndDate,
        'TrainerDetails': eventData.TrainerDetails,
        'WebExLink': eventData.WebExLink,
        'Location': eventData.Location,
        'Category': eventData.Category
      })
    });

    if (!response.ok) {
      throw new Error(`Failed to update event: ${response.statusText}`);
    }

    console.log('✅ Event updated successfully');
    return true;
    
  } catch (error) {
    console.error('❌ Error updating SharePoint event:', error);
    throw error;
  }
}

// Enhanced mock data with 6-week training program (Sep 1 - Oct 15, 2025)
function getEnhancedMockEvents() {
  const programStart = new Date('2025-09-01T09:30:00');
  const events = [];
  let eventId = 1;

  // 6-week program: Sep 1 - Oct 15, 2025
  // All four domains run simultaneously every day
  const domains = [
    { key: 'generativeAI', name: 'Generative AI', trainer: 'Dr. Sarah Chen - AI Research Scientist, OpenAI Expert', room: 'A', webexId: 'genai-training' },
    { key: 'containerization', name: 'Containerization', trainer: 'Mike Rodriguez - DevOps Architect, Docker & Kubernetes Expert', room: 'B', webexId: 'container-training' },
    { key: 'devOps', name: 'DevOps', trainer: 'Jennifer Williams - DevOps Lead, Azure DevOps MVP', room: 'C', webexId: 'devops-training' },
    { key: 'testAutomation', name: 'Test Automation', trainer: 'Alex Thompson - QA Automation Expert, Selenium Specialist', room: 'D', webexId: 'testautomation-training' }
  ];

  // Generate events for 6 weeks (30 weekdays)
  for (let week = 0; week < 6; week++) {
    for (let day = 0; day < 7; day++) {
      // Skip weekends
      if (day === 5 || day === 6) continue;

      const currentDate = new Date(programStart);
      currentDate.setDate(programStart.getDate() + (week * 7) + day);
      
      // Skip if beyond Oct 15, 2025
      if (currentDate > new Date('2025-10-15')) break;

      // Create sessions for ALL FOUR domains on the same day
      domains.forEach((domain, domainIndex) => {
        const sessionStart = new Date(currentDate);
        sessionStart.setHours(9, 30, 0, 0);
        
        const sessionEnd = new Date(sessionStart);
        sessionEnd.setHours(13, 30, 0, 0);

        // Determine session type based on week
        let sessionType = '';
        let description = '';
        
        if (week < 2) {
          sessionType = 'Fundamentals';
          description = `Introduction to ${domain.name} fundamentals, core concepts, and basic principles. Hands-on exercises and interactive learning.`;
        } else if (week < 4) {
          sessionType = 'Advanced Concepts';
          description = `Advanced ${domain.name} techniques, best practices, and real-world applications. In-depth workshops and case studies.`;
        } else {
          sessionType = 'Practical Implementation';
          description = `Practical implementation of ${domain.name} solutions. Project-based learning and final assessments.`;
        }

        // Format date for WebEx link uniqueness
        const dateStr = currentDate.toISOString().slice(0, 10);

        events.push({
          Id: eventId++,
          Title: `${domain.name} - ${sessionType}`,
          Description: description,
          EventDate: sessionStart.toISOString(),
          EndDate: sessionEnd.toISOString(),
          TrainerDetails: domain.trainer,
          WebExLink: `https://meet.webex.com/meet/${domain.webexId}-${dateStr}`,
          Location: `Training Room ${domain.room} / Virtual Hybrid`,
          Category: domain.key
        });
      });
    }
  }

  // Add some special events
  events.push({
    Id: eventId++,
    Title: 'Program Kickoff - Welcome & Orientation',
    Description: 'Welcome session for the 6-week training program. Program overview, schedule, expectations, room assignments, and networking session.',
    EventDate: new Date('2025-09-01T08:30:00').toISOString(),
    EndDate: new Date('2025-09-01T09:30:00').toISOString(),
    TrainerDetails: 'Program Director - Linda Foster, All Domain Trainers',
    WebExLink: 'https://meet.webex.com/meet/program-kickoff-2025',
    Location: 'Main Auditorium / Virtual',
    Category: 'generativeAI'
  });

  events.push({
    Id: eventId++,
    Title: 'All Domains - Mid-Program Assessment',
    Description: 'Comprehensive mid-program assessment covering all four domains. Individual and cross-domain evaluation sessions.',
    EventDate: new Date('2025-09-22T14:00:00').toISOString(),
    EndDate: new Date('2025-09-22T17:00:00').toISOString(),
    TrainerDetails: 'Assessment Team - All Domain Trainers & External Evaluators',
    WebExLink: 'https://meet.webex.com/meet/mid-program-assessment-2025',
    Location: 'Assessment Center (All Rooms A-D) / Virtual',
    Category: 'testAutomation'
  });

  events.push({
    Id: eventId++,
    Title: 'Final Projects & Graduation Ceremony',
    Description: 'Final project presentations from all domains with cross-domain integration showcase. Certification ceremony and program completion celebration.',
    EventDate: new Date('2025-10-15T14:00:00').toISOString(),
    EndDate: new Date('2025-10-15T17:00:00').toISOString(),
    TrainerDetails: 'All Domain Trainers, Program Leadership & Industry Experts',
    WebExLink: 'https://meet.webex.com/meet/final-presentations-graduation-2025',
    Location: 'Grand Auditorium / Virtual Livestream',
    Category: 'devOps'
  });

  return events;
}

// Auto-refresh functionality
function startAutoRefresh() {
  setInterval(async function() {
    if (calendar) {
      try {
        await loadEvents();
        console.log('🔄 Events refreshed automatically at', new Date().toLocaleTimeString());
      } catch (error) {
        console.error('❌ Auto-refresh failed:', error);
      }
    }
  }, 5 * 60 * 1000); // 5 minutes
}

// Start auto-refresh when app loads
document.addEventListener('DOMContentLoaded', function() {
  startAutoRefresh();
});

// Export functions for testing
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    formatEventDateTime,
    getEnhancedMockEvents,
    sharePointConfig
  };
}
