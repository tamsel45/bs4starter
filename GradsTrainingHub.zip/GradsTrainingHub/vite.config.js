import { defineConfig } from 'vite'

export default defineConfig({
  root: './',
  build: {
    outDir: 'dist',
    rollupOptions: {
      input: {
        main: './index.html'
      }
    }
  },
  server: {
    port: 3001,
    open: true
  },
  css: {
    devSourcemap: true
  },
  optimizeDeps: {
    include: ['chart.js', 'chartjs-adapter-date-fns', 'date-fns', 'flatpickr']
  }
})
