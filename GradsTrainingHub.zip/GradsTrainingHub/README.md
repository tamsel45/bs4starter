# Campus Training Program Portal

A comprehensive web-based portal for managing a 6-week training program across four technology domains: Generative AI, Containerization, DevOps, and Test Automation.

## Features

### 🎯 Core Modules
- **Training Calendar** - Schedule and manage daily training sessions
- **Attendance Tracker** - Monitor student attendance with WebEx integration
- **Trainer Availability** - Track trainer schedules and availability
- **Assignments & Quizzes** - Manage coursework and assessments
- **Student Progress** - Monitor individual and overall progress
- **Lab Requirements** - Track technical setup and requirements
- **Reports** - Generate comprehensive program reports

### 👥 Role-Based Access
- **Admins** - Full access to all modules and features
- **Trainers** - Access to calendar, attendance, and content upload
- **Students** - View schedules, submit assignments, check progress
- **Program Coordinators** - Manage reports and track overall progress

### 📊 Key Capabilities
- Real-time progress tracking across 68 students
- 60 trainer management (20 Senior, 40 Mid-Level)
- 480 total training hours across 6 weeks
- Automated attendance marking via WebEx integration
- Comprehensive reporting and analytics

## Technology Stack

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Styling**: Custom CSS with responsive design
- **Icons**: Font Awesome 6.0
- **Charts**: Custom canvas-based charting
- **Deployment**: SharePoint-compatible static files

## File Structure

```
training-portal/
├── index.html              # Main application file
├── css/
│   └── styles.css          # Complete styling
├── js/
│   ├── app.js             # Core application logic
│   ├── calendar.js        # Calendar management
│   ├── attendance.js      # Attendance tracking
│   ├── progress.js        # Progress monitoring
│   └── reports.js         # Report generation
└── README.md              # This file
```

## SharePoint Deployment Guide

### Method 1: SharePoint Online (Modern)

1. **Upload Files to Document Library**
   ```
   1. Go to your SharePoint site
   2. Create a new Document Library called "TrainingPortal"
   3. Upload all files maintaining the folder structure
   4. Note the public URL of index.html
   ```

2. **Create a SharePoint Page**
   ```
   1. Create a new SharePoint page
   2. Add a "File viewer" or "Embed" web part
   3. Point it to your uploaded index.html file
   4. Publish the page
   ```

### Method 2: SharePoint App Catalog

1. **Package as SharePoint Solution**
   ```
   1. Create a SharePoint Framework (SPFx) solution
   2. Copy the HTML, CSS, and JS files into the solution
   3. Build and package the solution
   4. Deploy to App Catalog
   ```

### Method 3: Site Assets Library

1. **Upload to Site Assets**
   ```
   1. Go to Site Contents → Site Assets
   2. Upload all files maintaining structure
   3. Access via: https://[tenant].sharepoint.com/sites/[site]/SiteAssets/index.html
   ```

## Local Development Setup

1. **Clone or Download Files**
   ```bash
   # Download all files to a local directory
   # No build process required - pure HTML/CSS/JS
   ```

2. **Serve Locally**
   ```bash
   # Option 1: Python HTTP Server
   python -m http.server 8000
   
   # Option 2: Node.js HTTP Server
   npx http-server
   
   # Option 3: VS Code Live Server Extension
   # Right-click index.html → "Open with Live Server"
   ```

3. **Access Application**
   ```
   Open browser to: http://localhost:8000
   ```

## Configuration

### 1. User Roles & Permissions
Edit the `currentUser` object in `js/app.js`:
```javascript
let currentUser = {
    name: 'Your Name',
    role: 'Admin', // Admin, Trainer, Student, Coordinator
    id: 'user001'
};
```

### 2. Training Dates
Update training dates in `js/calendar.js`:
```javascript
const startDate = new Date('2025-09-01'); // Adjust start date
const totalWeeks = 6; // Adjust program duration
```

### 3. Domains & Data
Modify training domains and sample data in `js/app.js`:
```javascript
// Update trainers array
trainers = [
    { id: 1, name: 'Your Trainer', designation: 'Role', ... }
];

// Update students array
students = [
    { id: 1, name: 'Student Name', email: 'email@domain.com', ... }
];
```

## SharePoint Integration Features

### Lists Integration (Future Enhancement)
The portal is designed to integrate with SharePoint lists:

1. **Training Sessions List**
   - Store session details, trainer assignments
   - Link WebEx meetings and materials

2. **Attendance List**
   - Automatic attendance from WebEx
   - Manual override capabilities

3. **Student Progress List**
   - Weekly progress tracking
   - Domain-wise completion status

4. **Assignments List**
   - Assignment creation and submission tracking
   - Automated scoring integration

### WebEx Integration
Configure WebEx API integration for automatic attendance:
```javascript
// In attendance.js, update WebEx API settings
const webexConfig = {
    apiKey: 'your-webex-api-key',
    meetingAPI: 'https://webexapis.com/v1/meetings'
};
```

## Customization Guide

### 1. Branding
Update colors and branding in `css/styles.css`:
```css
:root {
    --primary-color: #667eea;
    --secondary-color: #764ba2;
    --success-color: #28a745;
    /* Add your organization colors */
}
```

### 2. Add New Modules
1. Create HTML section in `index.html`
2. Add navigation item
3. Create corresponding JavaScript file
4. Import styles in `styles.css`

### 3. Modify Dashboard Cards
Edit the stats grid in `index.html`:
```html
<div class="stat-card">
    <div class="stat-icon">
        <i class="fas fa-your-icon"></i>
    </div>
    <div class="stat-info">
        <h3>Your Number</h3>
        <p>Your Metric</p>
    </div>
</div>
```

## Browser Compatibility

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ✅ SharePoint Online
- ✅ SharePoint 2019

## Security Considerations

1. **Authentication**: Relies on SharePoint authentication
2. **Authorization**: Role-based access in JavaScript (client-side)
3. **Data Protection**: All data stored in browser localStorage/SharePoint lists
4. **HTTPS**: Ensure deployment over HTTPS

## Performance Optimization

- Minified CSS and JavaScript for production
- Lazy loading of chart data
- Efficient DOM manipulation
- Responsive design for mobile devices

## Troubleshooting

### Common Issues

1. **File Access Denied**
   - Check SharePoint permissions
   - Ensure proper file sharing settings

2. **JavaScript Errors**
   - Check browser console for errors
   - Verify all JS files are loaded correctly

3. **Styling Issues**
   - Clear browser cache
   - Check CSS file paths

4. **SharePoint Integration**
   - Verify SharePoint Online vs On-Premises compatibility
   - Check Content Security Policy settings

## Support & Updates

For technical support or feature requests:
1. Check browser console for errors
2. Verify SharePoint permissions
3. Review deployment configuration
4. Contact system administrator

## Version History

- **v1.0** - Initial release with core modules
- **v1.1** - Added reports and enhanced UI
- **v1.2** - SharePoint integration improvements

---

**Note**: This portal is designed specifically for SharePoint deployment and the Campus Training Program described in the requirements. Customize as needed for your specific environment and requirements.
