// Calendar Module
let currentWeek = 1;
const totalWeeks = 6;
const weekDates = generateWeekDates();

function generateWeekDates() {
    const weeks = [];
    const startDate = new Date('2025-09-01'); // September 1st, 2025
    
    for (let week = 0; week < totalWeeks; week++) {
        const weekStart = new Date(startDate);
        weekStart.setDate(startDate.getDate() + (week * 7));
        
        const weekDays = [];
        for (let day = 0; day < 5; day++) { // Monday to Friday
            const currentDay = new Date(weekStart);
            currentDay.setDate(weekStart.getDate() + day);
            weekDays.push(currentDay);
        }
        
        weeks.push({
            number: week + 1,
            days: weekDays,
            label: `Week ${week + 1}: ${formatDateRange(weekDays[0], weekDays[4])}`
        });
    }
    
    return weeks;
}

function formatDateRange(startDate, endDate) {
    const options = { month: 'short', day: 'numeric' };
    const start = startDate.toLocaleDateString('en-US', options);
    const end = endDate.toLocaleDateString('en-US', options);
    const year = startDate.getFullYear();
    return `${start}-${end}, ${year}`;
}

function loadCalendar() {
    updateCalendarHeader();
    renderCalendarGrid();
}

function updateCalendarHeader() {
    const headerElement = document.getElementById('currentWeek');
    if (headerElement && weekDates[currentWeek - 1]) {
        headerElement.textContent = weekDates[currentWeek - 1].label;
    }
}

function renderCalendarGrid() {
    const calendarGrid = document.getElementById('calendarGrid');
    if (!calendarGrid) return;

    const currentWeekData = weekDates[currentWeek - 1];
    if (!currentWeekData) return;

    calendarGrid.innerHTML = '';

    // Day headers
    const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    dayNames.forEach(dayName => {
        const dayHeader = document.createElement('div');
        dayHeader.className = 'calendar-day-header';
        dayHeader.innerHTML = `<strong>${dayName}</strong>`;
        dayHeader.style.cssText = `
            background: #667eea;
            color: white;
            padding: 15px;
            text-align: center;
            font-weight: 600;
        `;
        calendarGrid.appendChild(dayHeader);
    });

    // Day content
    currentWeekData.days.forEach((date, index) => {
        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-day';
        
        const dayDate = date.getDate();
        const dayMonth = date.toLocaleDateString('en-US', { month: 'short' });
        
        const sessionsForDay = getSessionsForDate(date);
        
        dayElement.innerHTML = `
            <div class="day-header">
                ${dayDate} ${dayMonth}
            </div>
            <div class="day-sessions">
                ${sessionsForDay.map(session => `
                    <div class="session-item" onclick="viewSession(${session.id})" data-domain="${session.domain}">
                        <div class="session-time">${formatTime(session.startTime)} - ${formatTime(session.endTime)}</div>
                        <div class="session-title">${session.title}</div>
                        <div class="session-trainer">${session.trainer}</div>
                        <div class="session-domain">${getDomainDisplayName(session.domain)}</div>
                    </div>
                `).join('')}
                <button class="add-session-btn" onclick="addSessionForDate('${date.toISOString().split('T')[0]}')" title="Add Session">
                    <i data-lucide="plus"></i>
                </button>
            </div>
        `;

        calendarGrid.appendChild(dayElement);
    });
}

function getSessionsForDate(date) {
    const dateString = date.toISOString().split('T')[0];
    return trainingSessions.filter(session => session.date === dateString);
}

function getDomainDisplayName(domain) {
    const domainMap = {
        'generative-ai': 'Gen AI',
        'containerization': 'Containers',
        'devops': 'DevOps',
        'test-automation': 'Test Auto'
    };
    return domainMap[domain] || domain;
}

function previousWeek() {
    if (currentWeek > 1) {
        currentWeek--;
        loadCalendar();
    }
}

function nextWeek() {
    if (currentWeek < totalWeeks) {
        currentWeek++;
        loadCalendar();
    }
}

function addSessionForDate(date) {
    // Pre-fill the date in the modal
    document.getElementById('sessionDate').value = date;
    openModal('sessionModal');
}

function viewSession(sessionId) {
    const session = trainingSessions.find(s => s.id === sessionId);
    if (!session) return;

    const modalContent = `
        <div class="session-detail-modal">
            <h3>${session.title}</h3>
            <div class="session-info">
                <p><strong>Domain:</strong> ${getDomainDisplayName(session.domain)}</p>
                <p><strong>Date:</strong> ${formatDate(session.date)}</p>
                <p><strong>Time:</strong> ${formatTime(session.startTime)} - ${formatTime(session.endTime)}</p>
                <p><strong>Trainer:</strong> ${session.trainer}</p>
                ${session.webexLink ? `<p><strong>WebEx:</strong> <a href="${session.webexLink}" target="_blank">Join Meeting</a></p>` : ''}
            </div>
            ${session.materials && session.materials.length > 0 ? `
                <div class="session-materials">
                    <h4>Materials:</h4>
                    <ul>
                        ${session.materials.map(material => `<li>${material}</li>`).join('')}
                    </ul>
                </div>
            ` : ''}
            <div class="session-actions">
                <button class="btn btn-secondary" onclick="closeModal()">Close</button>
                <button class="btn btn-primary" onclick="editSession(${sessionId})">Edit Session</button>
                <button class="btn btn-danger" onclick="deleteSession(${sessionId})">Delete Session</button>
            </div>
        </div>
    `;

    // Create and show modal
    showSessionDetailModal(modalContent);
}

function showSessionDetailModal(content) {
    // Remove existing detail modal if any
    const existingModal = document.getElementById('sessionDetailModal');
    if (existingModal) {
        existingModal.remove();
    }

    // Create new modal
    const modal = document.createElement('div');
    modal.id = 'sessionDetailModal';
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>Session Details</h3>
                <button class="close-btn" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                ${content}
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    
    // Show modal
    document.getElementById('modalOverlay').classList.add('show');
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
}

function editSession(sessionId) {
    const session = trainingSessions.find(s => s.id === sessionId);
    if (!session) return;

    // Pre-fill the form with session data
    document.getElementById('sessionTitle').value = session.title;
    document.getElementById('sessionDomain').value = session.domain;
    document.getElementById('sessionDate').value = session.date;
    document.getElementById('sessionTrainer').value = session.trainerId;
    document.getElementById('webexLink').value = session.webexLink || '';

    // Store the session ID for updating
    document.getElementById('sessionForm').dataset.sessionId = sessionId;

    closeModal();
    openModal('sessionModal');
}

function deleteSession(sessionId) {
    if (confirm('Are you sure you want to delete this session?')) {
        const index = trainingSessions.findIndex(s => s.id === sessionId);
        if (index !== -1) {
            trainingSessions.splice(index, 1);
            closeModal();
            loadCalendar();
            showNotification('Session deleted successfully!', 'success');
        }
    }
}

// Domain filtering
function filterByDomain() {
    const selectedDomain = document.getElementById('domainFilter').value;
    const sessionItems = document.querySelectorAll('.session-item');
    
    sessionItems.forEach(item => {
        if (!selectedDomain || item.dataset.domain === selectedDomain) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

// Event listeners for calendar
document.addEventListener('DOMContentLoaded', function() {
    const domainFilter = document.getElementById('domainFilter');
    if (domainFilter) {
        domainFilter.addEventListener('change', filterByDomain);
    }
});

// Enhanced session form submission
function saveSession() {
    const form = document.getElementById('sessionForm');
    const formData = new FormData(form);
    const sessionId = form.dataset.sessionId;

    const sessionData = {
        title: formData.get('sessionTitle') || document.getElementById('sessionTitle').value,
        domain: formData.get('sessionDomain') || document.getElementById('sessionDomain').value,
        date: formData.get('sessionDate') || document.getElementById('sessionDate').value,
        startTime: '09:30',
        endTime: '13:30',
        trainer: trainers.find(t => t.id == (formData.get('sessionTrainer') || document.getElementById('sessionTrainer').value))?.name || '',
        trainerId: parseInt(formData.get('sessionTrainer') || document.getElementById('sessionTrainer').value),
        webexLink: formData.get('webexLink') || document.getElementById('webexLink').value,
        materials: []
    };

    if (sessionId) {
        // Update existing session
        const index = trainingSessions.findIndex(s => s.id == sessionId);
        if (index !== -1) {
            trainingSessions[index] = { ...trainingSessions[index], ...sessionData };
            showNotification('Session updated successfully!', 'success');
        }
        delete form.dataset.sessionId;
    } else {
        // Create new session
        sessionData.id = trainingSessions.length + 1;
        trainingSessions.push(sessionData);
        showNotification('Session added successfully!', 'success');
    }

    form.reset();
    closeModal();
    loadCalendar();
}

// Add CSS for calendar enhancements
const calendarStyles = `
    .calendar-day-header {
        background: #667eea;
        color: white;
        padding: 15px;
        text-align: center;
        font-weight: 600;
    }

    .session-item {
        background: #f0f2ff;
        padding: 10px;
        border-radius: 6px;
        border-left: 4px solid #667eea;
        margin-bottom: 8px;
        cursor: pointer;
        transition: all 0.3s ease;
        font-size: 0.85rem;
    }

    .session-item:hover {
        background: #e6e9ff;
        transform: translateX(3px);
    }

    .session-time {
        font-weight: 600;
        color: #667eea;
        margin-bottom: 4px;
    }

    .session-title {
        font-weight: 600;
        color: #333;
        margin-bottom: 4px;
    }

    .session-trainer {
        color: #666;
        font-size: 0.8rem;
        margin-bottom: 4px;
    }

    .session-domain {
        background: #667eea;
        color: white;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 0.7rem;
        display: inline-block;
    }

    .add-session-btn {
        background: #f8f9fa;
        border: 2px dashed #ccc;
        color: #666;
        width: 100%;
        padding: 20px;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.3s ease;
        margin-top: 10px;
    }

    .add-session-btn:hover {
        background: #e9ecef;
        border-color: #667eea;
        color: #667eea;
    }

    .session-detail-modal {
        max-width: 500px;
    }

    .session-info p {
        margin-bottom: 10px;
    }

    .session-materials {
        margin: 20px 0;
    }

    .session-materials ul {
        list-style: none;
        padding: 0;
    }

    .session-materials li {
        background: #f8f9fa;
        padding: 8px 12px;
        border-radius: 4px;
        margin-bottom: 5px;
        border-left: 3px solid #667eea;
    }

    .session-actions {
        display: flex;
        gap: 10px;
        justify-content: flex-end;
        margin-top: 25px;
        padding-top: 20px;
        border-top: 1px solid #e0e0e0;
    }

    .btn-danger {
        background: #dc3545;
        color: white;
    }

    .btn-danger:hover {
        background: #c82333;
    }
`;

// Inject calendar styles
if (!document.getElementById('calendar-styles')) {
    const styleSheet = document.createElement('style');
    styleSheet.id = 'calendar-styles';
    styleSheet.textContent = calendarStyles;
    document.head.appendChild(styleSheet);
}
