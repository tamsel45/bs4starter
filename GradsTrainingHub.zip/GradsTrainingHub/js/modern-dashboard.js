// Modern Training Portal Dashboard JavaScript
// Comprehensive role-based functionality with modern UI components

// Enhanced Master Data with complete structure
const masterData = {
    program: {
        name: "Campus Training Program 2025",
        startDate: "2025-09-01",
        endDate: "2025-10-15",
        totalParticipants: 68,
        totalTrainers: 24,
        domains: ["Generative AI", "Containerization", "DevOps", "Test Automation"]
    },
    
    roles: {
        admin: { name: "John Doe", title: "Program Administrator", avatar: "JD" },
        coordinator: { name: "Sarah Johnson", title: "Program Coordinator", avatar: "SJ" },
        trainer: { name: "Mike Chen", title: "Senior Trainer", avatar: "MC" },
        grad: { name: "Lisa Wang", title: "Graduate Trainee", avatar: "LW" }
    },
    
    graduates: [
        { id: "GR001", name: "Alex Rivera", domain: "Generative AI", progress: 85, attendance: 92, lastActive: "2 hours ago" },
        { id: "GR002", name: "Sam Patel", domain: "Containerization", progress: 78, attendance: 88, lastActive: "4 hours ago" },
        { id: "GR003", name: "Jordan Kim", domain: "DevOps", progress: 91, attendance: 95, lastActive: "1 hour ago" },
        { id: "GR004", name: "Taylor Swift", domain: "Test Automation", progress: 73, attendance: 85, lastActive: "6 hours ago" },
        { id: "GR005", name: "Morgan Lee", domain: "Generative AI", progress: 67, attendance: 79, lastActive: "3 hours ago" },
        { id: "GR006", name: "Casey Brown", domain: "DevOps", progress: 89, attendance: 93, lastActive: "30 min ago" },
        { id: "GR007", name: "Riley Davis", domain: "Containerization", progress: 82, attendance: 87, lastActive: "5 hours ago" },
        { id: "GR008", name: "Avery Wilson", domain: "Test Automation", progress: 76, attendance: 84, lastActive: "2 hours ago" }
    ],
    
    sessions: [
        {
            id: "S001",
            title: "Advanced Prompt Engineering",
            domain: "Generative AI",
            trainer: "Dr. Emily Watson",
            date: "2025-08-13",
            time: "09:00",
            duration: "2 hours",
            attendees: 18,
            status: "ongoing",
            location: "Room A-101"
        },
        {
            id: "S002",
            title: "Docker Container Orchestration",
            domain: "Containerization",
            trainer: "Mark Thompson",
            date: "2025-08-13",
            time: "11:00",
            duration: "3 hours",
            attendees: 16,
            status: "upcoming",
            location: "Lab B-205"
        },
        {
            id: "S003",
            title: "CI/CD Pipeline Implementation",
            domain: "DevOps",
            trainer: "Sarah Chen",
            date: "2025-08-13",
            time: "14:00",
            duration: "2.5 hours",
            attendees: 17,
            status: "upcoming",
            location: "Room C-301"
        },
        {
            id: "S004",
            title: "Selenium WebDriver Basics",
            domain: "Test Automation",
            trainer: "David Kumar",
            date: "2025-08-13",
            time: "16:00",
            duration: "2 hours",
            attendees: 17,
            status: "upcoming",
            location: "Lab D-102"
        }
    ],
    
    questions: [
        {
            id: "Q001",
            graduate: "Alex Rivera",
            question: "How do I optimize prompt engineering for better AI responses?",
            domain: "Generative AI",
            date: "2025-08-12",
            status: "pending",
            priority: "high"
        },
        {
            id: "Q002",
            graduate: "Sam Patel",
            question: "What's the difference between Docker and Kubernetes scaling?",
            domain: "Containerization",
            date: "2025-08-12",
            answer: "Docker handles single-node scaling while Kubernetes manages multi-node orchestration...",
            answeredBy: "Mark Thompson",
            status: "answered",
            priority: "medium"
        },
        {
            id: "Q003",
            graduate: "Jordan Kim",
            question: "How to implement blue-green deployment strategy?",
            domain: "DevOps",
            date: "2025-08-11",
            status: "escalated",
            priority: "high"
        }
    ],
    
    activities: [
        { 
            id: "A001", 
            type: "session_completed", 
            title: "Session Completed", 
            description: "Advanced Prompt Engineering - 18 attendees", 
            time: "2 hours ago",
            icon: "check-circle"
        },
        { 
            id: "A002", 
            type: "question_answered", 
            title: "Question Answered", 
            description: "Docker vs Kubernetes scaling question resolved", 
            time: "3 hours ago",
            icon: "message-circle"
        },
        { 
            id: "A003", 
            type: "new_graduate", 
            title: "New Graduate Added", 
            description: "Casey Brown joined DevOps track", 
            time: "5 hours ago",
            icon: "user-plus"
        },
        { 
            id: "A004", 
            type: "session_scheduled", 
            title: "Session Scheduled", 
            description: "CI/CD Pipeline Implementation for tomorrow", 
            time: "6 hours ago",
            icon: "calendar"
        }
    ]
};

// Global Variables
let currentRole = 'admin';
let currentDate = new Date().toISOString().split('T')[0];
let charts = {
    progressOverview: null,
    domainDistribution: null,
    progressTrends: null,
    weeklySchedule: null,
    myStudentProgress: null,
    weeklyAttendance: null,
    sessionTypes: null,
    aiProgress: null,
    aiPerfDist: null
};

// Role-based navigation configuration
const navigationConfig = {
    admin: {
        main: [
            { id: 'admin-dashboard', icon: 'layout-dashboard', text: 'Dashboard', active: true },
            { id: 'session-management', icon: 'monitor', text: 'Session Management' },
            { id: 'graduate-progress', icon: 'trending-up', text: 'Graduate Progress' },
            { id: 'qa-management', icon: 'help-circle', text: 'Q&A Management' }
        ],
        reports: [
            { id: 'daily-reports', icon: 'file-text', text: 'Daily Reports' },
            { id: 'weekly-analytics', icon: 'bar-chart-3', text: 'Weekly Analytics' },
            { id: 'domain-reports', icon: 'pie-chart', text: 'Domain Reports' }
        ],
        management: [
            { id: 'user-management', icon: 'users', text: 'User Management' },
            { id: 'trainer-availability', icon: 'calendar-check', text: 'Trainer Availability' },
            { id: 'program-settings', icon: 'settings', text: 'Program Settings' }
        ]
    },
    coordinator: {
        main: [
            { id: 'coordinator-dashboard', icon: 'layout-dashboard', text: 'Dashboard', active: true },
            { id: 'session-coordination', icon: 'calendar', text: 'Session Coordination' },
            { id: 'attendance-tracking', icon: 'user-check', text: 'Attendance Tracking' },
            { id: 'trainer-coordination', icon: 'users', text: 'Trainer Coordination' }
        ],
        reports: [
            { id: 'attendance-reports', icon: 'clipboard-check', text: 'Attendance Reports' },
            { id: 'session-reports', icon: 'monitor', text: 'Session Reports' }
        ],
        management: [
            { id: 'schedule-management', icon: 'calendar-days', text: 'Schedule Management' },
            { id: 'resource-allocation', icon: 'briefcase', text: 'Resource Allocation' }
        ]
    },
    trainer: {
        main: [
            { id: 'trainer-dashboard', icon: 'layout-dashboard', text: 'My Dashboard', active: true },
            { id: 'my-sessions', icon: 'monitor', text: 'My Sessions' },
            { id: 'student-progress', icon: 'trending-up', text: 'Student Progress' },
            { id: 'qa-responses', icon: 'message-circle', text: 'Q&A Responses' }
        ],
        reports: [
            { id: 'my-reports', icon: 'file-text', text: 'My Reports' },
            { id: 'student-analytics', icon: 'bar-chart-3', text: 'Student Analytics' }
        ],
        management: [
            { id: 'availability-setting', icon: 'calendar-check', text: 'Set Availability' },
            { id: 'resource-requests', icon: 'package', text: 'Resource Requests' }
        ]
    },
    grad: {
        main: [
            { id: 'grad-dashboard', icon: 'graduation-cap', text: 'My Dashboard', active: true },
            { id: 'my-progress', icon: 'trending-up', text: 'My Progress' },
            { id: 'my-sessions', icon: 'calendar', text: 'My Sessions' },
            { id: 'ask-questions', icon: 'help-circle', text: 'Ask Questions' }
        ],
        reports: [
            { id: 'my-attendance', icon: 'calendar-check', text: 'My Attendance' },
            { id: 'my-achievements', icon: 'award', text: 'My Achievements' }
        ],
        management: [
            { id: 'learning-resources', icon: 'book-open', text: 'Learning Resources' },
            { id: 'peer-collaboration', icon: 'users', text: 'Peer Collaboration' }
        ]
    }
};

// Application Initialization
function initializeModernDashboard() {
    setCurrentDate();
    switchRole(currentRole);
    initializeCharts();
    loadActivityFeed();
    
    // Set default date for reports
    const reportDateInput = document.getElementById('reportDate');
    if (reportDateInput) {
        reportDateInput.value = currentDate;
    }
    
    // Initialize dropdown functionality
    initializeDropdowns();
}

function setCurrentDate() {
    const today = new Date();
    currentDate = today.toISOString().split('T')[0];
}

// Role Management
function switchRole(role) {
    currentRole = role;
    updateUserInfo(role);
    updateNavigation(role);
    hideAllSections();
    showRoleDashboard(role);
}

function updateUserInfo(role) {
    const userData = masterData.roles[role];
    const userNameElement = document.getElementById('currentUserName');
    
    if (userNameElement) {
        userNameElement.textContent = userData.name;
    }
    
    // Update role selector
    const roleSelector = document.getElementById('roleSelector');
    if (roleSelector) {
        roleSelector.value = role;
    }
}

function updateNavigation(role) {
    const config = navigationConfig[role];
    
    // Update main menu
    updateMenuSection('mainMenuList', config.main);
    
    // Update reports menu
    updateMenuSection('reportsMenuList', config.reports);
    
    // Update management menu
    updateMenuSection('managementMenuList', config.management);
    
    // Refresh icons
    lucide.createIcons();
}

function updateMenuSection(containerId, items) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    container.innerHTML = '';
    
    items.forEach(item => {
        const li = document.createElement('li');
        li.innerHTML = `
            <a href="#${item.id}" onclick="showSection('${item.id}', this)" class="${item.active ? 'is-active' : ''}">
                <span class="icon"><i data-lucide="${item.icon}"></i></span>
                <span>${item.text}</span>
            </a>
        `;
        container.appendChild(li);
    });
}

function showRoleDashboard(role) {
    const dashboardMap = {
        admin: 'admin-dashboard',
        coordinator: 'coordinator-dashboard',
        trainer: 'trainer-dashboard',
        grad: 'grad-dashboard'
    };
    
    const sectionId = dashboardMap[role] || 'admin-dashboard';
    showSection(sectionId);
    
    // Load role-specific data
    loadDashboardData(role);
}

function loadDashboardData(role) {
    switch (role) {
        case 'admin':
            loadAdminDashboard();
            break;
        case 'coordinator':
            loadCoordinatorDashboard();
            break;
        case 'trainer':
            loadTrainerDashboard();
            break;
        case 'grad':
            loadGradDashboard();
            break;
    }
}

// Dashboard Loading Functions
function loadAdminDashboard() {
    loadActivityFeed();
    updateQuickStats();
    // Add slight delay to ensure DOM is ready for charts
    setTimeout(() => {
        initializeCharts();
    }, 100);
}

function loadCoordinatorDashboard() {
    // Load coordinator-specific data
    initializeWeeklyScheduleChart();
    console.log('Coordinator dashboard loaded');
}

function loadTrainerDashboard() {
    // Load trainer-specific data
    initializeMyStudentProgressChart();
    console.log('Trainer dashboard loaded');
}

function loadGradDashboard() {
    // Load graduate-specific data
    console.log('Graduate dashboard loaded');
}

function loadActivityFeed() {
    const activityFeed = document.getElementById('activityFeed');
    if (!activityFeed) return;
    
    activityFeed.innerHTML = '';
    
    masterData.activities.forEach(activity => {
        const activityItem = document.createElement('div');
        activityItem.className = 'activity-item';
        activityItem.innerHTML = `
            <div class="activity-icon">
                <i data-lucide="${activity.icon}"></i>
            </div>
            <div class="activity-content">
                <div class="activity-title">${activity.title}</div>
                <div class="activity-description">${activity.description}</div>
            </div>
            <div class="activity-time">${activity.time}</div>
        `;
        activityFeed.appendChild(activityItem);
    });
    
    lucide.createIcons();
}

function updateQuickStats() {
    // Calculate and update real-time statistics
    const todaysSessions = masterData.sessions.filter(s => s.date === currentDate);
    const ongoingSessions = todaysSessions.filter(s => s.status === 'ongoing');
    const totalAttendees = todaysSessions.reduce((sum, s) => sum + s.attendees, 0);
    const attendanceRate = Math.round((totalAttendees / masterData.program.totalParticipants) * 100);
    
    // Update quick stats display (if elements exist)
    updateStatValue('todayAttendance', `${attendanceRate}%`);
    updateStatValue('activeTrainers', masterData.program.totalTrainers);
    updateStatValue('pendingReviews', '7');
    updateStatValue('openQueries', masterData.questions.filter(q => q.status === 'pending').length);
}

function updateStatValue(elementClass, value) {
    const elements = document.querySelectorAll(`.${elementClass}`);
    elements.forEach(el => {
        if (el) el.textContent = value;
    });
}

// Section Management
function hideAllSections() {
    const sections = document.querySelectorAll('.dashboard-section');
    sections.forEach(section => {
        section.classList.add('is-hidden');
    });
}

function showSection(sectionId, activeLink = null) {
    console.log('Showing section:', sectionId);
    hideAllSections();
    
    const section = document.getElementById(sectionId);
    if (section) {
        section.classList.remove('is-hidden');
        section.classList.add('fade-in');
        console.log('Section found and displayed:', sectionId);
    } else {
        console.error('Section not found:', sectionId);
    }
    
    // Update active menu item
    if (activeLink) {
        document.querySelectorAll('.menu-list a').forEach(link => {
            link.classList.remove('is-active');
        });
        activeLink.classList.add('is-active');
    }
    
    // Load section-specific data
    loadSectionData(sectionId);
}

function loadSectionData(sectionId) {
    switch (sectionId) {
        case 'session-management':
            loadSessionManagement();
            break;
        case 'graduate-progress':
            loadGraduateProgress();
            break;
        case 'qa-management':
            loadQAManagement();
            break;
        case 'daily-reports':
            generateDailyReport();
            break;
        case 'weekly-analytics':
            loadWeeklyAnalytics();
            break;
        case 'domain-reports':
            loadDomainReports();
            break;
        case 'user-management':
            loadUserManagement();
            break;
        case 'trainer-availability':
            loadTrainerAvailability();
            break;
        case 'program-settings':
            loadProgramSettings();
            break;
        // Program Coordinator sections
        case 'session-coordination':
            loadSessionCoordination();
            break;
        case 'attendance-tracking':
            loadAttendanceTracking();
            break;
        case 'trainer-coordination':
            loadTrainerCoordination();
            break;
        case 'attendance-reports':
            loadAttendanceReports();
            break;
        case 'session-reports':
            loadSessionReports();
            break;
        case 'schedule-management':
            loadScheduleManagement();
            break;
        case 'resource-allocation':
            loadResourceAllocation();
            break;
        // Trainer sections
        case 'my-sessions':
            loadMySessions();
            break;
        case 'student-progress':
            loadStudentProgress();
            break;
        case 'qa-responses':
            loadQAResponses();
            break;
        case 'my-reports':
            loadMyReports();
            break;
        case 'student-analytics':
            loadStudentAnalytics();
            break;
        case 'availability-setting':
            loadAvailabilitySetting();
            break;
        case 'resource-requests':
            loadResourceRequests();
            break;
        // Graduate sections
        case 'my-progress':
            loadMyProgress();
            break;
        case 'ask-questions':
            loadAskQuestions();
            break;
        case 'my-attendance':
            loadMyAttendance();
            break;
        case 'my-achievements':
            loadMyAchievements();
            break;
        case 'learning-resources':
            loadLearningResources();
            break;
        case 'peer-collaboration':
            loadPeerCollaboration();
            break;
    }
}

// Session Management
function loadSessionManagement() {
    const sessionsGrid = document.getElementById('sessionsGrid');
    if (!sessionsGrid) return;
    
    sessionsGrid.innerHTML = '';
    
    masterData.sessions.forEach(session => {
        const sessionCard = document.createElement('div');
        sessionCard.className = 'session-card';
        sessionCard.innerHTML = `
            <div class="session-header">
                <div>
                    <div class="session-title">${session.title}</div>
                    <div class="session-meta">${session.trainer} • ${session.domain}</div>
                </div>
                <span class="session-status ${session.status}">${session.status}</span>
            </div>
            <div class="session-details">
                <div class="session-detail">
                    <i data-lucide="calendar"></i>
                    <span>${session.date} at ${session.time}</span>
                </div>
                <div class="session-detail">
                    <i data-lucide="clock"></i>
                    <span>${session.duration}</span>
                </div>
                <div class="session-detail">
                    <i data-lucide="map-pin"></i>
                    <span>${session.location}</span>
                </div>
                <div class="session-detail">
                    <i data-lucide="users"></i>
                    <span>${session.attendees} attendees</span>
                </div>
            </div>
            <div class="session-actions">
                <button class="button is-small is-info" onclick="viewSessionDetails('${session.id}')">
                    <span class="icon"><i data-lucide="eye"></i></span>
                    <span>View</span>
                </button>
                <button class="button is-small is-primary" onclick="editSession('${session.id}')">
                    <span class="icon"><i data-lucide="edit"></i></span>
                    <span>Edit</span>
                </button>
            </div>
        `;
        sessionsGrid.appendChild(sessionCard);
    });
    
    lucide.createIcons();
}

// Graduate Progress
function loadGraduateProgress() {
    loadProgressTrendsChart();
    loadGraduatesTable();
}

function loadGraduatesTable() {
    const tableBody = document.getElementById('graduatesTableBody');
    if (!tableBody) return;
    
    tableBody.innerHTML = '';
    
    masterData.graduates.forEach(graduate => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                <div class="media">
                    <div class="media-left">
                        <figure class="image is-32x32">
                            <div class="user-avatar" style="width: 32px; height: 32px; background: #667eea; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600;">
                                ${graduate.name.split(' ').map(n => n[0]).join('')}
                            </div>
                        </figure>
                    </div>
                    <div class="media-content">
                        <strong>${graduate.name}</strong><br>
                        <small>ID: ${graduate.id}</small>
                    </div>
                </div>
            </td>
            <td>
                <span class="tag is-info">${graduate.domain}</span>
            </td>
            <td>
                <progress class="progress is-primary" value="${graduate.progress}" max="100">${graduate.progress}%</progress>
            </td>
            <td>
                <span class="has-text-weight-semibold">${graduate.attendance}%</span>
            </td>
            <td>
                <span class="has-text-grey">${graduate.lastActive}</span>
            </td>
            <td>
                <div class="buttons are-small">
                    <button class="button is-info is-small" onclick="viewGraduateProfile('${graduate.id}')">
                        <span class="icon"><i data-lucide="user"></i></span>
                    </button>
                    <button class="button is-primary is-small" onclick="messageGraduate('${graduate.id}')">
                        <span class="icon"><i data-lucide="message-circle"></i></span>
                    </button>
                </div>
            </td>
        `;
        tableBody.appendChild(row);
    });
    
    lucide.createIcons();
}

// Q&A Management
function loadQAManagement() {
    loadQuestionsList();
}

function loadQuestionsList() {
    const questionsList = document.getElementById('questionsList');
    if (!questionsList) return;
    
    questionsList.innerHTML = '';
    
    masterData.questions.forEach(question => {
        const questionItem = document.createElement('div');
        questionItem.className = 'question-item';
        questionItem.innerHTML = `
            <div class="question-header">
                <div>
                    <div class="question-title">${question.question}</div>
                    <div class="question-meta">
                        Asked by <strong>${question.graduate}</strong> in ${question.domain} • ${question.date}
                    </div>
                </div>
                <div>
                    <span class="tag ${getQuestionStatusClass(question.status)}">${question.status}</span>
                    <span class="tag ${getPriorityClass(question.priority)}">${question.priority}</span>
                </div>
            </div>
            ${question.answer ? `
                <div class="question-content">
                    <strong>Answer:</strong> ${question.answer}
                    <br><small class="has-text-grey">Answered by: ${question.answeredBy}</small>
                </div>
            ` : ''}
            <div class="question-actions">
                ${!question.answer ? `
                    <button class="button is-small is-primary" onclick="answerQuestion('${question.id}')">
                        <span class="icon"><i data-lucide="message-circle"></i></span>
                        <span>Answer</span>
                    </button>
                ` : ''}
                <button class="button is-small is-info" onclick="viewQuestionDetails('${question.id}')">
                    <span class="icon"><i data-lucide="eye"></i></span>
                    <span>View Details</span>
                </button>
            </div>
        `;
        questionsList.appendChild(questionItem);
    });
    
    lucide.createIcons();
}

function getQuestionStatusClass(status) {
    const statusClasses = {
        pending: 'is-warning',
        answered: 'is-success',
        escalated: 'is-danger'
    };
    return statusClasses[status] || 'is-light';
}

function getPriorityClass(priority) {
    const priorityClasses = {
        high: 'is-danger',
        medium: 'is-warning',
        low: 'is-info'
    };
    return priorityClasses[priority] || 'is-light';
}

// Chart Initialization
function initializeCharts() {
    // Add retries for chart initialization to handle timing issues
    setTimeout(() => {
        try {
            initializeProgressOverviewChart();
            initializeDomainDistributionChart();
            console.log('All charts initialization completed');
        } catch (error) {
            console.error('Error initializing charts:', error);
            // Retry after a short delay
            setTimeout(() => {
                try {
                    initializeProgressOverviewChart();
                    initializeDomainDistributionChart();
                    console.log('Charts retry initialization completed');
                } catch (retryError) {
                    console.error('Retry failed for chart initialization:', retryError);
                }
            }, 500);
        }
    }, 200);
}

function initializeProgressOverviewChart() {
    const ctx = document.getElementById('progressOverviewChart');
    if (!ctx) {
        console.log('Progress overview chart canvas not found');
        return;
    }
    
    if (charts.progressOverview) {
        charts.progressOverview.destroy();
    }
    
    charts.progressOverview = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'],
            datasets: [{
                label: 'Overall Progress',
                data: [15, 32, 48, 65, 78, 85],
                borderColor: '#3273dc',
                backgroundColor: 'rgba(50, 115, 220, 0.1)',
                tension: 0.4,
                fill: true
            }, {
                label: 'Attendance Rate',
                data: [92, 89, 94, 87, 91, 89],
                borderColor: '#48c78e',
                backgroundColor: 'rgba(72, 199, 142, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
    console.log('Progress overview chart initialized successfully');
}

function initializeDomainDistributionChart() {
    const ctx = document.getElementById('domainDistributionChart');
    if (!ctx) {
        console.log('Domain distribution chart canvas not found');
        return;
    }
    
    if (charts.domainDistribution) {
        charts.domainDistribution.destroy();
    }
    
    charts.domainDistribution = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: masterData.program.domains,
            datasets: [{
                data: [18, 16, 17, 17],
                backgroundColor: [
                    '#3273dc',
                    '#48c78e',
                    '#ffe08a',
                    '#f14668'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
    console.log('Domain distribution chart initialized successfully');
}

function loadProgressTrendsChart() {
    const ctx = document.getElementById('progressTrendsChart');
    if (!ctx) return;
    
    if (charts.progressTrends) {
        charts.progressTrends.destroy();
    }
    
    charts.progressTrends = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: masterData.program.domains,
            datasets: [{
                label: 'Average Progress',
                data: [82, 75, 89, 69],
                backgroundColor: [
                    'rgba(50, 115, 220, 0.8)',
                    'rgba(72, 199, 142, 0.8)',
                    'rgba(255, 224, 138, 0.8)',
                    'rgba(241, 70, 104, 0.8)'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}

function initializeWeeklyScheduleChart() {
    const ctx = document.getElementById('weeklyScheduleChart');
    if (!ctx) return;
    
    if (charts.weeklySchedule) {
        charts.weeklySchedule.destroy();
    }
    
    charts.weeklySchedule = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
            datasets: [{
                label: 'Sessions Scheduled',
                data: [8, 6, 9, 7, 5],
                backgroundColor: 'rgba(50, 115, 220, 0.8)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

function initializeMyStudentProgressChart() {
    const ctx = document.getElementById('myStudentProgressChart');
    if (!ctx) return;
    
    if (charts.myStudentProgress) {
        charts.myStudentProgress.destroy();
    }
    
    charts.myStudentProgress = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Excellent', 'Good', 'Average', 'Needs Improvement'],
            datasets: [{
                data: [12, 6, 3, 1],
                backgroundColor: [
                    '#48c78e',
                    '#3273dc',
                    '#ffe08a',
                    '#f14668'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Modal Functions
function openAddModal() {
    openAddSessionModal();
}

function openAddSessionModal() {
    const modal = document.getElementById('addSessionModal');
    if (modal) {
        modal.classList.add('is-active');
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('is-active');
    }
}

// Dropdown Functions
function initializeDropdowns() {
    const dropdowns = document.querySelectorAll('.dropdown');
    dropdowns.forEach(dropdown => {
        const trigger = dropdown.querySelector('.dropdown-trigger button');
        if (trigger) {
            trigger.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('is-active');
            });
        }
    });
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', () => {
        const dropdowns = document.querySelectorAll('.dropdown');
        dropdowns.forEach(dropdown => {
            dropdown.classList.remove('is-active');
        });
    });
}

function toggleDropdown(dropdownId) {
    const dropdown = document.getElementById(dropdownId);
    if (dropdown) {
        dropdown.classList.toggle('is-active');
    }
}

// Report Functions
function generateDailyReport() {
    const reportContent = document.getElementById('dailyReportContent');
    if (!reportContent) return;
    
    const selectedDate = document.getElementById('reportDate')?.value || currentDate;
    const todaysSessions = masterData.sessions.filter(s => s.date === selectedDate);
    
    reportContent.innerHTML = `
        <div class="report-section">
            <h3>Daily Summary - ${selectedDate}</h3>
            <div class="columns">
                <div class="column">
                    <div class="field">
                        <label class="label">Total Sessions</label>
                        <div class="content">${todaysSessions.length}</div>
                    </div>
                </div>
                <div class="column">
                    <div class="field">
                        <label class="label">Total Attendees</label>
                        <div class="content">${todaysSessions.reduce((sum, s) => sum + s.attendees, 0)}</div>
                    </div>
                </div>
                <div class="column">
                    <div class="field">
                        <label class="label">Completion Rate</label>
                        <div class="content">${Math.round((todaysSessions.filter(s => s.status === 'completed').length / todaysSessions.length) * 100)}%</div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="report-section">
            <h3>Session Details</h3>
            <div class="table-container">
                <table class="table is-fullwidth">
                    <thead>
                        <tr>
                            <th>Session</th>
                            <th>Domain</th>
                            <th>Trainer</th>
                            <th>Time</th>
                            <th>Attendees</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${todaysSessions.map(session => `
                            <tr>
                                <td>${session.title}</td>
                                <td>${session.domain}</td>
                                <td>${session.trainer}</td>
                                <td>${session.time}</td>
                                <td>${session.attendees}</td>
                                <td><span class="tag ${session.status === 'completed' ? 'is-success' : session.status === 'ongoing' ? 'is-warning' : 'is-info'}">${session.status}</span></td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        </div>
    `;
}

// Filter Functions
function filterQuestions(status) {
    // Update active tab
    const tabs = document.querySelectorAll('.tabs li');
    tabs.forEach(tab => tab.classList.remove('is-active'));
    event.target.closest('li').classList.add('is-active');
    
    // Filter and reload questions
    loadQuestionsList(status);
}

function showDomainReport(domainId) {
    // Update tab active state
    const tabs = document.querySelectorAll('.domain-tabs .tabs li');
    tabs.forEach(tab => tab.classList.remove('is-active'));
    
    const activeTab = document.querySelector(`[onclick="showDomainReport('${domainId}')"]`);
    if (activeTab) {
        activeTab.parentElement.classList.add('is-active');
    }
    
    // Hide all domain reports
    const reports = document.querySelectorAll('.domain-report');
    reports.forEach(report => {
        report.classList.remove('active');
        report.style.display = 'none';
    });
    
    // Show selected domain report
    const selectedReport = document.getElementById(`${domainId}-report`);
    if (selectedReport) {
        selectedReport.classList.add('active');
        selectedReport.style.display = 'block';
    } else {
        // Create dynamic content for other domains
        createDomainReportContent(domainId);
    }
    
    console.log(`Showing domain report for: ${domainId}`);
}

function loadDomainSpecificReport(domain) {
    const reportContent = document.getElementById('domainReportContent');
    if (!reportContent) return;
    
    const domainGrads = masterData.graduates.filter(g => g.domain.toLowerCase().replace(/\s+/g, '-') === domain);
    const domainSessions = masterData.sessions.filter(s => s.domain.toLowerCase().replace(/\s+/g, '-') === domain);
    
    reportContent.innerHTML = `
        <div class="columns">
            <div class="column is-8">
                <div class="chart-card">
                    <div class="chart-header">
                        <h3 class="title is-5">${domain.replace('-', ' ')} Progress Overview</h3>
                    </div>
                    <div class="chart-content">
                        <canvas id="domainSpecificChart"></canvas>
                    </div>
                </div>
            </div>
            <div class="column is-4">
                <div class="card">
                    <div class="card-content">
                        <h4 class="title is-6">Quick Stats</h4>
                        <div class="content">
                            <p><strong>Total Graduates:</strong> ${domainGrads.length}</p>
                            <p><strong>Avg Progress:</strong> ${Math.round(domainGrads.reduce((sum, g) => sum + g.progress, 0) / domainGrads.length)}%</p>
                            <p><strong>Sessions Planned:</strong> ${domainSessions.length}</p>
                            <p><strong>Completion Rate:</strong> ${Math.round((domainSessions.filter(s => s.status === 'completed').length / domainSessions.length) * 100)}%</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Action Functions (Placeholder implementations)
function viewSessionDetails(sessionId) {
    console.log('Viewing session details for:', sessionId);
    // Implement modal or detail view
}

function editSession(sessionId) {
    console.log('Editing session:', sessionId);
    // Implement edit modal
}

function viewGraduateProfile(graduateId) {
    console.log('Viewing graduate profile:', graduateId);
    // Implement profile modal
}

function messageGraduate(graduateId) {
    console.log('Messaging graduate:', graduateId);
    // Implement messaging system
}

function answerQuestion(questionId) {
    console.log('Answering question:', questionId);
    // Implement answer modal
}

function viewQuestionDetails(questionId) {
    console.log('Viewing question details:', questionId);
    // Implement detail modal
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        window.location.reload();
    }
}

// Utility Functions
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification is-${type}`;
    notification.innerHTML = `
        <button class="delete" onclick="this.parentElement.remove()"></button>
        ${message}
    `;
    
    notification.style.position = 'fixed';
    notification.style.top = '90px';
    notification.style.right = '20px';
    notification.style.zIndex = '9999';
    notification.style.minWidth = '300px';
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// User Management Functions
function loadUserManagement() {
    console.log('User Management section loaded');
    // Additional user management data loading can be implemented here
    updateUserStats();
}

function updateUserStats() {
    const stats = {
        totalUsers: 73,
        graduates: 68,
        trainers: 4,
        admins: 1
    };
    
    // Update stat values if elements exist
    const statElements = document.querySelectorAll('.user-stats .stat-value');
    if (statElements.length >= 4) {
        statElements[0].textContent = stats.totalUsers;
        statElements[1].textContent = stats.graduates;
        statElements[2].textContent = stats.trainers;
        statElements[3].textContent = stats.admins;
    }
}

// Trainer Availability Functions
function loadTrainerAvailability() {
    console.log('Trainer Availability section loaded');
    // Additional trainer availability data loading can be implemented here
    updateTrainerStatus();
}

function updateTrainerStatus() {
    console.log('Trainer status updated');
    // Real-time trainer status updates can be implemented here
}

// Program Settings Functions
function loadProgramSettings() {
    console.log('Program Settings section loaded');
    // Additional program settings data loading can be implemented here
    loadSettingsData();
}

function loadSettingsData() {
    console.log('Settings data loaded');
    // Load current settings from server/storage can be implemented here
}

// Weekly Analytics Functions
function loadWeeklyAnalytics() {
    console.log('Loading Weekly Analytics section');
    initializeWeeklyAnalyticsCharts();
}

function initializeWeeklyAnalyticsCharts() {
    // Initialize Weekly Attendance Chart
    const weeklyAttendanceCtx = document.getElementById('weeklyAttendanceChart');
    if (weeklyAttendanceCtx) {
        if (charts.weeklyAttendance) {
            charts.weeklyAttendance.destroy();
        }
        
        charts.weeklyAttendance = new Chart(weeklyAttendanceCtx, {
            type: 'line',
            data: {
                labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
                datasets: [{
                    label: 'Attendance Rate (%)',
                    data: [94, 89, 96, 91, 88],
                    borderColor: '#3273dc',
                    backgroundColor: 'rgba(50, 115, 220, 0.1)',
                    fill: true,
                    tension: 0.4
                }, {
                    label: 'Target Rate (%)',
                    data: [90, 90, 90, 90, 90],
                    borderColor: '#48c78e',
                    borderDash: [5, 5],
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });
    }
    
    // Initialize Session Types Chart
    const sessionTypesCtx = document.getElementById('sessionTypesChart');
    if (sessionTypesCtx) {
        if (charts.sessionTypes) {
            charts.sessionTypes.destroy();
        }
        
        charts.sessionTypes = new Chart(sessionTypesCtx, {
            type: 'doughnut',
            data: {
                labels: ['Lectures', 'Hands-on Labs', 'Code Reviews', 'Q&A Sessions'],
                datasets: [{
                    data: [35, 30, 20, 15],
                    backgroundColor: [
                        '#3273dc',
                        '#48c78e',
                        '#ffe08a',
                        '#f14668'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
    
    console.log('Weekly Analytics charts initialized');
}

// Domain Reports Functions
function loadDomainReports() {
    console.log('Loading Domain Reports section');
    initializeDomainCharts();
    showDomainReport('generative-ai'); // Show default domain
}

function createDomainReportContent(domainId) {
    const container = document.getElementById('domainReportContent');
    if (!container) return;
    
    const domainData = {
        'containerization': {
            name: 'Containerization',
            students: 16,
            completion: 84,
            score: 82.3,
            sessions: 6,
            topics: [
                { name: 'Docker Fundamentals', progress: 14 },
                { name: 'Kubernetes Basics', progress: 12 },
                { name: 'Container Orchestration', progress: 10 },
                { name: 'Service Mesh', progress: 8 }
            ]
        },
        'devops': {
            name: 'DevOps',
            students: 17,
            completion: 89,
            score: 85.7,
            sessions: 8,
            topics: [
                { name: 'CI/CD Pipelines', progress: 15 },
                { name: 'Infrastructure as Code', progress: 13 },
                { name: 'Monitoring & Logging', progress: 11 },
                { name: 'Security Integration', progress: 9 }
            ]
        },
        'test-automation': {
            name: 'Test Automation',
            students: 17,
            completion: 78,
            score: 79.8,
            sessions: 5,
            topics: [
                { name: 'Selenium WebDriver', progress: 13 },
                { name: 'API Testing', progress: 12 },
                { name: 'Performance Testing', progress: 8 },
                { name: 'Mobile Testing', progress: 6 }
            ]
        }
    };
    
    const data = domainData[domainId];
    if (!data) return;
    
    container.innerHTML = `
        <div class="domain-report active" id="${domainId}-report">
            <div class="domain-metrics-grid">
                <div class="metric-card">
                    <div class="metric-content">
                        <div class="metric-header">
                            <div class="metric-label">Enrolled Students</div>
                            <div class="metric-icon">
                                <i data-lucide="users" style="color: #3273dc;"></i>
                            </div>
                        </div>
                        <div class="metric-value">${data.students}</div>
                        <div class="metric-change positive">
                            <i data-lucide="user-plus"></i>
                            <span>+1 this week</span>
                        </div>
                    </div>
                </div>
                
                <div class="metric-card">
                    <div class="metric-content">
                        <div class="metric-header">
                            <div class="metric-label">Completion Rate</div>
                            <div class="metric-icon">
                                <i data-lucide="check-circle" style="color: #48c78e;"></i>
                            </div>
                        </div>
                        <div class="metric-value">${data.completion}%</div>
                        <div class="metric-change positive">
                            <i data-lucide="trending-up"></i>
                            <span>+3% this month</span>
                        </div>
                    </div>
                </div>
                
                <div class="metric-card">
                    <div class="metric-content">
                        <div class="metric-header">
                            <div class="metric-label">Average Score</div>
                            <div class="metric-icon">
                                <i data-lucide="award" style="color: #ffe08a;"></i>
                            </div>
                        </div>
                        <div class="metric-value">${data.score}</div>
                        <div class="metric-change positive">
                            <i data-lucide="trending-up"></i>
                            <span>+2.1 points</span>
                        </div>
                    </div>
                </div>
                
                <div class="metric-card">
                    <div class="metric-content">
                        <div class="metric-header">
                            <div class="metric-label">Active Sessions</div>
                            <div class="metric-icon">
                                <i data-lucide="calendar" style="color: #3e8ed0;"></i>
                            </div>
                        </div>
                        <div class="metric-value">${data.sessions}</div>
                        <div class="metric-change neutral">
                            <i data-lucide="minus"></i>
                            <span>No change</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="columns">
                <div class="column is-8">
                    <div class="chart-card">
                        <div class="chart-header">
                            <h3 class="title is-5">${data.name} Progress Timeline</h3>
                        </div>
                        <div class="chart-content">
                            <canvas id="${domainId}ProgressChart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="column is-4">
                    <div class="chart-card">
                        <div class="chart-header">
                            <h3 class="title is-5">Topic Breakdown</h3>
                        </div>
                        <div class="chart-content">
                            <div class="topic-list">
                                ${data.topics.map(topic => `
                                    <div class="topic-item">
                                        <div class="topic-info">
                                            <div class="topic-name">${topic.name}</div>
                                            <div class="topic-progress">${topic.progress}/${data.students} completed</div>
                                        </div>
                                        <div class="topic-bar">
                                            <div class="progress-fill" style="width: ${(topic.progress/data.students)*100}%; background-color: #3273dc;"></div>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Re-initialize Lucide icons for the new content
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

function initializeDomainCharts() {
    // Initialize AI Progress Chart
    const aiProgressCtx = document.getElementById('aiProgressChart');
    if (aiProgressCtx) {
        if (charts.aiProgress) {
            charts.aiProgress.destroy();
        }
        
        charts.aiProgress = new Chart(aiProgressCtx, {
            type: 'line',
            data: {
                labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'],
                datasets: [{
                    label: 'Average Progress',
                    data: [20, 35, 52, 68, 79, 88],
                    borderColor: '#3273dc',
                    backgroundColor: 'rgba(50, 115, 220, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });
    }
    
    // Initialize Performance Distribution Chart
    const aiPerfDistCtx = document.getElementById('aiPerformanceDistChart');
    if (aiPerfDistCtx) {
        if (charts.aiPerfDist) {
            charts.aiPerfDist.destroy();
        }
        
        charts.aiPerfDist = new Chart(aiPerfDistCtx, {
            type: 'bar',
            data: {
                labels: ['90-100%', '80-89%', '70-79%', '60-69%', '<60%'],
                datasets: [{
                    label: 'Number of Students',
                    data: [8, 6, 3, 1, 0],
                    backgroundColor: [
                        '#48c78e',
                        '#3273dc',
                        '#ffe08a',
                        '#f14668',
                        '#b5b5b5'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
    }
    
    console.log('Domain charts initialized');
}

// Program Coordinator Functions
function loadSessionCoordination() {
    console.log('Loading session coordination...');
    // Initialize session coordination functionality
}

function loadAttendanceTracking() {
    console.log('Loading attendance tracking...');
    // Initialize attendance tracking functionality
}

function loadTrainerCoordination() {
    console.log('Loading trainer coordination...');
    // Initialize trainer coordination functionality
}

// Trainer Functions
function loadMySessions() {
    console.log('Loading my sessions...');
    // Initialize trainer sessions functionality
}

function loadStudentProgress() {
    console.log('Loading student progress...');
    // Initialize student progress tracking
}

function loadQAResponses() {
    console.log('Loading Q&A responses...');
    // Initialize Q&A responses functionality
}

// Graduate Functions
function loadMyProgress() {
    console.log('Loading my progress...');
    initializeProgressChart();
}

function loadAskQuestions() {
    console.log('Loading ask questions...');
    // Initialize question asking functionality
}

// Initialize Progress Chart for Graduate Role
function initializeProgressChart() {
    const ctx = document.getElementById('myProgressChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['LLM Fundamentals', 'Prompt Engineering', 'RAG Systems', 'Fine-tuning', 'Ethics & Safety', 'Deployment'],
            datasets: [{
                label: 'My Progress',
                data: [92, 87, 73, 45, 68, 58],
                backgroundColor: 'rgba(72, 199, 142, 0.2)',
                borderColor: 'rgba(72, 199, 142, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(72, 199, 142, 1)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }, {
                label: 'Class Average',
                data: [78, 75, 65, 52, 71, 48],
                backgroundColor: 'rgba(255, 224, 138, 0.2)',
                borderColor: 'rgba(255, 224, 138, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(255, 224, 138, 1)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        stepSize: 20
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    },
                    angleLines: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Program Coordinator Reports & Analytics Functions
function loadAttendanceReports() {
    console.log('Loading attendance reports...');
    initializeAttendanceCharts();
}

function loadSessionReports() {
    console.log('Loading session reports...');
    // Initialize session reports functionality
}

// Program Coordinator Management Functions
function loadScheduleManagement() {
    console.log('Loading schedule management...');
    // Initialize schedule management functionality
}

function loadResourceAllocation() {
    console.log('Loading resource allocation...');
    // Initialize resource allocation functionality
}

// Trainer Reports & Analytics Functions
function loadMyReports() {
    console.log('Loading my reports...');
    initializeTrainerCharts();
}

function loadStudentAnalytics() {
    console.log('Loading student analytics...');
    initializeStudentAnalyticsCharts();
}

// Trainer Management Functions
function loadAvailabilitySetting() {
    console.log('Loading availability setting...');
    // Initialize availability setting functionality
}

function loadResourceRequests() {
    console.log('Loading resource requests...');
    // Initialize resource requests functionality
}

// Graduate Reports & Analytics Functions
function loadMyAttendance() {
    console.log('Loading my attendance...');
    initializeAttendanceChart();
}

function loadMyAchievements() {
    console.log('Loading my achievements...');
    // Initialize achievements functionality
}

// Graduate Management Functions
function loadLearningResources() {
    console.log('Loading learning resources...');
    // Initialize learning resources functionality
}

function loadPeerCollaboration() {
    console.log('Loading peer collaboration...');
    // Initialize peer collaboration functionality
}

// Chart Initialization Functions
function initializeAttendanceCharts() {
    // Attendance Trend Chart
    const trendCtx = document.getElementById('attendanceTrendChart');
    if (trendCtx) {
        new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'],
                datasets: [{
                    label: 'Attendance Rate',
                    data: [88, 92, 90, 94, 96, 94],
                    borderColor: '#3273dc',
                    backgroundColor: 'rgba(50, 115, 220, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });
    }

    // Domain Attendance Chart
    const domainCtx = document.getElementById('domainAttendanceChart');
    if (domainCtx) {
        new Chart(domainCtx, {
            type: 'doughnut',
            data: {
                labels: ['Generative AI', 'DevOps', 'Containerization', 'Test Automation'],
                datasets: [{
                    data: [95, 92, 94, 98],
                    backgroundColor: ['#3273dc', '#48c78e', '#ffe08a', '#f14668']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
}

function initializeTrainerCharts() {
    // Teacher Performance Chart
    const performanceCtx = document.getElementById('teacherPerformanceChart');
    if (performanceCtx) {
        new Chart(performanceCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'],
                datasets: [{
                    label: 'Average Rating',
                    data: [4.5, 4.6, 4.4, 4.7, 4.8, 4.6, 4.7, 4.8],
                    borderColor: '#48c78e',
                    backgroundColor: 'rgba(72, 199, 142, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Sessions Taught',
                    data: [8, 10, 9, 12, 15, 14, 16, 18],
                    borderColor: '#3273dc',
                    backgroundColor: 'rgba(50, 115, 220, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        min: 0,
                        max: 5
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        min: 0,
                        grid: {
                            drawOnChartArea: false,
                        }
                    }
                }
            }
        });
    }
}

function initializeStudentAnalyticsCharts() {
    // Student Progress Distribution Chart
    const progressCtx = document.getElementById('studentProgressDistChart');
    if (progressCtx) {
        new Chart(progressCtx, {
            type: 'bar',
            data: {
                labels: ['0-20%', '21-40%', '41-60%', '61-80%', '81-100%'],
                datasets: [{
                    label: 'Number of Students',
                    data: [0, 1, 3, 8, 6],
                    backgroundColor: ['#f14668', '#ffe08a', '#ffdd57', '#48c78e', '#00d1b2']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
    }

    // Performance Trends Chart
    const trendsCtx = document.getElementById('performanceTrendsChart');
    if (trendsCtx) {
        new Chart(trendsCtx, {
            type: 'line',
            data: {
                labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'],
                datasets: [{
                    label: 'Class Average',
                    data: [78, 81, 83, 85, 87, 89],
                    borderColor: '#3273dc',
                    backgroundColor: 'rgba(50, 115, 220, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Top Performer',
                    data: [95, 96, 94, 97, 98, 95],
                    borderColor: '#48c78e',
                    backgroundColor: 'rgba(72, 199, 142, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }
}

function initializeAttendanceChart() {
    // My Attendance Chart
    const attendanceCtx = document.getElementById('attendanceChart');
    if (attendanceCtx) {
        new Chart(attendanceCtx, {
            type: 'line',
            data: {
                labels: ['Aug 1', 'Aug 3', 'Aug 5', 'Aug 7', 'Aug 9', 'Aug 11', 'Aug 13'],
                datasets: [{
                    label: 'Attendance Status',
                    data: [1, 1, 1, 1, 0, 0.5, 1], // 1 = present, 0 = absent, 0.5 = late
                    borderColor: '#48c78e',
                    backgroundColor: 'rgba(72, 199, 142, 0.1)',
                    tension: 0.4,
                    pointBackgroundColor: function(context) {
                        const value = context.raw;
                        if (value === 1) return '#48c78e';
                        if (value === 0.5) return '#ffe08a';
                        return '#f14668';
                    }
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        min: 0,
                        max: 1,
                        ticks: {
                            callback: function(value) {
                                if (value === 1) return 'Present';
                                if (value === 0.5) return 'Late';
                                return 'Absent';
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw;
                                if (value === 1) return 'Present';
                                if (value === 0.5) return 'Late';
                                return 'Absent';
                            }
                        }
                    }
                }
            }
        });
    }
}
