// Student Progress Mo                    <i class="untitledui-trending-up-01" style="font-size: 3rem; margin-bottom: 15px; display: block;"></i>ule

let progressChart = null;

function loadStudentProgress() {
    renderProgressTable();
    renderProgressChart();
    updateProgressStats();
}

function renderProgressTable() {
    const tableBody = document.getElementById('progressTableBody');
    if (!tableBody) return;

    const filteredData = getFilteredProgressData();
    
    tableBody.innerHTML = '';

    if (filteredData.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align: center; padding: 40px; color: #666;">
                    <i class="untitledui-trending-up-01" style="font-size: 3rem; margin-bottom: 15px; display: block;"></i>
                    No progress data found
                </td>
            </tr>
        `;
        return;
    }

    filteredData.forEach(student => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                <div class="student-info">
                    <div class="student-avatar">
                        ${student.studentName.charAt(0)}
                    </div>
                    <div class="student-details">
                        <div class="student-name">${student.studentName}</div>
                        <div class="student-id">ID: ${student.studentId}</div>
                    </div>
                </div>
            </td>
            <td>
                <div class="progress-cell">
                    <div class="progress-bar">
                        <div class="progress" style="width: ${student.domains['generative-ai']}%"></div>
                    </div>
                    <span class="progress-text">${student.domains['generative-ai']}%</span>
                </div>
            </td>
            <td>
                <div class="progress-cell">
                    <div class="progress-bar">
                        <div class="progress" style="width: ${student.domains['containerization']}%"></div>
                    </div>
                    <span class="progress-text">${student.domains['containerization']}%</span>
                </div>
            </td>
            <td>
                <div class="progress-cell">
                    <div class="progress-bar">
                        <div class="progress" style="width: ${student.domains['devops']}%"></div>
                    </div>
                    <span class="progress-text">${student.domains['devops']}%</span>
                </div>
            </td>
            <td>
                <div class="progress-cell">
                    <div class="progress-bar">
                        <div class="progress" style="width: ${student.domains['test-automation']}%"></div>
                    </div>
                    <span class="progress-text">${student.domains['test-automation']}%</span>
                </div>
            </td>
            <td>
                <div class="overall-progress">
                    <div class="overall-circle" data-progress="${student.overall}">
                        <span>${student.overall}%</span>
                    </div>
                    <div class="performance-badge ${getPerformanceBadge(student.overall)}">
                        ${getPerformanceLabel(student.overall)}
                    </div>
                </div>
            </td>
        `;
        tableBody.appendChild(row);
    });

    // Initialize circular progress indicators
    initializeCircularProgress();
}

function getFilteredProgressData() {
    let filtered = [...progressData];

    // Filter by student
    const selectedStudent = document.getElementById('studentFilter')?.value;
    if (selectedStudent) {
        filtered = filtered.filter(student => student.studentId == selectedStudent);
    }

    // Sort by overall progress (highest first)
    return filtered.sort((a, b) => b.overall - a.overall);
}

function getPerformanceBadge(percentage) {
    if (percentage >= 80) return 'excellent';
    if (percentage >= 60) return 'good';
    if (percentage >= 40) return 'average';
    return 'needs-improvement';
}

function getPerformanceLabel(percentage) {
    if (percentage >= 80) return 'Excellent';
    if (percentage >= 60) return 'Good';
    if (percentage >= 40) return 'Average';
    return 'Needs Improvement';
}

function initializeCircularProgress() {
    const circles = document.querySelectorAll('.overall-circle');
    circles.forEach(circle => {
        const progress = parseInt(circle.dataset.progress);
        const circumference = 2 * Math.PI * 45; // radius = 45
        
        // Create SVG circle
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('width', '100');
        svg.setAttribute('height', '100');
        svg.style.position = 'absolute';
        svg.style.top = '0';
        svg.style.left = '0';

        const circleBackground = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circleBackground.setAttribute('cx', '50');
        circleBackground.setAttribute('cy', '50');
        circleBackground.setAttribute('r', '45');
        circleBackground.setAttribute('fill', 'none');
        circleBackground.setAttribute('stroke', '#e0e0e0');
        circleBackground.setAttribute('stroke-width', '6');

        const circleProgress = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circleProgress.setAttribute('cx', '50');
        circleProgress.setAttribute('cy', '50');
        circleProgress.setAttribute('r', '45');
        circleProgress.setAttribute('fill', 'none');
        circleProgress.setAttribute('stroke', getProgressColor(progress));
        circleProgress.setAttribute('stroke-width', '6');
        circleProgress.setAttribute('stroke-linecap', 'round');
        circleProgress.setAttribute('stroke-dasharray', circumference);
        circleProgress.setAttribute('stroke-dashoffset', circumference - (progress / 100) * circumference);
        circleProgress.style.transform = 'rotate(-90deg)';
        circleProgress.style.transformOrigin = '50% 50%';

        svg.appendChild(circleBackground);
        svg.appendChild(circleProgress);
        circle.appendChild(svg);
    });
}

function getProgressColor(percentage) {
    if (percentage >= 80) return '#28a745';
    if (percentage >= 60) return '#17a2b8';
    if (percentage >= 40) return '#ffc107';
    return '#dc3545';
}

function renderProgressChart() {
    const canvas = document.getElementById('progressChart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    
    // Destroy existing chart if any
    if (progressChart) {
        progressChart.destroy();
    }

    const domainAverages = calculateDomainAverages();

    // Simple chart implementation (you can replace with Chart.js for more features)
    const chartData = {
        labels: ['Gen AI', 'Containers', 'DevOps', 'Test Auto'],
        data: [
            domainAverages['generative-ai'],
            domainAverages['containerization'],
            domainAverages['devops'],
            domainAverages['test-automation']
        ],
        colors: ['#667eea', '#764ba2', '#f093fb', '#f5576c']
    };

    drawBarChart(ctx, chartData, canvas.width, canvas.height);
}

function calculateDomainAverages() {
    const totals = {
        'generative-ai': 0,
        'containerization': 0,
        'devops': 0,
        'test-automation': 0
    };

    progressData.forEach(student => {
        Object.keys(totals).forEach(domain => {
            totals[domain] += student.domains[domain];
        });
    });

    const averages = {};
    Object.keys(totals).forEach(domain => {
        averages[domain] = Math.round(totals[domain] / progressData.length);
    });

    return averages;
}

function drawBarChart(ctx, data, width, height) {
    const padding = 60;
    const chartWidth = width - (padding * 2);
    const chartHeight = height - (padding * 2);
    const barWidth = chartWidth / data.labels.length * 0.6;
    const barSpacing = chartWidth / data.labels.length * 0.4;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Set font
    ctx.font = '12px Arial';
    ctx.textAlign = 'center';

    // Draw bars
    data.data.forEach((value, index) => {
        const x = padding + (index * (barWidth + barSpacing)) + (barSpacing / 2);
        const barHeight = (value / 100) * chartHeight;
        const y = height - padding - barHeight;

        // Draw bar
        ctx.fillStyle = data.colors[index];
        ctx.fillRect(x, y, barWidth, barHeight);

        // Draw value on top of bar
        ctx.fillStyle = '#333';
        ctx.fillText(`${value}%`, x + (barWidth / 2), y - 10);

        // Draw label at bottom
        ctx.fillText(data.labels[index], x + (barWidth / 2), height - padding + 20);
    });

    // Draw axes
    ctx.strokeStyle = '#ccc';
    ctx.lineWidth = 1;
    
    // Y-axis
    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, height - padding);
    ctx.stroke();

    // X-axis
    ctx.beginPath();
    ctx.moveTo(padding, height - padding);
    ctx.lineTo(width - padding, height - padding);
    ctx.stroke();

    // Y-axis labels
    ctx.fillStyle = '#666';
    ctx.textAlign = 'right';
    for (let i = 0; i <= 10; i++) {
        const y = height - padding - (i * chartHeight / 10);
        const value = i * 10;
        ctx.fillText(`${value}%`, padding - 10, y + 4);
    }
}

function updateProgressStats() {
    const stats = calculateProgressStats();
    const statsContainer = document.getElementById('progressStats');
    
    if (statsContainer) {
        statsContainer.innerHTML = `
            <div class="progress-stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <i class="untitledui-users-01"></i>
                        <span>Total Students</span>
                    </div>
                    <div class="stat-value">${stats.totalStudents}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-header">
                        <i class="untitledui-trending-up-01"></i>
                        <span>Average Progress</span>
                    </div>
                    <div class="stat-value">${stats.averageProgress}%</div>
                </div>
                <div class="stat-card">
                    <div class="stat-header">
                        <i class="untitledui-trophy-01"></i>
                        <span>Top Performers</span>
                    </div>
                    <div class="stat-value">${stats.topPerformers}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-header">
                        <i class="untitledui-alert-triangle"></i>
                        <span>Need Attention</span>
                    </div>
                    <div class="stat-value">${stats.needAttention}</div>
                </div>
            </div>
        `;
    }
}

function calculateProgressStats() {
    const totalStudents = progressData.length;
    const averageProgress = Math.round(
        progressData.reduce((sum, student) => sum + student.overall, 0) / totalStudents
    );
    const topPerformers = progressData.filter(student => student.overall >= 80).length;
    const needAttention = progressData.filter(student => student.overall < 40).length;

    return {
        totalStudents,
        averageProgress,
        topPerformers,
        needAttention
    };
}

function viewStudentDetail(studentId) {
    const student = progressData.find(s => s.studentId === studentId);
    if (!student) return;

    const modalContent = `
        <div class="student-detail-view">
            <div class="student-header">
                <div class="student-avatar-large">
                    ${student.studentName.charAt(0)}
                </div>
                <div class="student-info-large">
                    <h3>${student.studentName}</h3>
                    <p>Student ID: ${student.studentId}</p>
                    <div class="overall-progress-large">
                        <span>Overall Progress: ${student.overall}%</span>
                        <div class="progress-bar-large">
                            <div class="progress" style="width: ${student.overall}%"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="domain-progress-grid">
                ${Object.entries(student.domains).map(([domain, progress]) => `
                    <div class="domain-progress-card">
                        <h4>${getDomainDisplayName(domain)}</h4>
                        <div class="domain-progress-circle" data-progress="${progress}">
                            <span>${progress}%</span>
                        </div>
                        <div class="domain-status ${getPerformanceBadge(progress)}">
                            ${getPerformanceLabel(progress)}
                        </div>
                    </div>
                `).join('')}
            </div>

            <div class="student-actions">
                <button class="btn btn-primary" onclick="updateStudentProgress(${studentId})">Update Progress</button>
                <button class="btn btn-secondary" onclick="viewStudentAssignments(${studentId})">View Assignments</button>
                <button class="btn btn-secondary" onclick="closeModal()">Close</button>
            </div>
        </div>
    `;

    showProgressModal('Student Progress Details', modalContent);
    
    // Initialize circular progress for domain cards
    setTimeout(() => {
        initializeDomainCircles();
    }, 100);
}

function initializeDomainCircles() {
    const circles = document.querySelectorAll('.domain-progress-circle');
    circles.forEach(circle => {
        const progress = parseInt(circle.dataset.progress);
        circle.style.background = `conic-gradient(${getProgressColor(progress)} ${progress * 3.6}deg, #e0e0e0 0deg)`;
    });
}

function updateStudentProgress(studentId) {
    const student = progressData.find(s => s.studentId === studentId);
    if (!student) return;

    const modalContent = `
        <form id="updateProgressForm" onsubmit="saveProgressUpdate(event, ${studentId})">
            <div class="progress-update-form">
                <h4>Update Progress for ${student.studentName}</h4>
                
                ${Object.entries(student.domains).map(([domain, progress]) => `
                    <div class="form-group">
                        <label for="progress_${domain}">${getDomainDisplayName(domain)} Progress</label>
                        <div class="progress-input-group">
                            <input type="range" id="progress_${domain}" name="progress_${domain}" 
                                   min="0" max="100" value="${progress}" class="progress-slider"
                                   oninput="updateProgressDisplay('${domain}', this.value)">
                            <span id="display_${domain}" class="progress-display">${progress}%</span>
                        </div>
                    </div>
                `).join('')}
                
                <div class="form-group">
                    <label for="progressNotes">Notes</label>
                    <textarea id="progressNotes" class="form-control" rows="3" 
                              placeholder="Add any notes about this progress update..."></textarea>
                </div>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Update Progress</button>
            </div>
        </form>
    `;

    showProgressModal('Update Student Progress', modalContent);
}

function updateProgressDisplay(domain, value) {
    const display = document.getElementById(`display_${domain}`);
    if (display) {
        display.textContent = `${value}%`;
    }
}

function saveProgressUpdate(event, studentId) {
    event.preventDefault();
    
    const student = progressData.find(s => s.studentId === studentId);
    if (!student) return;

    // Update domain progress
    Object.keys(student.domains).forEach(domain => {
        const input = document.getElementById(`progress_${domain}`);
        if (input) {
            student.domains[domain] = parseInt(input.value);
        }
    });

    // Recalculate overall progress
    const domainValues = Object.values(student.domains);
    student.overall = Math.round(domainValues.reduce((a, b) => a + b, 0) / domainValues.length);

    closeModal();
    renderProgressTable();
    renderProgressChart();
    updateProgressStats();
    showNotification('Student progress updated successfully!', 'success');
}

function showProgressModal(title, content) {
    const existingModal = document.getElementById('progressModal');
    if (existingModal) {
        existingModal.remove();
    }

    const modal = document.createElement('div');
    modal.id = 'progressModal';
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>${title}</h3>
                <button class="close-btn" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                ${content}
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    
    document.getElementById('modalOverlay').classList.add('show');
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
}

// Event listeners for progress filters
document.addEventListener('DOMContentLoaded', function() {
    const studentFilter = document.getElementById('studentFilter');
    const weekFilter = document.getElementById('weekFilter');

    if (studentFilter) {
        studentFilter.addEventListener('change', renderProgressTable);
    }

    if (weekFilter) {
        weekFilter.addEventListener('change', renderProgressTable);
    }
});

// Progress-specific styles
const progressStyles = `
    .progress-cell {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .progress-bar {
        background: #e0e0e0;
        height: 8px;
        border-radius: 4px;
        overflow: hidden;
        width: 100px;
        flex-shrink: 0;
    }

    .progress {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        height: 100%;
        border-radius: 4px;
        transition: width 0.3s ease;
    }

    .progress-text {
        font-weight: 600;
        color: #333;
        min-width: 40px;
    }

    .overall-progress {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 10px;
    }

    .overall-circle {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        font-weight: 600;
        color: #333;
        font-size: 1.1rem;
    }

    .performance-badge {
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
        text-align: center;
    }

    .performance-badge.excellent { background: #d4edda; color: #155724; }
    .performance-badge.good { background: #cce7ff; color: #004085; }
    .performance-badge.average { background: #fff3cd; color: #856404; }
    .performance-badge.needs-improvement { background: #f8d7da; color: #721c24; }

    .student-details {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .student-name {
        font-weight: 600;
        color: #333;
    }

    .student-id {
        font-size: 0.85rem;
        color: #666;
    }

    .domain-progress-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin: 25px 0;
    }

    .domain-progress-card {
        background: #f8f9fa;
        padding: 20px;
        border-radius: 12px;
        text-align: center;
    }

    .domain-progress-card h4 {
        margin-bottom: 15px;
        color: #333;
    }

    .domain-progress-circle {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 15px;
        font-weight: 600;
        color: #333;
        position: relative;
    }

    .domain-progress-circle::before {
        content: '';
        position: absolute;
        inset: 0;
        border-radius: 50%;
        padding: 4px;
        background: linear-gradient(45deg, transparent, transparent);
        mask: radial-gradient(farthest-side, transparent calc(100% - 4px), white calc(100% - 4px));
    }

    .progress-input-group {
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .progress-slider {
        flex: 1;
        height: 6px;
        border-radius: 3px;
        background: #e0e0e0;
        outline: none;
        -webkit-appearance: none;
    }

    .progress-slider::-webkit-slider-thumb {
        -webkit-appearance: none;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: #667eea;
        cursor: pointer;
    }

    .progress-display {
        min-width: 50px;
        font-weight: 600;
        color: #333;
    }

    .student-header {
        display: flex;
        align-items: center;
        gap: 20px;
        margin-bottom: 25px;
        padding-bottom: 20px;
        border-bottom: 1px solid #e0e0e0;
    }

    .student-avatar-large {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 2rem;
        font-weight: 600;
    }

    .student-info-large h3 {
        margin-bottom: 5px;
        color: #333;
    }

    .overall-progress-large {
        margin-top: 15px;
    }

    .progress-bar-large {
        background: #e0e0e0;
        height: 12px;
        border-radius: 6px;
        overflow: hidden;
        margin-top: 8px;
        width: 200px;
    }
`;

// Inject progress styles
if (!document.getElementById('progress-styles')) {
    const styleSheet = document.createElement('style');
    styleSheet.id = 'progress-styles';
    styleSheet.textContent = progressStyles;
    document.head.appendChild(styleSheet);
}
