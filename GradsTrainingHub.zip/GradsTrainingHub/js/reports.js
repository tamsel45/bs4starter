// Reports Module

function loadReports() {
    displayReportsOverview();
    setupReportGenerators();
}

function displayReportsOverview() {
    const reportsContainer = document.querySelector('#reports .reports-grid');
    if (!reportsContainer) return;

    // Add reports overview stats before the grid
    const overviewStats = document.createElement('div');
    overviewStats.className = 'reports-overview';
    overviewStats.innerHTML = `
        <div class="overview-stats">
            <div class="overview-stat">
                <div class="stat-icon">
                    <i class="untitledui-calendar-date"></i>
                </div>
                <div class="stat-content">
                    <h3>${getCurrentWeek()}/6</h3>
                    <p>Current Week</p>
                </div>
            </div>
            <div class="overview-stat">
                <div class="stat-icon">
                    <i class="untitledui-users-01"></i>
                </div>
                <div class="stat-content">
                    <h3>${getActiveStudents()}</h3>
                    <p>Active Students</p>
                </div>
            </div>
            <div class="overview-stat">
                <div class="stat-icon">
                    <i class="untitledui-presentation-chart-02"></i>
                </div>
                <div class="stat-content">
                    <h3>${trainingSessions.length}</h3>
                    <p>Total Sessions</p>
                </div>
            </div>
            <div class="overview-stat">
                <div class="stat-icon">
                    <i class="untitledui-percent-01"></i>
                </div>
                <div class="stat-content">
                    <h3>${getOverallAttendanceRate()}%</h3>
                    <p>Attendance Rate</p>
                </div>
            </div>
        </div>
    `;

    // Insert before the reports grid
    reportsContainer.parentNode.insertBefore(overviewStats, reportsContainer);
}

function getCurrentWeek() {
    // Calculate current week based on start date (September 1, 2025)
    const startDate = new Date('2025-09-01');
    const currentDate = new Date();
    const weeksDiff = Math.floor((currentDate - startDate) / (7 * 24 * 60 * 60 * 1000));
    return Math.min(Math.max(weeksDiff + 1, 1), 6);
}

function getActiveStudents() {
    // Count students who have attended at least one session
    const activeStudentIds = new Set(attendanceData
        .filter(record => record.status === 'Present')
        .map(record => record.studentId));
    return activeStudentIds.size;
}

function getOverallAttendanceRate() {
    if (attendanceData.length === 0) return 0;
    const presentCount = attendanceData.filter(record => record.status === 'Present').length;
    return Math.round((presentCount / attendanceData.length) * 100);
}

function setupReportGenerators() {
    // Add event listeners for report generation buttons
    const reportButtons = document.querySelectorAll('.report-card button');
    reportButtons.forEach(button => {
        const reportType = button.getAttribute('onclick')?.match(/generateReport\('([^']+)'\)/)?.[1];
        if (reportType) {
            button.onclick = () => generateDetailedReport(reportType);
        }
    });
}

function generateDetailedReport(type) {
    showNotification(`Generating ${type} report...`, 'info');
    
    setTimeout(() => {
        switch(type) {
            case 'weekly':
                showWeeklyReport();
                break;
            case 'attendance':
                showAttendanceReport();
                break;
            case 'performance':
                showPerformanceReport();
                break;
            case 'issues':
                showIssuesReport();
                break;
            default:
                showNotification('Report type not found', 'error');
        }
    }, 1500);
}

function showWeeklyReport() {
    const weeklyData = generateWeeklyReportData();
    
    const reportContent = `
        <div class="report-content">
            <div class="report-header">
                <h3>Weekly Progress Report - Week ${weeklyData.week}</h3>
                <p class="report-date">Generated on ${new Date().toLocaleDateString()}</p>
            </div>
            
            <div class="report-summary">
                <div class="summary-grid">
                    <div class="summary-item">
                        <div class="summary-value">${weeklyData.totalSessions}</div>
                        <div class="summary-label">Sessions Conducted</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-value">${weeklyData.averageAttendance}%</div>
                        <div class="summary-label">Avg Attendance</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-value">${weeklyData.completedAssignments}</div>
                        <div class="summary-label">Assignments Completed</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-value">${weeklyData.issuesReported}</div>
                        <div class="summary-label">Issues Reported</div>
                    </div>
                </div>
            </div>

            <div class="report-sections">
                <div class="report-section">
                    <h4>Domain Progress</h4>
                    <div class="domain-progress-list">
                        ${Object.entries(weeklyData.domainProgress).map(([domain, progress]) => `
                            <div class="domain-progress-item">
                                <span class="domain-name">${getDomainDisplayName(domain)}</span>
                                <div class="progress-bar">
                                    <div class="progress" style="width: ${progress}%"></div>
                                </div>
                                <span class="progress-percentage">${progress}%</span>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="report-section">
                    <h4>Top Performers</h4>
                    <div class="performers-list">
                        ${weeklyData.topPerformers.map(student => `
                            <div class="performer-item">
                                <div class="student-avatar">${student.name.charAt(0)}</div>
                                <span class="student-name">${student.name}</span>
                                <span class="student-score">${student.score}%</span>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="report-section">
                    <h4>Recommendations</h4>
                    <ul class="recommendations-list">
                        ${weeklyData.recommendations.map(rec => `<li>${rec}</li>`).join('')}
                    </ul>
                </div>
            </div>

            <div class="report-actions">
                <button class="btn btn-primary" onclick="downloadReport('weekly')">
                    <i class="untitledui-download-01"></i> Download PDF
                </button>
                <button class="btn btn-secondary" onclick="emailReport('weekly')">
                    <i class="untitledui-mail-01"></i> Email Report
                </button>
                <button class="btn btn-secondary" onclick="closeModal()">Close</button>
            </div>
        </div>
    `;

    showReportModal('Weekly Progress Report', reportContent);
}

function generateWeeklyReportData() {
    const currentWeek = getCurrentWeek();
    const domainAverages = calculateDomainAverages();
    
    return {
        week: currentWeek,
        totalSessions: trainingSessions.length,
        averageAttendance: getOverallAttendanceRate(),
        completedAssignments: Math.floor(Math.random() * 20) + 10,
        pendingAssignments: Math.floor(Math.random() * 10) + 5,
        issuesReported: Math.floor(Math.random() * 5) + 1,
        issuesResolved: Math.floor(Math.random() * 3) + 1,
        domainProgress: domainAverages,
        topPerformers: getTopPerformers(5),
        recommendations: generateRecommendations()
    };
}

function getTopPerformers(count) {
    return progressData
        .sort((a, b) => b.overall - a.overall)
        .slice(0, count)
        .map(student => ({
            name: student.studentName,
            score: student.overall
        }));
}

function generateRecommendations() {
    const recommendations = [
        'Increase focus on containerization concepts based on lower completion rates',
        'Schedule additional practice sessions for test automation',
        'Consider peer mentoring for students with below 60% progress',
        'Review and update GenAI curriculum based on recent feedback'
    ];
    
    return recommendations.slice(0, Math.floor(Math.random() * 3) + 2);
}

function showAttendanceReport() {
    const attendanceStats = generateAttendanceReportData();
    
    const reportContent = `
        <div class="report-content">
            <div class="report-header">
                <h3>Attendance Analysis Report</h3>
                <p class="report-date">Generated on ${new Date().toLocaleDateString()}</p>
            </div>
            
            <div class="attendance-overview">
                <div class="attendance-stats-grid">
                    <div class="stat-card">
                        <div class="stat-value">${attendanceStats.totalRecords}</div>
                        <div class="stat-label">Total Records</div>
                    </div>
                    <div class="stat-card success">
                        <div class="stat-value">${attendanceStats.presentCount}</div>
                        <div class="stat-label">Present</div>
                    </div>
                    <div class="stat-card warning">
                        <div class="stat-value">${attendanceStats.absentCount}</div>
                        <div class="stat-label">Absent</div>
                    </div>
                    <div class="stat-card info">
                        <div class="stat-value">${attendanceStats.excusedCount}</div>
                        <div class="stat-label">Excused</div>
                    </div>
                </div>
            </div>

            <div class="report-sections">
                <div class="report-section">
                    <h4>Attendance by Domain</h4>
                    <div class="domain-attendance-list">
                        ${Object.entries(attendanceStats.byDomain).map(([domain, stats]) => `
                            <div class="domain-attendance-item">
                                <div class="domain-info">
                                    <span class="domain-name">${getDomainDisplayName(domain)}</span>
                                    <span class="attendance-rate">${stats.rate}%</span>
                                </div>
                                <div class="attendance-breakdown">
                                    <span class="present">Present: ${stats.present}</span>
                                    <span class="absent">Absent: ${stats.absent}</span>
                                    <span class="excused">Excused: ${stats.excused}</span>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="report-section">
                    <h4>Students with Perfect Attendance</h4>
                    <div class="perfect-attendance-list">
                        ${attendanceStats.perfectAttendance.map(student => `
                            <div class="student-item">
                                <div class="student-avatar">${student.charAt(0)}</div>
                                <span>${student}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="report-section">
                    <h4>Students Requiring Attention</h4>
                    <div class="attention-list">
                        ${attendanceStats.needsAttention.map(student => `
                            <div class="student-item warning">
                                <div class="student-avatar">${student.name.charAt(0)}</div>
                                <div class="student-info">
                                    <span class="student-name">${student.name}</span>
                                    <span class="attendance-rate">${student.rate}% attendance</span>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>

            <div class="report-actions">
                <button class="btn btn-primary" onclick="downloadReport('attendance')">
                    <i class="untitledui-download-01"></i> Download PDF
                </button>
                <button class="btn btn-secondary" onclick="closeModal()">Close</button>
            </div>
        </div>
    `;

    showReportModal('Attendance Analysis Report', reportContent);
}

function generateAttendanceReportData() {
    const totalRecords = attendanceData.length;
    const presentCount = attendanceData.filter(r => r.status === 'Present').length;
    const absentCount = attendanceData.filter(r => r.status === 'Absent').length;
    const excusedCount = attendanceData.filter(r => r.status === 'Excused').length;

    // Attendance by domain
    const byDomain = {};
    ['generative-ai', 'containerization', 'devops', 'test-automation'].forEach(domain => {
        const domainRecords = attendanceData.filter(r => r.domain === domain);
        const domainPresent = domainRecords.filter(r => r.status === 'Present').length;
        const domainAbsent = domainRecords.filter(r => r.status === 'Absent').length;
        const domainExcused = domainRecords.filter(r => r.status === 'Excused').length;
        
        byDomain[domain] = {
            present: domainPresent,
            absent: domainAbsent,
            excused: domainExcused,
            rate: domainRecords.length > 0 ? Math.round((domainPresent / domainRecords.length) * 100) : 0
        };
    });

    // Perfect attendance students
    const studentAttendance = {};
    attendanceData.forEach(record => {
        if (!studentAttendance[record.studentName]) {
            studentAttendance[record.studentName] = { present: 0, total: 0 };
        }
        studentAttendance[record.studentName].total++;
        if (record.status === 'Present') {
            studentAttendance[record.studentName].present++;
        }
    });

    const perfectAttendance = Object.entries(studentAttendance)
        .filter(([name, stats]) => stats.present === stats.total && stats.total > 0)
        .map(([name]) => name);

    const needsAttention = Object.entries(studentAttendance)
        .filter(([name, stats]) => (stats.present / stats.total) < 0.8 && stats.total > 0)
        .map(([name, stats]) => ({
            name,
            rate: Math.round((stats.present / stats.total) * 100)
        }))
        .sort((a, b) => a.rate - b.rate);

    return {
        totalRecords,
        presentCount,
        absentCount,
        excusedCount,
        byDomain,
        perfectAttendance,
        needsAttention
    };
}

function showPerformanceReport() {
    const performanceData = generatePerformanceReportData();
    
    const reportContent = `
        <div class="report-content">
            <div class="report-header">
                <h3>Student Performance Analysis</h3>
                <p class="report-date">Generated on ${new Date().toLocaleDateString()}</p>
            </div>
            
            <div class="performance-overview">
                <div class="performance-stats-grid">
                    <div class="stat-card">
                        <div class="stat-value">${performanceData.averageScore}%</div>
                        <div class="stat-label">Average Score</div>
                    </div>
                    <div class="stat-card success">
                        <div class="stat-value">${performanceData.excellent}</div>
                        <div class="stat-label">Excellent (80%+)</div>
                    </div>
                    <div class="stat-card info">
                        <div class="stat-value">${performanceData.good}</div>
                        <div class="stat-label">Good (60-79%)</div>
                    </div>
                    <div class="stat-card warning">
                        <div class="stat-value">${performanceData.needsImprovement}</div>
                        <div class="stat-label">Needs Improvement</div>
                    </div>
                </div>
            </div>

            <div class="report-sections">
                <div class="report-section">
                    <h4>Performance by Domain</h4>
                    <div class="domain-performance-chart">
                        ${Object.entries(performanceData.domainAverages).map(([domain, avg]) => `
                            <div class="domain-performance-bar">
                                <div class="domain-label">${getDomainDisplayName(domain)}</div>
                                <div class="performance-bar">
                                    <div class="performance-fill" style="width: ${avg}%; background-color: ${getPerformanceColor(avg)}"></div>
                                </div>
                                <div class="performance-value">${avg}%</div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="report-section">
                    <h4>Top Performers</h4>
                    <div class="top-performers-list">
                        ${performanceData.topPerformers.map((student, index) => `
                            <div class="performer-rank">
                                <div class="rank-number">${index + 1}</div>
                                <div class="student-avatar">${student.name.charAt(0)}</div>
                                <div class="performer-info">
                                    <div class="student-name">${student.name}</div>
                                    <div class="student-score">${student.overall}% overall</div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="report-section">
                    <h4>Improvement Opportunities</h4>
                    <ul class="opportunities-list">
                        ${performanceData.opportunities.map(opp => `<li>${opp}</li>`).join('')}
                    </ul>
                </div>
            </div>

            <div class="report-actions">
                <button class="btn btn-primary" onclick="downloadReport('performance')">
                    <i class="untitledui-download-01"></i> Download PDF
                </button>
                <button class="btn btn-secondary" onclick="closeModal()">Close</button>
            </div>
        </div>
    `;

    showReportModal('Performance Analysis Report', reportContent);
}

function generatePerformanceReportData() {
    const averageScore = Math.round(
        progressData.reduce((sum, student) => sum + student.overall, 0) / progressData.length
    );

    const excellent = progressData.filter(s => s.overall >= 80).length;
    const good = progressData.filter(s => s.overall >= 60 && s.overall < 80).length;
    const needsImprovement = progressData.filter(s => s.overall < 60).length;

    const domainAverages = calculateDomainAverages();
    const topPerformers = progressData
        .sort((a, b) => b.overall - a.overall)
        .slice(0, 10);

    const opportunities = [
        'Focus on practical exercises for DevOps concepts',
        'Implement peer learning sessions for struggling students',
        'Provide additional resources for containerization',
        'Schedule one-on-one mentoring for students below 60%'
    ];

    return {
        averageScore,
        excellent,
        good,
        needsImprovement,
        domainAverages,
        topPerformers,
        opportunities
    };
}

function getPerformanceColor(percentage) {
    if (percentage >= 80) return '#28a745';
    if (percentage >= 60) return '#17a2b8';
    if (percentage >= 40) return '#ffc107';
    return '#dc3545';
}

function showIssuesReport() {
    const issuesData = generateIssuesReportData();
    
    const reportContent = `
        <div class="report-content">
            <div class="report-header">
                <h3>Issues Tracking Report</h3>
                <p class="report-date">Generated on ${new Date().toLocaleDateString()}</p>
            </div>
            
            <div class="issues-overview">
                <div class="issues-stats-grid">
                    <div class="stat-card">
                        <div class="stat-value">${issuesData.total}</div>
                        <div class="stat-label">Total Issues</div>
                    </div>
                    <div class="stat-card warning">
                        <div class="stat-value">${issuesData.open}</div>
                        <div class="stat-label">Open</div>
                    </div>
                    <div class="stat-card info">
                        <div class="stat-value">${issuesData.inProgress}</div>
                        <div class="stat-label">In Progress</div>
                    </div>
                    <div class="stat-card success">
                        <div class="stat-value">${issuesData.resolved}</div>
                        <div class="stat-label">Resolved</div>
                    </div>
                </div>
            </div>

            <div class="report-sections">
                <div class="report-section">
                    <h4>Issues by Category</h4>
                    <div class="issues-category-list">
                        ${Object.entries(issuesData.byCategory).map(([category, count]) => `
                            <div class="category-item">
                                <div class="category-info">
                                    <span class="category-name">${category}</span>
                                    <span class="category-count">${count} issues</span>
                                </div>
                                <div class="category-bar">
                                    <div class="category-fill" style="width: ${(count / issuesData.total) * 100}%"></div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="report-section">
                    <h4>Recent Issues</h4>
                    <div class="recent-issues-list">
                        ${issuesData.recentIssues.map(issue => `
                            <div class="issue-item">
                                <div class="issue-priority priority-${issue.priority.toLowerCase()}">
                                    ${issue.priority}
                                </div>
                                <div class="issue-info">
                                    <div class="issue-title">${issue.title}</div>
                                    <div class="issue-description">${issue.description}</div>
                                    <div class="issue-meta">
                                        <span class="issue-category">${issue.category}</span>
                                        <span class="issue-status status-${issue.status.toLowerCase().replace(' ', '-')}">${issue.status}</span>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="report-section">
                    <h4>Resolution Recommendations</h4>
                    <ul class="recommendations-list">
                        ${issuesData.recommendations.map(rec => `<li>${rec}</li>`).join('')}
                    </ul>
                </div>
            </div>

            <div class="report-actions">
                <button class="btn btn-primary" onclick="downloadReport('issues')">
                    <i class="untitledui-download-01"></i> Download PDF
                </button>
                <button class="btn btn-secondary" onclick="closeModal()">Close</button>
            </div>
        </div>
    `;

    showReportModal('Issues Tracking Report', reportContent);
}

function generateIssuesReportData() {
    const sampleIssues = [
        {
            id: 1,
            title: 'WebEx Connection Issues',
            description: 'Multiple students experiencing connectivity problems during AI sessions',
            category: 'Technical',
            priority: 'High',
            status: 'In Progress',
            reportedDate: '2025-09-03'
        },
        {
            id: 2,
            title: 'Docker Installation Problems',
            description: 'Students unable to install Docker on Windows machines',
            category: 'Lab Setup',
            priority: 'Medium',
            status: 'Open',
            reportedDate: '2025-09-04'
        },
        {
            id: 3,
            title: 'Missing Assignment Materials',
            description: 'DevOps assignment PDFs not accessible in portal',
            category: 'Content',
            priority: 'Medium',
            status: 'Resolved',
            reportedDate: '2025-09-02'
        },
        {
            id: 4,
            title: 'Lab Environment Access',
            description: 'VPN connectivity issues preventing lab access',
            category: 'Infrastructure',
            priority: 'High',
            status: 'Open',
            reportedDate: '2025-09-05'
        }
    ];

    const total = sampleIssues.length;
    const open = sampleIssues.filter(i => i.status === 'Open').length;
    const inProgress = sampleIssues.filter(i => i.status === 'In Progress').length;
    const resolved = sampleIssues.filter(i => i.status === 'Resolved').length;

    const byCategory = {};
    sampleIssues.forEach(issue => {
        byCategory[issue.category] = (byCategory[issue.category] || 0) + 1;
    });

    const recommendations = [
        'Implement backup WebEx rooms for each session',
        'Create pre-installation guides with troubleshooting steps',
        'Set up dedicated IT support during training hours',
        'Establish clear escalation procedures for critical issues'
    ];

    return {
        total,
        open,
        inProgress,
        resolved,
        byCategory,
        recentIssues: sampleIssues,
        recommendations
    };
}

function showReportModal(title, content) {
    const existingModal = document.getElementById('reportModal');
    if (existingModal) {
        existingModal.remove();
    }

    const modal = document.createElement('div');
    modal.id = 'reportModal';
    modal.className = 'modal report-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>${title}</h3>
                <button class="close-btn" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                ${content}
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    
    document.getElementById('modalOverlay').classList.add('show');
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
}

function downloadReport(type) {
    showNotification(`Downloading ${type} report...`, 'info');
    
    // Simulate download
    setTimeout(() => {
        const link = document.createElement('a');
        link.href = '#';
        link.download = `${type}-report-${new Date().toISOString().split('T')[0]}.pdf`;
        link.click();
        showNotification('Report downloaded successfully!', 'success');
    }, 2000);
}

function emailReport(type) {
    showNotification(`Preparing ${type} report for email...`, 'info');
    
    // Simulate email preparation
    setTimeout(() => {
        showNotification('Report sent to stakeholders!', 'success');
    }, 2000);
}

// Reports-specific styles
const reportsStyles = `
    .reports-overview {
        margin-bottom: 40px;
    }

    .overview-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }

    .overview-stat {
        background: white;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .stat-icon {
        width: 60px;
        height: 60px;
        border-radius: 12px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1.5rem;
    }

    .stat-content h3 {
        font-size: 2rem;
        font-weight: 700;
        color: #333;
        margin-bottom: 5px;
    }

    .stat-content p {
        color: #666;
        font-size: 0.9rem;
    }

    .report-modal .modal-content {
        max-width: 900px;
        max-height: 90vh;
        overflow-y: auto;
    }

    .report-header {
        text-align: center;
        margin-bottom: 30px;
        padding-bottom: 20px;
        border-bottom: 2px solid #e0e0e0;
    }

    .report-date {
        color: #666;
        font-style: italic;
        margin-top: 5px;
    }

    .summary-grid,
    .attendance-stats-grid,
    .performance-stats-grid,
    .issues-stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }

    .summary-item,
    .stat-card {
        background: #f8f9fa;
        padding: 20px;
        border-radius: 8px;
        text-align: center;
    }

    .summary-value,
    .stat-value {
        font-size: 2rem;
        font-weight: 700;
        color: #333;
        margin-bottom: 5px;
    }

    .summary-label,
    .stat-label {
        color: #666;
        font-size: 0.9rem;
    }

    .stat-card.success { border-left: 4px solid #28a745; }
    .stat-card.warning { border-left: 4px solid #ffc107; }
    .stat-card.info { border-left: 4px solid #17a2b8; }

    .report-section {
        background: #f8f9fa;
        padding: 25px;
        border-radius: 8px;
        margin-bottom: 25px;
    }

    .report-section h4 {
        color: #333;
        margin-bottom: 20px;
        font-size: 1.2rem;
    }

    .domain-progress-item {
        display: flex;
        align-items: center;
        gap: 15px;
        margin-bottom: 15px;
        padding: 15px;
        background: white;
        border-radius: 6px;
    }

    .domain-name {
        min-width: 120px;
        font-weight: 600;
        color: #333;
    }

    .progress-percentage {
        min-width: 50px;
        font-weight: 600;
        color: #667eea;
    }

    .performers-list,
    .top-performers-list {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .performer-item,
    .performer-rank {
        display: flex;
        align-items: center;
        gap: 15px;
        padding: 15px;
        background: white;
        border-radius: 6px;
    }

    .rank-number {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        background: #667eea;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
    }

    .student-score {
        margin-left: auto;
        font-weight: 600;
        color: #667eea;
    }

    .recommendations-list,
    .opportunities-list {
        list-style: none;
        padding: 0;
    }

    .recommendations-list li,
    .opportunities-list li {
        background: white;
        padding: 15px;
        border-radius: 6px;
        margin-bottom: 10px;
        border-left: 4px solid #667eea;
    }

    .domain-performance-bar {
        display: flex;
        align-items: center;
        gap: 15px;
        margin-bottom: 15px;
        padding: 10px;
        background: white;
        border-radius: 6px;
    }

    .domain-label {
        min-width: 120px;
        font-weight: 600;
    }

    .performance-bar {
        flex: 1;
        height: 20px;
        background: #e0e0e0;
        border-radius: 10px;
        overflow: hidden;
    }

    .performance-fill {
        height: 100%;
        border-radius: 10px;
        transition: width 0.3s ease;
    }

    .performance-value {
        min-width: 50px;
        font-weight: 600;
    }

    .issue-item {
        display: flex;
        gap: 15px;
        padding: 15px;
        background: white;
        border-radius: 6px;
        margin-bottom: 15px;
    }

    .issue-priority {
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
        white-space: nowrap;
    }

    .priority-high { background: #f8d7da; color: #721c24; }
    .priority-medium { background: #fff3cd; color: #856404; }
    .priority-low { background: #d4edda; color: #155724; }

    .issue-title {
        font-weight: 600;
        color: #333;
        margin-bottom: 5px;
    }

    .issue-description {
        color: #666;
        font-size: 0.9rem;
        margin-bottom: 10px;
    }

    .issue-meta {
        display: flex;
        gap: 15px;
        align-items: center;
    }

    .issue-category {
        background: #e9ecef;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 0.8rem;
        color: #495057;
    }

    .issue-status {
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 0.8rem;
        font-weight: 500;
    }

    .status-open { background: #f8d7da; color: #721c24; }
    .status-in-progress { background: #cce7ff; color: #004085; }
    .status-resolved { background: #d4edda; color: #155724; }

    .report-actions {
        display: flex;
        gap: 15px;
        justify-content: center;
        margin-top: 30px;
        padding-top: 25px;
        border-top: 1px solid #e0e0e0;
    }
`;

// Inject reports styles
if (!document.getElementById('reports-styles')) {
    const styleSheet = document.createElement('style');
    styleSheet.id = 'reports-styles';
    styleSheet.textContent = reportsStyles;
    document.head.appendChild(styleSheet);
}
