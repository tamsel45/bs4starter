// Trainer Management System for Campus Training Program 2025
// Manages 20 Senior Trainers and 40 Mid-Level Trainers

// Sample trainer data
const trainersData = [
    // Senior Trainers
    {
        id: 1,
        name: "Dr. Sarah Johnson",
        level: "senior",
        email: "sarah.johnson@company.com",
        domains: ["generative-ai", "test-automation"],
        status: "available",
        phone: "+1-555-0101",
        experience: "15 years",
        currentLoad: 2,
        maxLoad: 5,
        availability: {
            monday: { start: "09:00", end: "17:00" },
            tuesday: { start: "09:00", end: "17:00" },
            wednesday: { start: "09:00", end: "17:00" },
            thursday: { start: "09:00", end: "17:00" },
            friday: { start: "09:00", end: "17:00" }
        },
        certifications: ["AWS Certified", "Google Cloud Professional"],
        bio: "AI/ML specialist with extensive experience in machine learning and test automation frameworks."
    },
    {
        id: 2,
        name: "Michael Chen",
        level: "senior",
        email: "michael.chen@company.com",
        domains: ["containerization", "devops"],
        status: "busy",
        phone: "+1-555-0102",
        experience: "12 years",
        currentLoad: 5,
        maxLoad: 5,
        availability: {
            monday: { start: "08:00", end: "16:00" },
            tuesday: { start: "08:00", end: "16:00" },
            wednesday: { start: "08:00", end: "16:00" },
            thursday: { start: "08:00", end: "16:00" },
            friday: { start: "08:00", end: "16:00" }
        },
        certifications: ["Docker Certified", "Kubernetes Administrator", "Azure DevOps"],
        bio: "DevOps architect with deep expertise in containerization and CI/CD pipelines."
    },
    // Mid-Level Trainers
    {
        id: 21,
        name: "Jennifer Smith",
        level: "mid",
        email: "jennifer.smith@company.com",
        domains: ["generative-ai"],
        status: "available",
        phone: "+1-555-0121",
        experience: "6 years",
        currentLoad: 1,
        maxLoad: 3,
        availability: {
            monday: { start: "09:30", end: "17:30" },
            tuesday: { start: "09:30", end: "17:30" },
            wednesday: { start: "09:30", end: "17:30" },
            thursday: { start: "09:30", end: "17:30" },
            friday: { start: "09:30", end: "17:30" }
        },
        certifications: ["Python Developer", "Machine Learning Specialist"],
        bio: "AI enthusiast with practical experience in generative AI applications."
    },
    {
        id: 22,
        name: "David Wilson",
        level: "mid",
        email: "david.wilson@company.com",
        domains: ["devops", "test-automation"],
        status: "out-of-office",
        phone: "+1-555-0122",
        experience: "5 years",
        currentLoad: 0,
        maxLoad: 3,
        availability: {},
        certifications: ["Jenkins Certified", "Selenium WebDriver"],
        bio: "Test automation specialist with DevOps integration experience."
    }
];

// Initialize trainer management
function initializeTrainerManagement() {
    loadTrainers();
    setupTrainerFilters();
    updateTrainerStats();
}

// Load and display trainers
function loadTrainers() {
    const container = document.getElementById('trainersGrid');
    if (!container) return;

    const filteredTrainers = getFilteredTrainers();
    
    container.innerHTML = filteredTrainers.map(trainer => `
        <div class="trainer-card ${trainer.level}" data-id="${trainer.id}">
            <div class="trainer-header">
                <div class="trainer-avatar">
                    <i class="untitledui-user-circle"></i>
                </div>
                <div class="trainer-info">
                    <h3>${trainer.name}</h3>
                    <p class="trainer-level">${trainer.level.charAt(0).toUpperCase() + trainer.level.slice(1)} Trainer</p>
                    <p class="trainer-experience">${trainer.experience} experience</p>
                </div>
                <div class="trainer-status ${trainer.status}">
                    <i class="untitledui-${getStatusIcon(trainer.status)}"></i>
                    ${trainer.status.replace('-', ' ').toUpperCase()}
                </div>
            </div>
            
            <div class="trainer-details">
                <div class="contact-info">
                    <p><i class="untitledui-mail-01"></i> ${trainer.email}</p>
                    <p><i class="untitledui-phone-01"></i> ${trainer.phone}</p>
                </div>
                
                <div class="domains">
                    <h4>Domain Expertise:</h4>
                    <div class="domain-tags">
                        ${trainer.domains.map(domain => 
                            `<span class="domain-tag ${domain}">${formatDomainName(domain)}</span>`
                        ).join('')}
                    </div>
                </div>
                
                <div class="workload">
                    <h4>Current Workload:</h4>
                    <div class="workload-bar">
                        <div class="workload-progress" style="width: ${(trainer.currentLoad / trainer.maxLoad) * 100}%"></div>
                    </div>
                    <span>${trainer.currentLoad}/${trainer.maxLoad} sessions</span>
                </div>
                
                <div class="certifications">
                    <h4>Certifications:</h4>
                    <div class="cert-tags">
                        ${trainer.certifications.map(cert => 
                            `<span class="cert-tag">${cert}</span>`
                        ).join('')}
                    </div>
                </div>
                
                <div class="trainer-actions">
                    <button class="btn btn-sm btn-primary" onclick="viewTrainerProfile(${trainer.id})">
                        <i class="untitledui-eye"></i> View Profile
                    </button>
                    <button class="btn btn-sm btn-secondary" onclick="assignTrainerToSession(${trainer.id})">
                        <i class="untitledui-calendar-plus-01"></i> Assign
                    </button>
                    <button class="btn btn-sm btn-outline" onclick="updateTrainerStatus(${trainer.id})">
                        <i class="untitledui-edit-01"></i> Update Status
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Get filtered trainers based on current filter selections
function getFilteredTrainers() {
    const levelFilter = document.getElementById('trainerLevelFilter')?.value || '';
    const domainFilter = document.getElementById('trainerDomainFilter')?.value || '';
    const statusFilter = document.getElementById('trainerStatusFilter')?.value || '';
    
    return trainersData.filter(trainer => {
        const levelMatch = !levelFilter || trainer.level === levelFilter;
        const domainMatch = !domainFilter || trainer.domains.includes(domainFilter);
        const statusMatch = !statusFilter || trainer.status === statusFilter;
        
        return levelMatch && domainMatch && statusMatch;
    });
}

// Setup trainer filter event listeners
function setupTrainerFilters() {
    const filters = ['trainerLevelFilter', 'trainerDomainFilter', 'trainerStatusFilter'];
    
    filters.forEach(filterId => {
        const filter = document.getElementById(filterId);
        if (filter) {
            filter.addEventListener('change', () => {
                loadTrainers();
                updateTrainerStats();
            });
        }
    });
}

// Update trainer statistics
function updateTrainerStats() {
    const filteredTrainers = getFilteredTrainers();
    const seniorCount = filteredTrainers.filter(t => t.level === 'senior').length;
    const midCount = filteredTrainers.filter(t => t.level === 'mid').length;
    const availableCount = filteredTrainers.filter(t => t.status === 'available').length;
    const busyCount = filteredTrainers.filter(t => t.status === 'busy').length;
    const outCount = filteredTrainers.filter(t => t.status === 'out-of-office' || t.status === 'permissions').length;
    
    // Update stat badges if they exist
    const statBadges = document.querySelectorAll('.trainer-stats .stat-badge');
    if (statBadges.length >= 5) {
        statBadges[2].textContent = `${availableCount} Available`;
        statBadges[3].textContent = `${busyCount} Busy`;
        statBadges[4].textContent = `${outCount} Out of Office`;
    }
}

// Get status icon for trainer
function getStatusIcon(status) {
    switch (status) {
        case 'available': return 'check-circle';
        case 'busy': return 'clock';
        case 'out-of-office': return 'x-circle';
        case 'permissions': return 'user-clock';
        default: return 'help-circle';
    }
}

// Format domain name for display
function formatDomainName(domain) {
    const names = {
        'generative-ai': 'Generative AI',
        'containerization': 'Containerization',
        'devops': 'DevOps',
        'test-automation': 'Test Automation'
    };
    return names[domain] || domain;
}

// Trainer management functions
function viewTrainerProfile(trainerId) {
    const trainer = trainersData.find(t => t.id === trainerId);
    if (!trainer) return;
    
    // Create detailed profile modal
    const modalContent = `
        <div class="trainer-profile-modal">
            <div class="profile-header">
                <div class="profile-avatar">
                    <i class="untitledui-user-circle"></i>
                </div>
                <div class="profile-info">
                    <h2>${trainer.name}</h2>
                    <p class="profile-title">${trainer.level.charAt(0).toUpperCase() + trainer.level.slice(1)} Trainer</p>
                    <p class="profile-experience">${trainer.experience} of experience</p>
                </div>
                <div class="profile-status ${trainer.status}">
                    <i class="untitledui-${getStatusIcon(trainer.status)}"></i>
                    ${trainer.status.replace('-', ' ').toUpperCase()}
                </div>
            </div>
            
            <div class="profile-details">
                <div class="detail-section">
                    <h3>Contact Information</h3>
                    <p><i class="untitledui-mail-01"></i> ${trainer.email}</p>
                    <p><i class="untitledui-phone-01"></i> ${trainer.phone}</p>
                </div>
                
                <div class="detail-section">
                    <h3>Domain Expertise</h3>
                    <div class="domain-tags">
                        ${trainer.domains.map(domain => 
                            `<span class="domain-tag ${domain}">${formatDomainName(domain)}</span>`
                        ).join('')}
                    </div>
                </div>
                
                <div class="detail-section">
                    <h3>Certifications</h3>
                    <div class="cert-list">
                        ${trainer.certifications.map(cert => 
                            `<div class="cert-item"><i class="untitledui-award-01"></i> ${cert}</div>`
                        ).join('')}
                    </div>
                </div>
                
                <div class="detail-section">
                    <h3>Biography</h3>
                    <p>${trainer.bio}</p>
                </div>
                
                <div class="detail-section">
                    <h3>Current Workload</h3>
                    <div class="workload-details">
                        <div class="workload-bar">
                            <div class="workload-progress" style="width: ${(trainer.currentLoad / trainer.maxLoad) * 100}%"></div>
                        </div>
                        <p>${trainer.currentLoad} of ${trainer.maxLoad} maximum sessions assigned</p>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h3>Availability Schedule</h3>
                    <div class="availability-grid">
                        ${Object.entries(trainer.availability).map(([day, times]) => `
                            <div class="availability-item">
                                <strong>${day.charAt(0).toUpperCase() + day.slice(1)}:</strong>
                                ${times.start} - ${times.end}
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
            
            <div class="profile-actions">
                <button class="btn btn-primary" onclick="assignTrainerToSession(${trainer.id})">
                    <i class="untitledui-calendar-plus-01"></i> Assign to Session
                </button>
                <button class="btn btn-secondary" onclick="updateTrainerStatus(${trainer.id})">
                    <i class="untitledui-edit-01"></i> Update Status
                </button>
                <button class="btn btn-outline" onclick="contactTrainer(${trainer.id})">
                    <i class="untitledui-mail-01"></i> Send Message
                </button>
            </div>
        </div>
    `;
    
    showModal('Trainer Profile', modalContent);
}

function assignTrainerToSession(trainerId) {
    const trainer = trainersData.find(t => t.id === trainerId);
    if (!trainer) return;
    
    showMessage('Feature Coming Soon', `Trainer assignment for ${trainer.name} will be implemented with calendar integration.`, 'info');
}

function updateTrainerStatus(trainerId) {
    const trainer = trainersData.find(t => t.id === trainerId);
    if (!trainer) return;
    
    const statusOptions = [
        { value: 'available', label: 'Available' },
        { value: 'busy', label: 'Busy' },
        { value: 'out-of-office', label: 'Out of Office' },
        { value: 'permissions', label: 'On Permissions' }
    ];
    
    const modalContent = `
        <div class="status-update-form">
            <h3>Update Status for ${trainer.name}</h3>
            <div class="form-group">
                <label for="newStatus">New Status:</label>
                <select id="newStatus" class="form-control">
                    ${statusOptions.map(option => 
                        `<option value="${option.value}" ${trainer.status === option.value ? 'selected' : ''}>
                            ${option.label}
                        </option>`
                    ).join('')}
                </select>
            </div>
            <div class="form-group">
                <label for="statusNote">Note (optional):</label>
                <textarea id="statusNote" class="form-control" placeholder="Reason for status change..."></textarea>
            </div>
            <div class="form-actions">
                <button class="btn btn-primary" onclick="saveTrainerStatus(${trainerId})">
                    <i class="untitledui-save-01"></i> Update Status
                </button>
                <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
            </div>
        </div>
    `;
    
    showModal('Update Trainer Status', modalContent);
}

function saveTrainerStatus(trainerId) {
    const newStatus = document.getElementById('newStatus')?.value;
    const note = document.getElementById('statusNote')?.value;
    
    if (!newStatus) return;
    
    const trainer = trainersData.find(t => t.id === trainerId);
    if (trainer) {
        trainer.status = newStatus;
        loadTrainers();
        updateTrainerStats();
        closeModal();
        showMessage('Success', `Status updated for ${trainer.name}`, 'success');
    }
}

function contactTrainer(trainerId) {
    const trainer = trainersData.find(t => t.id === trainerId);
    if (!trainer) return;
    
    showMessage('Contact Trainer', `Email integration for ${trainer.name} (${trainer.email}) will be implemented.`, 'info');
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('trainersGrid')) {
        initializeTrainerManagement();
    }
});
