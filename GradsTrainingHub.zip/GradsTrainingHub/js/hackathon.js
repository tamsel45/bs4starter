// Hackathon Management System for Campus Training Program 2025
// Manages final hackathon event within the 6-week training duration

// Hackathon configuration
const HACKATHON_CONFIG = {
    name: "Campus Training Program 2025 - Final Hackathon",
    startDate: "2025-10-13T09:30:00Z",
    endDate: "2025-10-15T13:30:00Z",
    duration: "3 days",
    maxTeamSize: 4,
    minTeamSize: 2,
    totalParticipants: 68,
    domains: [
        { id: 'generative-ai', name: 'Generative AI', color: '#4A90E2' },
        { id: 'containerization', name: 'Containerization', color: '#7ED321' },
        { id: 'devops', name: 'DevOps', color: '#F5A623' },
        { id: 'test-automation', name: 'Test Automation', color: '#D0021B' }
    ],
    challenges: [
        {
            id: 1,
            title: "AI-Powered DevOps Assistant",
            description: "Create an AI assistant that helps with DevOps tasks using generative AI",
            domains: ['generative-ai', 'devops'],
            difficulty: 'Advanced',
            estimatedTime: '2-3 days'
        },
        {
            id: 2,
            title: "Containerized Test Automation Framework",
            description: "Build a scalable test automation framework using containers",
            domains: ['containerization', 'test-automation'],
            difficulty: 'Intermediate',
            estimatedTime: '2 days'
        },
        {
            id: 3,
            title: "Smart Resource Orchestration",
            description: "Develop an intelligent container orchestration system",
            domains: ['containerization', 'devops'],
            difficulty: 'Advanced',
            estimatedTime: '2-3 days'
        },
        {
            id: 4,
            title: "AI-Enhanced Testing Suite",
            description: "Create AI-powered automated testing tools",
            domains: ['generative-ai', 'test-automation'],
            difficulty: 'Intermediate',
            estimatedTime: '2 days'
        }
    ]
};

// Teams and participants data
let hackathonTeams = [];
let hackathonParticipants = [];

// Initialize hackathon management
function initializeHackathon() {
    generateParticipants();
    setupHackathonUI();
    loadHackathonDashboard();
}

// Generate sample participants data
function generateParticipants() {
    const firstNames = ['John', 'Sarah', 'Michael', 'Jennifer', 'David', 'Emily', 'Robert', 'Lisa', 'James', 'Maria'];
    const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez'];
    
    for (let i = 1; i <= 68; i++) {
        const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
        const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
        const domains = HACKATHON_CONFIG.domains.slice(0, Math.floor(Math.random() * 2) + 1);
        
        hackathonParticipants.push({
            id: i,
            name: `${firstName} ${lastName}`,
            email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@student.com`,
            primaryDomain: domains[0].id,
            secondaryDomains: domains.slice(1).map(d => d.id),
            skills: generateRandomSkills(),
            teamId: null,
            registrationDate: new Date(2025, 7, Math.floor(Math.random() * 13) + 1).toISOString(),
            status: 'registered'
        });
    }
}

// Generate random skills for participants
function generateRandomSkills() {
    const allSkills = [
        'Python', 'JavaScript', 'Docker', 'Kubernetes', 'AWS', 'Azure', 'Git', 'Jenkins',
        'Selenium', 'PyTest', 'React', 'Node.js', 'TensorFlow', 'PyTorch', 'Ansible', 'Terraform'
    ];
    const numSkills = Math.floor(Math.random() * 6) + 3; // 3-8 skills
    return allSkills.sort(() => 0.5 - Math.random()).slice(0, numSkills);
}

// Setup hackathon UI
function setupHackathonUI() {
    const hackathonSection = document.getElementById('assignments');
    if (!hackathonSection) return;
    
    // Add hackathon-specific content to assignments section
    const hackathonContainer = document.createElement('div');
    hackathonContainer.className = 'hackathon-container';
    hackathonContainer.innerHTML = `
        <div class="hackathon-header">
            <h3><i class="untitledui-trophy-01"></i> ${HACKATHON_CONFIG.name}</h3>
            <div class="hackathon-timeline">
                <span class="timeline-item">
                    <i class="untitledui-calendar-date"></i>
                    Start: October 13, 2025 (9:30 AM)
                </span>
                <span class="timeline-item">
                    <i class="untitledui-calendar-date"></i>
                    End: October 15, 2025 (1:30 PM)
                </span>
                <span class="timeline-item">
                    <i class="untitledui-users-01"></i>
                    68 Participants
                </span>
            </div>
        </div>
        
        <div class="hackathon-tabs">
            <button class="tab-btn active" onclick="showHackathonTab('overview')">Overview</button>
            <button class="tab-btn" onclick="showHackathonTab('teams')">Teams</button>
            <button class="tab-btn" onclick="showHackathonTab('challenges')">Challenges</button>
            <button class="tab-btn" onclick="showHackathonTab('participants')">Participants</button>
            <button class="tab-btn" onclick="showHackathonTab('judging')">Judging</button>
        </div>
        
        <div id="hackathon-content">
            <!-- Content will be loaded dynamically -->
        </div>
    `;
    
    // Insert after assignment controls
    const controlsDiv = hackathonSection.querySelector('.assignment-controls');
    if (controlsDiv) {
        controlsDiv.parentNode.insertBefore(hackathonContainer, controlsDiv.nextSibling);
    }
}

// Show hackathon tab content
function showHackathonTab(tab) {
    // Update active tab
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    const content = document.getElementById('hackathon-content');
    if (!content) return;
    
    switch (tab) {
        case 'overview':
            content.innerHTML = getOverviewContent();
            break;
        case 'teams':
            content.innerHTML = getTeamsContent();
            break;
        case 'challenges':
            content.innerHTML = getChallengesContent();
            break;
        case 'participants':
            content.innerHTML = getParticipantsContent();
            break;
        case 'judging':
            content.innerHTML = getJudgingContent();
            break;
    }
}

// Get overview tab content
function getOverviewContent() {
    const registeredCount = hackathonParticipants.filter(p => p.status === 'registered').length;
    const teamsCount = hackathonTeams.length;
    const averageTeamSize = teamsCount > 0 ? Math.round(registeredCount / teamsCount) : 0;
    
    return `
        <div class="hackathon-overview">
            <div class="overview-stats">
                <div class="stat-card">
                    <h4>Registered Participants</h4>
                    <span class="stat-number">${registeredCount}</span>
                </div>
                <div class="stat-card">
                    <h4>Formed Teams</h4>
                    <span class="stat-number">${teamsCount}</span>
                </div>
                <div class="stat-card">
                    <h4>Available Challenges</h4>
                    <span class="stat-number">${HACKATHON_CONFIG.challenges.length}</span>
                </div>
                <div class="stat-card">
                    <h4>Days Remaining</h4>
                    <span class="stat-number">${getDaysUntilHackathon()}</span>
                </div>
            </div>
            
            <div class="hackathon-info">
                <div class="info-section">
                    <h4>Event Details</h4>
                    <ul>
                        <li><strong>Duration:</strong> ${HACKATHON_CONFIG.duration}</li>
                        <li><strong>Team Size:</strong> ${HACKATHON_CONFIG.minTeamSize}-${HACKATHON_CONFIG.maxTeamSize} members</li>
                        <li><strong>Format:</strong> Hybrid (On-site + Remote via WebEx)</li>
                        <li><strong>Domains:</strong> ${HACKATHON_CONFIG.domains.map(d => d.name).join(', ')}</li>
                    </ul>
                </div>
                
                <div class="info-section">
                    <h4>Schedule</h4>
                    <div class="schedule-timeline">
                        <div class="timeline-item">
                            <strong>Day 1 (Oct 13):</strong> Opening Ceremony, Team Formation, Challenge Selection
                        </div>
                        <div class="timeline-item">
                            <strong>Day 2 (Oct 14):</strong> Development Phase, Mentor Sessions
                        </div>
                        <div class="timeline-item">
                            <strong>Day 3 (Oct 15):</strong> Final Presentations, Judging, Awards Ceremony
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="action-buttons">
                <button class="btn btn-primary" onclick="openTeamFormation()">
                    <i class="untitledui-users-01"></i> Form Teams
                </button>
                <button class="btn btn-secondary" onclick="exportParticipantsList()">
                    <i class="untitledui-download-01"></i> Export Participants
                </button>
                <button class="btn btn-success" onclick="setupJudgingCriteria()">
                    <i class="untitledui-gavel"></i> Setup Judging
                </button>
            </div>
        </div>
    `;
}

// Get teams tab content
function getTeamsContent() {
    return `
        <div class="teams-management">
            <div class="teams-header">
                <h4>Team Management</h4>
                <div class="team-actions">
                    <button class="btn btn-primary" onclick="createTeam()">
                        <i class="untitledui-plus"></i> Create Team
                    </button>
                    <button class="btn btn-secondary" onclick="autoFormTeams()">
                        <i class="untitledui-magic-wand-01"></i> Auto-Form Teams
                    </button>
                </div>
            </div>
            
            <div class="teams-grid" id="teamsGrid">
                ${hackathonTeams.length > 0 ? renderTeams() : '<p class="no-teams">No teams formed yet. Use "Create Team" or "Auto-Form Teams" to get started.</p>'}
            </div>
        </div>
    `;
}

// Get challenges tab content
function getChallengesContent() {
    return `
        <div class="challenges-management">
            <div class="challenges-header">
                <h4>Hackathon Challenges</h4>
                <button class="btn btn-primary" onclick="addChallenge()">
                    <i class="untitledui-plus"></i> Add Challenge
                </button>
            </div>
            
            <div class="challenges-grid">
                ${HACKATHON_CONFIG.challenges.map(challenge => `
                    <div class="challenge-card">
                        <div class="challenge-header">
                            <h5>${challenge.title}</h5>
                            <span class="difficulty-badge ${challenge.difficulty.toLowerCase()}">${challenge.difficulty}</span>
                        </div>
                        <p class="challenge-description">${challenge.description}</p>
                        <div class="challenge-details">
                            <div class="challenge-domains">
                                ${challenge.domains.map(domain => 
                                    `<span class="domain-tag ${domain}">${formatDomainName(domain)}</span>`
                                ).join('')}
                            </div>
                            <div class="challenge-time">
                                <i class="untitledui-clock"></i> ${challenge.estimatedTime}
                            </div>
                        </div>
                        <div class="challenge-actions">
                            <button class="btn btn-sm btn-primary" onclick="selectChallenge(${challenge.id})">
                                Select Challenge
                            </button>
                            <button class="btn btn-sm btn-secondary" onclick="editChallenge(${challenge.id})">
                                <i class="untitledui-edit-01"></i>
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// Get participants tab content
function getParticipantsContent() {
    return `
        <div class="participants-management">
            <div class="participants-header">
                <h4>Hackathon Participants</h4>
                <div class="participant-filters">
                    <select id="participantDomainFilter" onchange="filterParticipants()">
                        <option value="">All Domains</option>
                        ${HACKATHON_CONFIG.domains.map(domain => 
                            `<option value="${domain.id}">${domain.name}</option>`
                        ).join('')}
                    </select>
                    <select id="participantStatusFilter" onchange="filterParticipants()">
                        <option value="">All Status</option>
                        <option value="registered">Registered</option>
                        <option value="team-assigned">Team Assigned</option>
                        <option value="not-assigned">Not Assigned</option>
                    </select>
                </div>
            </div>
            
            <div class="participants-grid" id="participantsGrid">
                ${renderParticipants()}
            </div>
        </div>
    `;
}

// Get judging tab content
function getJudgingContent() {
    return `
        <div class="judging-management">
            <h4>Judging & Evaluation</h4>
            <div class="judging-criteria">
                <div class="criteria-section">
                    <h5>Evaluation Criteria</h5>
                    <div class="criteria-list">
                        <div class="criteria-item">
                            <strong>Innovation & Creativity (25%)</strong>
                            <p>Originality of solution and creative approach to problem-solving</p>
                        </div>
                        <div class="criteria-item">
                            <strong>Technical Implementation (30%)</strong>
                            <p>Code quality, architecture, and use of technologies</p>
                        </div>
                        <div class="criteria-item">
                            <strong>Problem Solution (25%)</strong>
                            <p>How well the solution addresses the challenge requirements</p>
                        </div>
                        <div class="criteria-item">
                            <strong>Presentation & Demo (20%)</strong>
                            <p>Quality of presentation and demonstration of the solution</p>
                        </div>
                    </div>
                </div>
                
                <div class="judges-section">
                    <h5>Judging Panel</h5>
                    <div class="judges-list">
                        <div class="judge-card">
                            <i class="untitledui-user-check-01"></i>
                            <h6>Industry Expert Panel</h6>
                            <p>External industry professionals and domain experts</p>
                        </div>
                        <div class="judge-card">
                            <i class="untitledui-presentation-chart-01"></i>
                            <h6>Senior Trainers</h6>
                            <p>Internal senior trainers with domain expertise</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="judging-actions">
                <button class="btn btn-primary" onclick="setupJudgingPanel()">
                    <i class="untitledui-users-01"></i> Setup Judging Panel
                </button>
                <button class="btn btn-secondary" onclick="createEvaluationForm()">
                    <i class="untitledui-clipboard-check"></i> Create Evaluation Form
                </button>
            </div>
        </div>
    `;
}

// Utility functions
function getDaysUntilHackathon() {
    const today = new Date();
    const hackathonStart = new Date(HACKATHON_CONFIG.startDate);
    const timeDiff = hackathonStart.getTime() - today.getTime();
    const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
    return Math.max(0, daysDiff);
}

function formatDomainName(domain) {
    const names = {
        'generative-ai': 'Generative AI',
        'containerization': 'Containerization',
        'devops': 'DevOps',
        'test-automation': 'Test Automation'
    };
    return names[domain] || domain;
}

function renderTeams() {
    return hackathonTeams.map(team => `
        <div class="team-card">
            <h5>${team.name}</h5>
            <div class="team-members">
                ${team.members.map(member => `
                    <div class="member-item">
                        <i class="untitledui-user-01"></i> ${member.name}
                    </div>
                `).join('')}
            </div>
            <div class="team-actions">
                <button class="btn btn-sm btn-primary" onclick="viewTeam(${team.id})">View</button>
                <button class="btn btn-sm btn-secondary" onclick="editTeam(${team.id})">Edit</button>
            </div>
        </div>
    `).join('');
}

function renderParticipants() {
    return hackathonParticipants.slice(0, 20).map(participant => `
        <div class="participant-card">
            <div class="participant-info">
                <h6>${participant.name}</h6>
                <p>${participant.email}</p>
                <span class="domain-tag ${participant.primaryDomain}">${formatDomainName(participant.primaryDomain)}</span>
            </div>
            <div class="participant-skills">
                ${participant.skills.slice(0, 3).map(skill => 
                    `<span class="skill-tag">${skill}</span>`
                ).join('')}
            </div>
        </div>
    `).join('') + '<p class="load-more">... and 48 more participants</p>';
}

// Hackathon management functions
function setupHackathon() {
    showModal('Setup Hackathon', `
        <div class="hackathon-setup">
            <h3>Hackathon Event Setup</h3>
            <p>This will initialize the hackathon management system with all participants and challenges.</p>
            <div class="setup-actions">
                <button class="btn btn-primary" onclick="initializeHackathon(); closeModal();">
                    <i class="untitledui-trophy-01"></i> Initialize Hackathon
                </button>
                <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
            </div>
        </div>
    `);
}

function loadHackathonDashboard() {
    // Load overview tab by default
    setTimeout(() => {
        showHackathonTab('overview');
    }, 100);
}

// Team management functions
function createTeam() {
    showMessage('Team Creation', 'Team formation interface will be implemented with drag-and-drop functionality.', 'info');
}

function autoFormTeams() {
    showMessage('Auto Formation', 'Automatic team formation based on skills and domain preferences will be implemented.', 'info');
}

// Challenge management functions
function addChallenge() {
    showMessage('Add Challenge', 'Challenge creation interface will be implemented.', 'info');
}

function selectChallenge(challengeId) {
    const challenge = HACKATHON_CONFIG.challenges.find(c => c.id === challengeId);
    if (challenge) {
        showMessage('Challenge Selected', `Challenge "${challenge.title}" selected for team assignment.`, 'success');
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('assignments')) {
        initializeHackathon();
    }
});
