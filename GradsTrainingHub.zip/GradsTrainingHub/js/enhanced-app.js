// Enhanced Training Portal JavaScript
// Author: Campus Training Program 2025
// Features: Role-based dashboards, Charts, Attendance tracking, Q&A system

// Master Data Structure
const masterData = {
    // Training Program Details
    program: {
        name: "Campus Training Program 2025",
        startDate: "2025-09-01",
        endDate: "2025-10-15",
        totalParticipants: 68,
        totalTrainers: 60,
        domains: ["Frontend Development", "Backend Development", "Data Science", "Cloud Computing"]
    },
    
    // User Data
    users: {
        admin: { name: "John Doe", role: "Module Lead", id: "ML001" },
        trainer: { name: "Sarah Johnson", role: "Senior Trainer", id: "TR001" },
        graduate: { name: "Mike Chen", role: "Graduate", id: "GR001" }
    },
    
    // Sample Data for demonstration
    graduates: [
        { id: "GR001", name: "Mike Chen", domain: "Frontend Development", progress: 75 },
        { id: "GR002", name: "Lisa Wang", domain: "Backend Development", progress: 80 },
        { id: "GR003", name: "Alex Brown", domain: "Data Science", progress: 65 },
        // ... more graduates
    ],
    
    trainers: [
        { id: "TR001", name: "Sarah Johnson", domain: "Frontend Development", experience: 5 },
        { id: "TR002", name: "Robert Miller", domain: "Backend Development", experience: 7 },
        { id: "TR003", name: "Emily Davis", domain: "Data Science", experience: 6 },
        { id: "TR004", name: "James Wilson", domain: "Cloud Computing", experience: 8 },
        // ... more trainers
    ],
    
    // Training Sessions
    sessions: [
        {
            id: "S001",
            date: "2025-08-13",
            time: "09:00-11:00",
            domain: "Frontend Development",
            trainer: "Sarah Johnson",
            topic: "React Fundamentals",
            attendees: 17,
            status: "completed"
        },
        {
            id: "S002",
            date: "2025-08-13",
            time: "11:30-13:30",
            domain: "Backend Development",
            trainer: "Robert Miller",
            topic: "Node.js Express",
            attendees: 15,
            status: "ongoing"
        },
        // ... more sessions
    ],
    
    // Q&A Data
    questions: [
        {
            id: "Q001",
            graduate: "Mike Chen",
            question: "How do I handle state management in React?",
            domain: "Frontend Development",
            date: "2025-08-12",
            answer: "You can use useState hook for local state...",
            answeredBy: "Sarah Johnson",
            status: "answered"
        },
        // ... more questions
    ]
};

// Global Variables
let currentUser = 'admin';
let currentDate = new Date().toISOString().split('T')[0];
let charts = {};

// Application Initialization
function initializeApp() {
    setCurrentDate();
    switchRole(currentUser);
    initializeCharts();
    loadMasterData();
    
    // Set default date inputs
    document.getElementById('attendanceDate').value = currentDate;
    document.getElementById('availabilityStartDate').value = currentDate;
    document.getElementById('availabilityEndDate').value = getDateAfterDays(7);
}

function setCurrentDate() {
    const today = new Date();
    const formattedDate = today.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    
    const currentDateElement = document.getElementById('currentDate');
    if (currentDateElement) {
        currentDateElement.textContent = formattedDate;
    }
}

// Role-based Navigation and Dashboard
function switchRole(role) {
    currentUser = role;
    hideAllSections();
    updateNavigation(role);
    showDashboard(role);
    updateUserInfo(role);
}

function updateNavigation(role) {
    const mainMenu = document.getElementById('mainMenu');
    const reportsMenu = document.getElementById('reportsMenu');
    
    // Clear existing menu items
    mainMenu.innerHTML = '';
    reportsMenu.innerHTML = '';
    
    // Role-based menu items
    const menuItems = {
        admin: [
            { id: 'module-lead-dashboard', icon: 'bar-chart-3', text: 'Dashboard', active: true },
            { id: 'attendance-management', icon: 'user-check', text: 'Attendance' },
            { id: 'trainer-availability', icon: 'calendar-check', text: 'Trainer Availability' },
            { id: 'session-management', icon: 'monitor', text: 'Session Management' },
            { id: 'graduate-progress', icon: 'trending-up', text: 'Graduate Progress' },
            { id: 'qa-management', icon: 'help-circle', text: 'Q&A Management' }
        ],
        trainer: [
            { id: 'trainer-dashboard', icon: 'monitor', text: 'My Dashboard', active: true },
            { id: 'my-sessions', icon: 'calendar', text: 'My Sessions' },
            { id: 'attendance-entry', icon: 'user-check', text: 'Mark Attendance' },
            { id: 'availability-setting', icon: 'calendar-check', text: 'Set Availability' },
            { id: 'qa-responses', icon: 'message-circle', text: 'Answer Questions' }
        ],
        graduate: [
            { id: 'graduate-dashboard', icon: 'graduation-cap', text: 'My Dashboard', active: true },
            { id: 'my-progress', icon: 'trending-up', text: 'My Progress' },
            { id: 'my-sessions', icon: 'calendar', text: 'My Sessions' },
            { id: 'ask-questions', icon: 'help-circle', text: 'Ask Questions' },
            { id: 'resources', icon: 'book-open', text: 'Resources' }
        ]
    };
    
    const reportItems = {
        admin: [
            { id: 'daily-reports', icon: 'file-text', text: 'Daily Reports' },
            { id: 'weekly-analytics', icon: 'bar-chart', text: 'Weekly Analytics' },
            { id: 'domain-reports', icon: 'pie-chart', text: 'Domain Reports' }
        ],
        trainer: [
            { id: 'my-reports', icon: 'file-text', text: 'My Reports' },
            { id: 'student-progress', icon: 'users', text: 'Student Progress' }
        ],
        graduate: [
            { id: 'my-attendance', icon: 'calendar-check', text: 'My Attendance' },
            { id: 'my-achievements', icon: 'award', text: 'Achievements' }
        ]
    };
    
    // Populate main menu
    menuItems[role].forEach(item => {
        const li = document.createElement('li');
        li.innerHTML = `
            <a href="#${item.id}" onclick="showSection('${item.id}', this)" class="${item.active ? 'is-active' : ''}">
                <span class="icon"><i data-lucide="${item.icon}"></i></span>
                <span>${item.text}</span>
            </a>
        `;
        mainMenu.appendChild(li);
    });
    
    // Populate reports menu
    reportItems[role].forEach(item => {
        const li = document.createElement('li');
        li.innerHTML = `
            <a href="#${item.id}" onclick="showSection('${item.id}', this)">
                <span class="icon"><i data-lucide="${item.icon}"></i></span>
                <span>${item.text}</span>
            </a>
        `;
        reportsMenu.appendChild(li);
    });
    
    // Hide reports section for graduates if no reports
    const reportsLabel = document.getElementById('reportsLabel');
    if (role === 'graduate' && reportItems[role].length === 0) {
        reportsLabel.style.display = 'none';
        reportsMenu.style.display = 'none';
    } else {
        reportsLabel.style.display = 'block';
        reportsMenu.style.display = 'block';
    }
    
    // Refresh icons
    lucide.createIcons();
}

function showDashboard(role) {
    const dashboards = {
        admin: 'module-lead-dashboard',
        trainer: 'trainer-dashboard',
        graduate: 'graduate-dashboard'
    };
    
    showSection(dashboards[role]);
    
    // Load role-specific data
    switch (role) {
        case 'admin':
            loadModuleLeadDashboard();
            break;
        case 'trainer':
            loadTrainerDashboard();
            break;
        case 'graduate':
            loadGraduateDashboard();
            break;
    }
}

function updateUserInfo(role) {
    const currentUserElement = document.getElementById('currentUser');
    const roleSelector = document.getElementById('roleSelector');
    
    if (currentUserElement) {
        currentUserElement.textContent = masterData.users[role].name;
    }
    
    if (roleSelector) {
        roleSelector.value = role;
    }
}

// Dashboard Loading Functions
function loadModuleLeadDashboard() {
    // Update quick metrics
    updateTodayMetrics();
    
    // Load today's sessions
    loadTodaySessions();
    
    // Load upcoming sessions
    loadUpcomingSessions();
    
    // Update charts
    updateProgressChart();
    updateDomainChart();
}

function updateTodayMetrics() {
    // Calculate today's metrics from master data
    const todayDate = currentDate;
    const todaySessions = masterData.sessions.filter(session => session.date === todayDate);
    
    // Update attendance
    const totalAttendees = todaySessions.reduce((sum, session) => sum + session.attendees, 0);
    document.getElementById('todayAttendance').textContent = `${totalAttendees}/${masterData.program.totalParticipants}`;
    
    // Update active trainers
    const activeTrainers = new Set(todaySessions.map(session => session.trainer)).size;
    document.getElementById('activeTrainers').textContent = `${activeTrainers}/${masterData.program.totalTrainers}`;
    
    // Update sessions count
    document.getElementById('sessionsToday').textContent = todaySessions.length;
    
    // Update open queries
    const openQueries = masterData.questions.filter(q => q.status === 'pending').length;
    document.getElementById('openQueries').textContent = openQueries;
}

function loadTodaySessions() {
    const todaySessionsTable = document.getElementById('todaySessionsTable');
    const todayDate = currentDate;
    const todaySessions = masterData.sessions.filter(session => session.date === todayDate);
    
    todaySessionsTable.innerHTML = '';
    
    todaySessions.forEach(session => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${session.time}</td>
            <td>
                <span class="tag is-info">${session.domain}</span>
            </td>
            <td>${session.trainer}</td>
            <td>${session.topic}</td>
            <td>
                <span class="has-text-weight-semibold">${session.attendees}</span>
            </td>
            <td>
                <span class="status-badge ${session.status}">${session.status}</span>
            </td>
            <td>
                <div class="buttons are-small">
                    <button class="button is-info is-small" onclick="viewSessionDetails('${session.id}')">
                        <span class="icon"><i data-lucide="eye"></i></span>
                    </button>
                    <button class="button is-primary is-small" onclick="markAttendance('${session.id}')">
                        <span class="icon"><i data-lucide="user-check"></i></span>
                    </button>
                </div>
            </td>
        `;
        todaySessionsTable.appendChild(row);
    });
    
    lucide.createIcons();
}

function loadUpcomingSessions() {
    const upcomingSessionsContainer = document.getElementById('upcomingSessions');
    const startDate = new Date(currentDate);
    const endDate = new Date(startDate);
    endDate.setDate(startDate.getDate() + 7);
    
    const upcomingSessions = masterData.sessions.filter(session => {
        const sessionDate = new Date(session.date);
        return sessionDate > startDate && sessionDate <= endDate;
    });
    
    upcomingSessionsContainer.innerHTML = '';
    
    if (upcomingSessions.length === 0) {
        upcomingSessionsContainer.innerHTML = '<p class="has-text-grey">No upcoming sessions in the next 7 days.</p>';
        return;
    }
    
    upcomingSessions.forEach(session => {
        const sessionCard = document.createElement('div');
        sessionCard.className = 'box';
        sessionCard.innerHTML = `
            <div class="level">
                <div class="level-left">
                    <div class="level-item">
                        <div>
                            <p class="heading">${session.date} • ${session.time}</p>
                            <p class="title is-6">${session.topic}</p>
                            <p class="subtitle is-7">${session.trainer} • ${session.domain}</p>
                        </div>
                    </div>
                </div>
                <div class="level-right">
                    <div class="level-item">
                        <span class="status-badge ${session.status}">${session.status}</span>
                    </div>
                </div>
            </div>
        `;
        upcomingSessionsContainer.appendChild(sessionCard);
    });
}

// Chart Initialization and Updates
function initializeCharts() {
    // Progress Chart
    const progressCtx = document.getElementById('progressChart');
    if (progressCtx) {
        charts.progress = new Chart(progressCtx, {
            type: 'line',
            data: {
                labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'],
                datasets: [{
                    label: 'Overall Progress',
                    data: [10, 25, 40, 55, 70, 85],
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4,
                    fill: true
                }, {
                    label: 'Attendance Rate',
                    data: [90, 88, 92, 85, 87, 90],
                    borderColor: '#23d160',
                    backgroundColor: 'rgba(35, 209, 96, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }
    
    // Domain Distribution Chart
    const domainCtx = document.getElementById('domainChart');
    if (domainCtx) {
        charts.domain = new Chart(domainCtx, {
            type: 'doughnut',
            data: {
                labels: masterData.program.domains,
                datasets: [{
                    data: [25, 20, 15, 8],
                    backgroundColor: [
                        '#667eea',
                        '#23d160',
                        '#ffdd57',
                        '#ff3860'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
    
    // Attendance Heatmap
    const heatmapCtx = document.getElementById('attendanceHeatmap');
    if (heatmapCtx) {
        // Generate sample heatmap data
        const heatmapData = generateHeatmapData();
        charts.heatmap = new Chart(heatmapCtx, {
            type: 'scatter',
            data: {
                datasets: [{
                    label: 'Attendance',
                    data: heatmapData,
                    backgroundColor: function(context) {
                        const value = context.parsed.y;
                        if (value >= 90) return '#196127';
                        if (value >= 80) return '#239a3b';
                        if (value >= 70) return '#7bc96f';
                        if (value >= 60) return '#c6e48b';
                        return '#ebedf0';
                    }
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        type: 'linear',
                        position: 'bottom',
                        title: {
                            display: true,
                            text: 'Days'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Attendance %'
                        }
                    }
                }
            }
        });
    }
}

function updateProgressChart() {
    // Update progress chart with real data
    if (charts.progress) {
        // This would typically fetch real data from your backend
        charts.progress.update();
    }
}

function updateDomainChart() {
    // Update domain chart with current distribution
    if (charts.domain) {
        charts.domain.update();
    }
}

// Attendance Management Functions
function loadAttendanceForDate() {
    const selectedDate = document.getElementById('attendanceDate').value;
    const attendanceGrid = document.getElementById('attendanceGrid');
    
    // Get graduates for the selected date
    const graduates = masterData.graduates;
    
    attendanceGrid.innerHTML = '';
    attendanceGrid.className = 'attendance-grid';
    
    graduates.forEach(graduate => {
        const attendanceItem = document.createElement('div');
        attendanceItem.className = 'attendance-item';
        attendanceItem.innerHTML = `
            <div style="flex: 1;">
                <strong>${graduate.name}</strong>
                <br>
                <small>${graduate.domain}</small>
            </div>
            <div class="field">
                <div class="control">
                    <label class="checkbox">
                        <input type="checkbox" id="attendance_${graduate.id}" onchange="updateAttendanceStatus('${graduate.id}', this.checked)">
                        Present
                    </label>
                </div>
            </div>
        `;
        attendanceGrid.appendChild(attendanceItem);
    });
}

function updateAttendanceStatus(graduateId, isPresent) {
    const attendanceItem = document.querySelector(`input[id="attendance_${graduateId}"]`).closest('.attendance-item');
    
    if (isPresent) {
        attendanceItem.classList.add('present');
        attendanceItem.classList.remove('absent');
    } else {
        attendanceItem.classList.add('absent');
        attendanceItem.classList.remove('present');
    }
}

// Trainer Availability Functions
function loadTrainerAvailability() {
    const startDate = document.getElementById('availabilityStartDate').value;
    const endDate = document.getElementById('availabilityEndDate').value;
    const availabilityMatrix = document.getElementById('availabilityMatrix');
    
    // Generate date range
    const dates = getDateRange(startDate, endDate);
    
    // Create availability matrix
    availabilityMatrix.innerHTML = '';
    availabilityMatrix.className = 'availability-matrix';
    
    // Header row
    const headerRow = document.createElement('div');
    headerRow.className = 'availability-header';
    headerRow.textContent = 'Trainer';
    availabilityMatrix.appendChild(headerRow);
    
    dates.forEach(date => {
        const dateHeader = document.createElement('div');
        dateHeader.className = 'availability-header';
        dateHeader.textContent = new Date(date).toLocaleDateString();
        availabilityMatrix.appendChild(dateHeader);
    });
    
    // Trainer rows
    masterData.trainers.forEach(trainer => {
        const trainerCell = document.createElement('div');
        trainerCell.className = 'availability-trainer';
        trainerCell.textContent = trainer.name;
        availabilityMatrix.appendChild(trainerCell);
        
        dates.forEach(date => {
            const availabilitySlot = document.createElement('div');
            availabilitySlot.className = 'availability-slot';
            
            // Random availability for demo (replace with real data)
            const status = Math.random() > 0.3 ? 'available' : 'unavailable';
            availabilitySlot.classList.add(status);
            availabilitySlot.textContent = status === 'available' ? '✓' : '✗';
            
            availabilityMatrix.appendChild(availabilitySlot);
        });
    });
}

// Q&A System Functions
function submitQuestion() {
    const questionText = document.getElementById('questionText').value.trim();
    
    if (!questionText) {
        showNotification('Please enter a question', 'warning');
        return;
    }
    
    const newQuestion = {
        id: `Q${Date.now()}`,
        graduate: masterData.users.graduate.name,
        question: questionText,
        domain: "General",
        date: currentDate,
        status: "pending"
    };
    
    masterData.questions.push(newQuestion);
    document.getElementById('questionText').value = '';
    
    showNotification('Question submitted successfully!', 'success');
    loadMyQuestions();
}

function loadMyQuestions() {
    const myQuestionsContainer = document.getElementById('myQuestions');
    const userQuestions = masterData.questions.filter(q => 
        q.graduate === masterData.users.graduate.name
    );
    
    myQuestionsContainer.innerHTML = '';
    
    if (userQuestions.length === 0) {
        myQuestionsContainer.innerHTML = '<p class="has-text-grey">No questions asked yet.</p>';
        return;
    }
    
    userQuestions.forEach(question => {
        const questionItem = document.createElement('div');
        questionItem.className = 'question-item';
        questionItem.innerHTML = `
            <div class="question-header">
                <span class="tag ${question.status === 'answered' ? 'is-success' : 'is-warning'}">
                    ${question.status}
                </span>
                <span class="has-text-grey">${question.date}</span>
            </div>
            <div class="question-content">
                <strong>Q:</strong> ${question.question}
            </div>
            ${question.answer ? `
                <div class="answer-section">
                    <strong>A:</strong> ${question.answer}
                    <br>
                    <small class="has-text-grey">Answered by: ${question.answeredBy}</small>
                </div>
            ` : ''}
        `;
        myQuestionsContainer.appendChild(questionItem);
    });
}

// Utility Functions
function hideAllSections() {
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => section.classList.add('is-hidden'));
}

function showSection(sectionId, activeLink = null) {
    hideAllSections();
    
    const section = document.getElementById(sectionId);
    if (section) {
        section.classList.remove('is-hidden');
        section.classList.add('fade-in');
    }
    
    // Update active menu item
    if (activeLink) {
        document.querySelectorAll('.menu-list a').forEach(link => {
            link.classList.remove('is-active');
        });
        activeLink.classList.add('is-active');
    }
    
    // Load section-specific data
    loadSectionData(sectionId);
}

function loadSectionData(sectionId) {
    switch (sectionId) {
        case 'attendance-management':
            loadAttendanceForDate();
            break;
        case 'trainer-availability':
            loadTrainerAvailability();
            break;
        case 'graduate-dashboard':
            loadMyQuestions();
            break;
    }
}

function generateHeatmapData() {
    const data = [];
    for (let day = 1; day <= 30; day++) {
        data.push({
            x: day,
            y: Math.floor(Math.random() * 40) + 60 // 60-100% attendance
        });
    }
    return data;
}

function getDateRange(startDate, endDate) {
    const dates = [];
    const currentDate = new Date(startDate);
    const lastDate = new Date(endDate);
    
    while (currentDate <= lastDate) {
        dates.push(new Date(currentDate).toISOString().split('T')[0]);
        currentDate.setDate(currentDate.getDate() + 1);
    }
    
    return dates;
}

function getDateAfterDays(days) {
    const date = new Date();
    date.setDate(date.getDate() + days);
    return date.toISOString().split('T')[0];
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification is-${type} is-light`;
    notification.innerHTML = `
        <button class="delete" onclick="this.parentElement.remove()"></button>
        ${message}
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Position notification
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '9999';
    notification.style.minWidth = '300px';
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

function refreshSessions() {
    showNotification('Refreshing sessions...', 'info');
    loadTodaySessions();
    updateTodayMetrics();
}

function markAttendance(sessionId) {
    document.getElementById('attendanceModal').classList.add('is-active');
    // Load attendance form for specific session
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('is-active');
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        window.location.reload();
    }
}

// Mock data loading function
function loadMasterData() {
    // In a real application, this would fetch data from your backend
    console.log('Master data loaded:', masterData);
}
