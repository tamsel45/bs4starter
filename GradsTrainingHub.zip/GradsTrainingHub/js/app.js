// Global Variables
let currentUser = {
    name: 'John Doe',
    role: 'Admin',
    id: 'admin001'
};

let trainingSessions = [];
let attendanceData = [];

// Helper function to reinitialize Lucide icons
function refreshIcons() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

// Modal functions
let trainers = [];
let students = [];
let assignments = [];
let progressData = [];

// Sample Data Initialization
function initializeData() {
    // Initialize trainers
    trainers = [
        { id: 1, name: 'Dr. Sarah Johnson', designation: 'Senior AI Trainer', level: 'Senior', domain: 'generative-ai', status: 'available' },
        { id: 2, name: 'Mark Anderson', designation: 'DevOps Architect', level: 'Senior', domain: 'devops', status: 'available' },
        { id: 3, name: 'Lisa Chen', designation: 'Container Specialist', level: 'Mid', domain: 'containerization', status: 'available' },
        { id: 4, name: 'James Wilson', designation: 'Test Automation Lead', level: 'Senior', domain: 'test-automation', status: 'available' },
        { id: 5, name: 'Emily Davis', designation: 'ML Engineer', level: 'Mid', domain: 'generative-ai', status: 'out-of-office' }
    ];

    // Initialize students
    students = [];
    for (let i = 1; i <= 68; i++) {
        students.push({
            id: i,
            name: `Student ${i.toString().padStart(2, '0')}`,
            email: `student${i}@company.com`,
            domain: ['generative-ai', 'containerization', 'devops', 'test-automation'][Math.floor(Math.random() * 4)]
        });
    }

    // Initialize training sessions
    trainingSessions = [
        {
            id: 1,
            title: 'Introduction to Generative AI',
            domain: 'generative-ai',
            date: '2025-09-01',
            startTime: '09:30',
            endTime: '13:30',
            trainer: 'Dr. Sarah Johnson',
            trainerId: 1,
            webexLink: 'https://webex.com/meet/session1',
            materials: ['intro-genai.pdf', 'slides-day1.pptx']
        },
        {
            id: 2,
            title: 'Docker Fundamentals',
            domain: 'containerization',
            date: '2025-09-01',
            startTime: '09:30',
            endTime: '13:30',
            trainer: 'Lisa Chen',
            trainerId: 3,
            webexLink: 'https://webex.com/meet/session2',
            materials: ['docker-basics.pdf']
        }
    ];

    // Initialize assignments
    assignments = [
        {
            id: 1,
            title: 'Build a Simple Chatbot',
            domain: 'generative-ai',
            type: 'Assignment',
            dueDate: '2025-09-08',
            description: 'Create a basic chatbot using OpenAI API',
            submissions: 15,
            totalStudents: 17
        },
        {
            id: 2,
            title: 'Docker Container Quiz',
            domain: 'containerization',
            type: 'Quiz',
            dueDate: '2025-09-05',
            description: 'Multiple choice quiz on Docker concepts',
            submissions: 20,
            totalStudents: 17
        }
    ];

    // Initialize progress data
    progressData = students.map(student => ({
        studentId: student.id,
        studentName: student.name,
        domains: {
            'generative-ai': Math.floor(Math.random() * 30) + 15,
            'containerization': Math.floor(Math.random() * 30) + 10,
            'devops': Math.floor(Math.random() * 25) + 5,
            'test-automation': Math.floor(Math.random() * 20) + 5
        },
        overall: 0
    }));

    // Calculate overall progress
    progressData.forEach(student => {
        const domains = Object.values(student.domains);
        student.overall = Math.round(domains.reduce((a, b) => a + b, 0) / domains.length);
    });

    // Update trainer select options
    updateTrainerOptions();
    updateStudentOptions();
}

// Navigation Functions
function showSection(sectionId, clickedElement = null) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });

    // Remove active class from all nav items
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });

    // Show selected section
    document.getElementById(sectionId).classList.add('active');

    // Add active class to clicked nav item
    if (clickedElement) {
        clickedElement.closest('.nav-item').classList.add('active');
    } else {
        // Find the nav item by section id
        const navItem = document.querySelector(`a[href="#${sectionId}"]`)?.closest('.nav-item');
        if (navItem) navItem.classList.add('active');
    }

    // Load section-specific data
    switch(sectionId) {
        case 'calendar':
            loadCalendar();
            break;
        case 'attendance':
            loadAttendance();
            break;
        case 'trainer-availability':
            loadTrainerAvailability();
            break;
        case 'assignments':
            loadAssignments();
            break;
        case 'student-progress':
            loadStudentProgress();
            break;
        case 'lab-requirements':
            loadLabRequirements();
            break;
        case 'reports':
            loadReports();
            break;
    }
}

// Modal Functions
function openModal(modalId) {
    document.getElementById('modalOverlay').classList.add('show');
    document.getElementById(modalId).classList.add('show');
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    document.getElementById('modalOverlay').classList.remove('show');
    document.querySelectorAll('.modal').forEach(modal => {
        modal.classList.remove('show');
    });
    document.body.style.overflow = 'auto';
}

// Session Management
function addSession() {
    openModal('sessionModal');
}

function saveSession() {
    const form = document.getElementById('sessionForm');
    const formData = new FormData(form);
    
    const session = {
        id: trainingSessions.length + 1,
        title: formData.get('sessionTitle'),
        domain: formData.get('sessionDomain'),
        date: formData.get('sessionDate'),
        startTime: '09:30',
        endTime: '13:30',
        trainer: trainers.find(t => t.id == formData.get('sessionTrainer'))?.name || '',
        trainerId: parseInt(formData.get('sessionTrainer')),
        webexLink: formData.get('webexLink'),
        materials: []
    };

    trainingSessions.push(session);
    closeModal();
    loadCalendar();
    showNotification('Session added successfully!', 'success');
}

// Utility Functions
function updateTrainerOptions() {
    const select = document.getElementById('sessionTrainer');
    if (select) {
        select.innerHTML = '<option value="">Select Trainer</option>';
        trainers.forEach(trainer => {
            const option = document.createElement('option');
            option.value = trainer.id;
            option.textContent = `${trainer.name} - ${trainer.designation}`;
            select.appendChild(option);
        });
    }
}

function updateStudentOptions() {
    const select = document.getElementById('studentFilter');
    if (select) {
        select.innerHTML = '<option value="">All Students</option>';
        students.forEach(student => {
            const option = document.createElement('option');
            option.value = student.id;
            option.textContent = student.name;
            select.appendChild(option);
        });
    }
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i data-lucide="${type === 'success' ? 'check-circle' : type === 'error' ? 'alert-circle' : 'info'}"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()" class="notification-close">&times;</button>
    `;

    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#d4edda' : type === 'error' ? '#f8d7da' : '#cce7ff'};
        color: ${type === 'success' ? '#155724' : type === 'error' ? '#721c24' : '#004085'};
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 3000;
        display: flex;
        align-items: center;
        gap: 10px;
        max-width: 400px;
        animation: slideInRight 0.3s ease;
    `;

    document.body.appendChild(notification);

    // Re-initialize Lucide icons for new content
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function formatTime(timeString) {
    const [hours, minutes] = timeString.split(':');
    const date = new Date();
    date.setHours(parseInt(hours), parseInt(minutes));
    return date.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
    });
}

// Export Functions
function exportAttendance() {
    const data = attendanceData.map(record => ({
        'Student Name': record.studentName,
        'Session': record.sessionTitle,
        'Domain': record.domain,
        'Date': formatDate(record.date),
        'Status': record.status,
        'Timestamp': record.timestamp
    }));

    downloadCSV(data, 'attendance-report.csv');
    showNotification('Attendance report exported successfully!', 'success');
}

function downloadCSV(data, filename) {
    if (data.length === 0) return;

    const headers = Object.keys(data[0]);
    const csvContent = [
        headers.join(','),
        ...data.map(row => headers.map(header => `"${row[header] || ''}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
}

// Authentication Functions
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        // In a real application, this would redirect to login page
        showNotification('Logged out successfully!', 'success');
        // Simulate redirect
        setTimeout(() => {
            window.location.reload();
        }, 1000);
    }
}

// Generate Reports
function generateReport(type) {
    showNotification(`Generating ${type} report...`, 'info');
    
    // Simulate report generation
    setTimeout(() => {
        switch(type) {
            case 'weekly':
                generateWeeklyReport();
                break;
            case 'attendance':
                generateAttendanceReport();
                break;
            case 'performance':
                generatePerformanceReport();
                break;
            case 'issues':
                generateIssuesReport();
                break;
        }
    }, 2000);
}

function generateWeeklyReport() {
    const reportData = {
        week: 1,
        totalSessions: trainingSessions.length,
        averageAttendance: 95,
        completedAssignments: 75,
        pendingAssignments: 25,
        issuesReported: 3,
        issuesResolved: 2
    };

    showNotification('Weekly report generated successfully!', 'success');
    console.log('Weekly Report:', reportData);
}

function generateAttendanceReport() {
    const reportData = attendanceData.reduce((acc, record) => {
        if (!acc[record.studentName]) {
            acc[record.studentName] = { present: 0, absent: 0, excused: 0 };
        }
        acc[record.studentName][record.status.toLowerCase()]++;
        return acc;
    }, {});

    showNotification('Attendance report generated successfully!', 'success');
    console.log('Attendance Report:', reportData);
}

function generatePerformanceReport() {
    const reportData = progressData.map(student => ({
        name: student.studentName,
        overall: student.overall,
        domains: student.domains
    }));

    showNotification('Performance report generated successfully!', 'success');
    console.log('Performance Report:', reportData);
}

function generateIssuesReport() {
    const issuesData = [
        { id: 1, type: 'Technical', description: 'WebEx connectivity issues', status: 'Resolved', priority: 'High' },
        { id: 2, type: 'Lab Setup', description: 'Docker installation problems', status: 'In Progress', priority: 'Medium' },
        { id: 3, type: 'Content', description: 'Missing assignment materials', status: 'Open', priority: 'Low' }
    ];

    showNotification('Issues report generated successfully!', 'success');
    console.log('Issues Report:', issuesData);
}

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize data
    initializeData();
    
    // Set up event listeners
    document.getElementById('sessionForm')?.addEventListener('submit', function(e) {
        e.preventDefault();
        saveSession();
    });

    // Add keyboard support for modal overlay
    document.getElementById('modalOverlay')?.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModal();
        }
    });

    // Make modal overlay focusable for keyboard navigation
    const modalOverlay = document.getElementById('modalOverlay');
    if (modalOverlay) {
        modalOverlay.setAttribute('tabindex', '0');
        modalOverlay.setAttribute('role', 'button');
        modalOverlay.setAttribute('aria-label', 'Close modal');
    }

    // Set up form labels with proper associations
    const labels = document.querySelectorAll('label');
    labels.forEach(label => {
        const nextElement = label.nextElementSibling;
        if (nextElement && (nextElement.tagName === 'INPUT' || nextElement.tagName === 'SELECT')) {
            const id = nextElement.id || 'input_' + Math.random().toString(36).substr(2, 9);
            nextElement.id = id;
            label.setAttribute('for', id);
        }
    });

    // Update user info display
    document.getElementById('userName').textContent = currentUser.name;
    document.getElementById('userRole').textContent = currentUser.role;

    // Load initial dashboard data
    showSection('dashboard');
    
    console.log('Training Portal Application Initialized');
});

// Additional Functions for Missing Modules

function loadTrainerAvailability() {
    const trainerGrid = document.getElementById('trainerGrid');
    if (!trainerGrid) return;

    trainerGrid.innerHTML = '';

    trainers.forEach(trainer => {
        const card = document.createElement('div');
        card.className = 'trainer-card';
        card.innerHTML = `
            <div class="trainer-header">
                <div class="trainer-avatar">
                    ${trainer.name.charAt(0)}
                </div>
                <div class="trainer-info">
                    <h3>${trainer.name}</h3>
                    <p>${trainer.designation}</p>
                </div>
            </div>
            <div class="trainer-status">
                <span class="availability-status status-${trainer.status}">
                    ${trainer.status.replace('-', ' ').toUpperCase()}
                </span>
            </div>
            <div class="trainer-domain">
                <strong>Domain:</strong> ${getDomainDisplayName(trainer.domain)}
            </div>
            <div class="trainer-actions">
                <button class="btn btn-sm btn-secondary" onclick="updateTrainerStatus(${trainer.id})">
                    Update Status
                </button>
            </div>
        `;
        trainerGrid.appendChild(card);
    });
}

function loadAssignments() {
    const assignmentsGrid = document.getElementById('assignmentsGrid');
    if (!assignmentsGrid) return;

    assignmentsGrid.innerHTML = '';

    assignments.forEach(assignment => {
        const card = document.createElement('div');
        card.className = 'assignment-card';
        card.innerHTML = `
            <div class="assignment-header">
                <h3 class="assignment-title">${assignment.title}</h3>
                <span class="assignment-type">${assignment.type}</span>
            </div>
            <div class="assignment-domain">Domain: ${getDomainDisplayName(assignment.domain)}</div>
            <p class="assignment-description">${assignment.description}</p>
            <div class="assignment-meta">
                <span>Due: ${formatDate(assignment.dueDate)}</span>
                <span>Submissions: ${assignment.submissions}/${assignment.totalStudents}</span>
            </div>
            <div class="assignment-actions">
                <button class="btn btn-sm btn-primary" onclick="viewAssignmentDetails(${assignment.id})">
                    View Details
                </button>
            </div>
        `;
        assignmentsGrid.appendChild(card);
    });
}

function loadLabRequirements() {
    const labGrid = document.getElementById('labRequirementsGrid');
    if (!labGrid) return;

    const sampleRequirements = [
        {
            id: 1,
            title: 'Docker Desktop Installation',
            domain: 'containerization',
            status: 'completed',
            description: 'Install Docker Desktop on all student machines',
            assignedTo: 'IT Team',
            dueDate: '2025-08-30'
        },
        {
            id: 2,
            title: 'AI Development Environment',
            domain: 'generative-ai',
            status: 'in-progress',
            description: 'Set up Python environment with required AI libraries',
            assignedTo: 'Lab Coordinator',
            dueDate: '2025-09-01'
        },
        {
            id: 3,
            title: 'Jenkins Setup',
            domain: 'devops',
            status: 'pending',
            description: 'Configure Jenkins for CI/CD pipeline training',
            assignedTo: 'DevOps Team',
            dueDate: '2025-09-05'
        }
    ];

    labGrid.innerHTML = '';

    sampleRequirements.forEach(requirement => {
        const card = document.createElement('div');
        card.className = 'lab-requirement-card';
        card.innerHTML = `
            <div class="requirement-header">
                <h3>${requirement.title}</h3>
                <span class="requirement-status status-${requirement.status}">
                    ${requirement.status.replace('-', ' ').toUpperCase()}
                </span>
            </div>
            <div class="requirement-domain">
                Domain: ${getDomainDisplayName(requirement.domain)}
            </div>
            <p class="requirement-description">${requirement.description}</p>
            <div class="requirement-meta">
                <div><strong>Assigned to:</strong> ${requirement.assignedTo}</div>
                <div><strong>Due Date:</strong> ${formatDate(requirement.dueDate)}</div>
            </div>
            <div class="requirement-actions">
                <button class="btn btn-sm btn-primary" onclick="updateRequirementStatus(${requirement.id})">
                    Update Status
                </button>
            </div>
        `;
        labGrid.appendChild(card);
    });
}

function createAssignment() {
    const modalContent = `
        <form id="assignmentForm" onsubmit="saveAssignment(event)">
            <div class="form-group">
                <label for="assignmentTitle">Assignment Title</label>
                <input type="text" id="assignmentTitle" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="assignmentDomain">Domain</label>
                <select id="assignmentDomain" class="form-control" required>
                    <option value="">Select Domain</option>
                    <option value="generative-ai">Generative AI</option>
                    <option value="containerization">Containerization</option>
                    <option value="devops">DevOps</option>
                    <option value="test-automation">Test Automation</option>
                </select>
            </div>
            <div class="form-group">
                <label for="assignmentType">Type</label>
                <select id="assignmentType" class="form-control" required>
                    <option value="">Select Type</option>
                    <option value="Assignment">Assignment</option>
                    <option value="Quiz">Quiz</option>
                    <option value="Hackathon">Hackathon</option>
                </select>
            </div>
            <div class="form-group">
                <label for="assignmentDueDate">Due Date</label>
                <input type="date" id="assignmentDueDate" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="assignmentDescription">Description</label>
                <textarea id="assignmentDescription" class="form-control" rows="4" required></textarea>
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Create Assignment</button>
            </div>
        </form>
    `;

    showModal('Create Assignment', modalContent);
}

function saveAssignment(event) {
    event.preventDefault();
    
    const assignment = {
        id: assignments.length + 1,
        title: document.getElementById('assignmentTitle').value,
        domain: document.getElementById('assignmentDomain').value,
        type: document.getElementById('assignmentType').value,
        dueDate: document.getElementById('assignmentDueDate').value,
        description: document.getElementById('assignmentDescription').value,
        submissions: 0,
        totalStudents: students.length
    };

    assignments.push(assignment);
    closeModal();
    loadAssignments();
    showNotification('Assignment created successfully!', 'success');
}

function addLabRequirement() {
    const modalContent = `
        <form id="labRequirementForm" onsubmit="saveLabRequirement(event)">
            <div class="form-group">
                <label for="requirementTitle">Requirement Title</label>
                <input type="text" id="requirementTitle" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="requirementDomain">Domain</label>
                <select id="requirementDomain" class="form-control" required>
                    <option value="">Select Domain</option>
                    <option value="generative-ai">Generative AI</option>
                    <option value="containerization">Containerization</option>
                    <option value="devops">DevOps</option>
                    <option value="test-automation">Test Automation</option>
                </select>
            </div>
            <div class="form-group">
                <label for="requirementDescription">Description</label>
                <textarea id="requirementDescription" class="form-control" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label for="requirementAssignee">Assigned To</label>
                <input type="text" id="requirementAssignee" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="requirementDueDate">Due Date</label>
                <input type="date" id="requirementDueDate" class="form-control" required>
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Add Requirement</button>
            </div>
        </form>
    `;

    showModal('Add Lab Requirement', modalContent);
}

function saveLabRequirement(event) {
    event.preventDefault();
    closeModal();
    loadLabRequirements();
    showNotification('Lab requirement added successfully!', 'success');
}

function updateAvailability() {
    showNotification('Trainer availability updated!', 'success');
}

function updateTrainerStatus(trainerId) {
    const trainer = trainers.find(t => t.id === trainerId);
    if (!trainer) return;

    const modalContent = `
        <form id="trainerStatusForm" onsubmit="saveTrainerStatus(event, ${trainerId})">
            <div class="form-group">
                <label for="trainerStatusSelect">Status for ${trainer.name}</label>
                <select id="trainerStatusSelect" class="form-control" required>
                    <option value="available" ${trainer.status === 'available' ? 'selected' : ''}>Available</option>
                    <option value="busy" ${trainer.status === 'busy' ? 'selected' : ''}>Busy</option>
                    <option value="out-of-office" ${trainer.status === 'out-of-office' ? 'selected' : ''}>Out of Office</option>
                </select>
            </div>
            <div class="form-group">
                <label for="statusNotes">Notes (Optional)</label>
                <textarea id="statusNotes" class="form-control" rows="3" placeholder="Add any additional notes..."></textarea>
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Update Status</button>
            </div>
        </form>
    `;

    showModal('Update Trainer Status', modalContent);
}

function saveTrainerStatus(event, trainerId) {
    event.preventDefault();
    
    const trainer = trainers.find(t => t.id === trainerId);
    if (trainer) {
        trainer.status = document.getElementById('trainerStatusSelect').value;
    }
    
    closeModal();
    loadTrainerAvailability();
    showNotification('Trainer status updated successfully!', 'success');
}

function viewAssignmentDetails(assignmentId) {
    const assignment = assignments.find(a => a.id === assignmentId);
    if (!assignment) return;

    const modalContent = `
        <div class="assignment-details">
            <h3>${assignment.title}</h3>
            <div class="assignment-info">
                <p><strong>Domain:</strong> ${getDomainDisplayName(assignment.domain)}</p>
                <p><strong>Type:</strong> ${assignment.type}</p>
                <p><strong>Due Date:</strong> ${formatDate(assignment.dueDate)}</p>
                <p><strong>Description:</strong> ${assignment.description}</p>
                <p><strong>Submissions:</strong> ${assignment.submissions} out of ${assignment.totalStudents} students</p>
            </div>
            <div class="assignment-actions">
                <button class="btn btn-primary" onclick="viewSubmissions(${assignmentId})">View Submissions</button>
                <button class="btn btn-secondary" onclick="closeModal()">Close</button>
            </div>
        </div>
    `;

    showModal('Assignment Details', modalContent);
}

function viewSubmissions(assignmentId) {
    showNotification('Viewing assignment submissions...', 'info');
    closeModal();
}

function updateRequirementStatus(requirementId) {
    showNotification('Lab requirement status updated!', 'success');
}

function showModal(title, content) {
    const existingModal = document.getElementById('customModal');
    if (existingModal) {
        existingModal.remove();
    }

    const modal = document.createElement('div');
    modal.id = 'customModal';
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>${title}</h3>
                <button class="close-btn" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                ${content}
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    
    document.getElementById('modalOverlay').classList.add('show');
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
}
