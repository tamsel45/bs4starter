// Attendance Management Module

function loadAttendance() {
    generateSampleAttendanceData();
    populateSessionFilter();
    renderAttendanceTable();
}

function generateSampleAttendanceData() {
    // Generate sample attendance data for demonstration
    attendanceData = [];
    
    trainingSessions.forEach(session => {
        students.forEach(student => {
            // Generate random attendance with 90% probability of being present
            const statuses = ['Present', 'Absent', 'Excused'];
            const weights = [0.9, 0.07, 0.03]; // 90% present, 7% absent, 3% excused
            
            let randomValue = Math.random();
            let status = 'Present';
            
            if (randomValue < weights[1]) {
                status = 'Absent';
            } else if (randomValue < weights[1] + weights[2]) {
                status = 'Excused';
            }

            const timestamp = new Date(session.date);
            timestamp.setHours(9, 30 + Math.floor(Math.random() * 30), 0, 0);

            attendanceData.push({
                id: `${session.id}-${student.id}`,
                sessionId: session.id,
                sessionTitle: session.title,
                domain: session.domain,
                date: session.date,
                studentId: student.id,
                studentName: student.name,
                status: status,
                timestamp: timestamp.toISOString(),
                method: status === 'Present' ? 'WebEx Auto' : 'Manual'
            });
        });
    });
}

function populateSessionFilter() {
    const sessionFilter = document.getElementById('sessionFilter');
    if (!sessionFilter) return;

    sessionFilter.innerHTML = '<option value="">All Sessions</option>';
    
    trainingSessions.forEach(session => {
        const option = document.createElement('option');
        option.value = session.id;
        option.textContent = `${session.title} - ${formatDate(session.date)}`;
        sessionFilter.appendChild(option);
    });
}

function renderAttendanceTable() {
    const tableBody = document.getElementById('attendanceTableBody');
    if (!tableBody) return;

    const filteredData = getFilteredAttendanceData();
    
    tableBody.innerHTML = '';

    if (filteredData.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align: center; padding: 40px; color: #666;">
                    <i class="untitledui-inbox" style="font-size: 3rem; margin-bottom: 15px; display: block;"></i>
                    No attendance records found
                </td>
            </tr>
        `;
        return;
    }

    filteredData.forEach(record => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                <div class="student-info">
                    <div class="student-avatar">
                        ${record.studentName.charAt(0)}
                    </div>
                    <span>${record.studentName}</span>
                </div>
            </td>
            <td>
                <div class="session-info">
                    <div class="session-title">${record.sessionTitle}</div>
                    <div class="session-date">${formatDate(record.date)}</div>
                </div>
            </td>
            <td>
                <span class="domain-badge domain-${record.domain}">
                    ${getDomainDisplayName(record.domain)}
                </span>
            </td>
            <td>
                <span class="status-badge status-${record.status.toLowerCase()}">
                    <i class="untitledui-${getStatusIcon(record.status)}"></i>
                    ${record.status}
                </span>
            </td>
            <td>
                <div class="timestamp-info">
                    <div>${formatTime(new Date(record.timestamp).toTimeString().slice(0, 5))}</div>
                    <div class="method">${record.method}</div>
                </div>
            </td>
            <td>
                <div class="action-buttons">
                    <button class="btn-sm btn-edit" onclick="editAttendance('${record.id}')" title="Edit">
                        <i class="untitledui-edit-01"></i>
                    </button>
                    <button class="btn-sm btn-delete" onclick="deleteAttendance('${record.id}')" title="Delete">
                        <i class="untitledui-trash-01"></i>
                    </button>
                </div>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

function getFilteredAttendanceData() {
    let filtered = [...attendanceData];

    // Filter by date
    const selectedDate = document.getElementById('attendanceDate')?.value;
    if (selectedDate) {
        filtered = filtered.filter(record => record.date === selectedDate);
    }

    // Filter by session
    const selectedSession = document.getElementById('sessionFilter')?.value;
    if (selectedSession) {
        filtered = filtered.filter(record => record.sessionId == selectedSession);
    }

    // Sort by timestamp (most recent first)
    return filtered.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
}

function getStatusIcon(status) {
    switch (status) {
        case 'Present': return 'check-circle';
        case 'Absent': return 'times-circle';
        case 'Excused': return 'exclamation-circle';
        default: return 'question-circle';
    }
}

function editAttendance(recordId) {
    const record = attendanceData.find(r => r.id === recordId);
    if (!record) return;

    const modalContent = `
        <form id="editAttendanceForm" onsubmit="saveAttendanceEdit(event, '${recordId}')">
            <div class="form-group">
                <label for="editStudentName">Student</label>
                <input type="text" id="editStudentName" value="${record.studentName}" readonly class="form-control">
            </div>
            <div class="form-group">
                <label for="editSessionTitle">Session</label>
                <input type="text" id="editSessionTitle" value="${record.sessionTitle}" readonly class="form-control">
            </div>
            <div class="form-group">
                <label for="editAttendanceStatus">Status</label>
                <select id="editAttendanceStatus" class="form-control" required>
                    <option value="Present" ${record.status === 'Present' ? 'selected' : ''}>Present</option>
                    <option value="Absent" ${record.status === 'Absent' ? 'selected' : ''}>Absent</option>
                    <option value="Excused" ${record.status === 'Excused' ? 'selected' : ''}>Excused</option>
                </select>
            </div>
            <div class="form-group">
                <label for="editAttendanceNotes">Notes (Optional)</label>
                <textarea id="editAttendanceNotes" class="form-control" rows="3" placeholder="Add any notes about this attendance record...">${record.notes || ''}</textarea>
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    `;

    showAttendanceModal('Edit Attendance', modalContent);
}

function saveAttendanceEdit(event, recordId) {
    event.preventDefault();
    
    const record = attendanceData.find(r => r.id === recordId);
    if (!record) return;

    const newStatus = document.getElementById('editAttendanceStatus').value;
    const notes = document.getElementById('editAttendanceNotes').value;

    record.status = newStatus;
    record.notes = notes;
    record.method = 'Manual Override';
    record.timestamp = new Date().toISOString();

    closeModal();
    renderAttendanceTable();
    showNotification('Attendance updated successfully!', 'success');
}

function deleteAttendance(recordId) {
    if (confirm('Are you sure you want to delete this attendance record?')) {
        const index = attendanceData.findIndex(r => r.id === recordId);
        if (index !== -1) {
            attendanceData.splice(index, 1);
            renderAttendanceTable();
            showNotification('Attendance record deleted!', 'success');
        }
    }
}

function showAttendanceModal(title, content) {
    const existingModal = document.getElementById('attendanceModal');
    if (existingModal) {
        existingModal.remove();
    }

    const modal = document.createElement('div');
    modal.id = 'attendanceModal';
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>${title}</h3>
                <button class="close-btn" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                ${content}
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    
    document.getElementById('modalOverlay').classList.add('show');
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
}

function markAttendanceForSession(sessionId) {
    const session = trainingSessions.find(s => s.id === sessionId);
    if (!session) return;

    const modalContent = `
        <div class="bulk-attendance-form">
            <p>Mark attendance for: <strong>${session.title}</strong></p>
            <p>Date: <strong>${formatDate(session.date)}</strong></p>
            
            <div class="student-attendance-list" id="bulkAttendanceList">
                ${students.map(student => `
                    <div class="student-attendance-item">
                        <div class="student-info">
                            <div class="student-avatar">${student.name.charAt(0)}</div>
                            <span>${student.name}</span>
                        </div>
                        <div class="attendance-options">
                            <label class="radio-option">
                                <input type="radio" name="attendance_${student.id}" value="Present" checked>
                                <span class="status-present">Present</span>
                            </label>
                            <label class="radio-option">
                                <input type="radio" name="attendance_${student.id}" value="Absent">
                                <span class="status-absent">Absent</span>
                            </label>
                            <label class="radio-option">
                                <input type="radio" name="attendance_${student.id}" value="Excused">
                                <span class="status-excused">Excused</span>
                            </label>
                        </div>
                    </div>
                `).join('')}
            </div>
            
            <div class="bulk-actions">
                <button type="button" onclick="markAllPresent()">Mark All Present</button>
                <button type="button" onclick="markAllAbsent()">Mark All Absent</button>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="saveBulkAttendance(${sessionId})">Save Attendance</button>
            </div>
        </div>
    `;

    showAttendanceModal('Mark Attendance', modalContent);
}

function markAllPresent() {
    const presentRadios = document.querySelectorAll('input[value="Present"]');
    presentRadios.forEach(radio => radio.checked = true);
}

function markAllAbsent() {
    const absentRadios = document.querySelectorAll('input[value="Absent"]');
    absentRadios.forEach(radio => radio.checked = true);
}

function saveBulkAttendance(sessionId) {
    const session = trainingSessions.find(s => s.id === sessionId);
    if (!session) return;

    students.forEach(student => {
        const selectedStatus = document.querySelector(`input[name="attendance_${student.id}"]:checked`)?.value || 'Present';
        
        // Remove existing record if any
        const existingIndex = attendanceData.findIndex(r => r.sessionId === sessionId && r.studentId === student.id);
        if (existingIndex !== -1) {
            attendanceData.splice(existingIndex, 1);
        }

        // Add new record
        const timestamp = new Date(session.date);
        timestamp.setHours(9, 30, 0, 0);

        attendanceData.push({
            id: `${sessionId}-${student.id}`,
            sessionId: sessionId,
            sessionTitle: session.title,
            domain: session.domain,
            date: session.date,
            studentId: student.id,
            studentName: student.name,
            status: selectedStatus,
            timestamp: timestamp.toISOString(),
            method: 'Manual Bulk'
        });
    });

    closeModal();
    renderAttendanceTable();
    showNotification('Bulk attendance saved successfully!', 'success');
}

function getAttendanceStats() {
    const stats = {
        totalRecords: attendanceData.length,
        present: attendanceData.filter(r => r.status === 'Present').length,
        absent: attendanceData.filter(r => r.status === 'Absent').length,
        excused: attendanceData.filter(r => r.status === 'Excused').length
    };

    stats.presentPercentage = stats.totalRecords > 0 ? Math.round((stats.present / stats.totalRecords) * 100) : 0;
    stats.absentPercentage = stats.totalRecords > 0 ? Math.round((stats.absent / stats.totalRecords) * 100) : 0;
    stats.excusedPercentage = stats.totalRecords > 0 ? Math.round((stats.excused / stats.totalRecords) * 100) : 0;

    return stats;
}

function displayAttendanceStats() {
    const stats = getAttendanceStats();
    const statsContainer = document.getElementById('attendanceStats');
    
    if (statsContainer) {
        statsContainer.innerHTML = `
            <div class="stats-grid">
                <div class="stat-item">
                    <div class="stat-value">${stats.present}</div>
                    <div class="stat-label">Present</div>
                    <div class="stat-percentage">${stats.presentPercentage}%</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${stats.absent}</div>
                    <div class="stat-label">Absent</div>
                    <div class="stat-percentage">${stats.absentPercentage}%</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${stats.excused}</div>
                    <div class="stat-label">Excused</div>
                    <div class="stat-percentage">${stats.excusedPercentage}%</div>
                </div>
            </div>
        `;
    }
}

// Event listeners for attendance filters
document.addEventListener('DOMContentLoaded', function() {
    const attendanceDate = document.getElementById('attendanceDate');
    const sessionFilter = document.getElementById('sessionFilter');

    if (attendanceDate) {
        attendanceDate.addEventListener('change', renderAttendanceTable);
    }

    if (sessionFilter) {
        sessionFilter.addEventListener('change', renderAttendanceTable);
    }
});

// Enhanced attendance styles
const attendanceStyles = `
    .student-info {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .student-avatar {
        width: 35px;
        height: 35px;
        border-radius: 50%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 600;
        font-size: 0.9rem;
    }

    .session-info {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .session-title {
        font-weight: 600;
        color: #333;
    }

    .session-date {
        font-size: 0.85rem;
        color: #666;
    }

    .domain-badge {
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
    }

    .domain-generative-ai { background: #e3f2fd; color: #1565c0; }
    .domain-containerization { background: #f3e5f5; color: #7b1fa2; }
    .domain-devops { background: #e8f5e8; color: #2e7d32; }
    .domain-test-automation { background: #fff3e0; color: #f57c00; }

    .status-badge {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 500;
    }

    .status-present { background: #d4edda; color: #155724; }
    .status-absent { background: #f8d7da; color: #721c24; }
    .status-excused { background: #fff3cd; color: #856404; }

    .timestamp-info {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .method {
        font-size: 0.75rem;
        color: #666;
        font-style: italic;
    }

    .action-buttons {
        display: flex;
        gap: 8px;
    }

    .btn-sm {
        padding: 6px 8px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 0.8rem;
        transition: all 0.3s ease;
    }

    .btn-edit {
        background: #007bff;
        color: white;
    }

    .btn-edit:hover {
        background: #0056b3;
    }

    .btn-delete {
        background: #dc3545;
        color: white;
    }

    .btn-delete:hover {
        background: #c82333;
    }

    .student-attendance-list {
        max-height: 400px;
        overflow-y: auto;
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        padding: 15px;
        margin: 20px 0;
    }

    .student-attendance-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 0;
        border-bottom: 1px solid #f0f0f0;
    }

    .student-attendance-item:last-child {
        border-bottom: none;
    }

    .attendance-options {
        display: flex;
        gap: 15px;
    }

    .radio-option {
        display: flex;
        align-items: center;
        gap: 5px;
        cursor: pointer;
    }

    .radio-option input[type="radio"] {
        margin-right: 5px;
    }

    .status-present { color: #28a745; }
    .status-absent { color: #dc3545; }
    .status-excused { color: #ffc107; }

    .bulk-actions {
        display: flex;
        gap: 10px;
        margin: 15px 0;
    }

    .bulk-actions button {
        padding: 8px 16px;
        background: #f8f9fa;
        border: 1px solid #e0e0e0;
        border-radius: 4px;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .bulk-actions button:hover {
        background: #e9ecef;
    }
`;

// Inject attendance styles
if (!document.getElementById('attendance-styles')) {
    const styleSheet = document.createElement('style');
    styleSheet.id = 'attendance-styles';
    styleSheet.textContent = attendanceStyles;
    document.head.appendChild(styleSheet);
}
