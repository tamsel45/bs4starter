// Access Control and User Role Management System
// Manages five distinct access levels with role-based permissions

// User roles configuration
const ROLES = {
    admin: {
        name: 'Admin',
        level: 5,
        permissions: ['all'],
        description: 'Full system access, user management, and configuration'
    },
    coordinator: {
        name: 'Program Coordinator',
        level: 4,
        permissions: ['reports', 'resources', 'coordination', 'issues'],
        description: 'Program oversight, reporting, and resource management'
    },
    'senior-trainer': {
        name: 'Senior Trainer',
        level: 3,
        permissions: ['training', 'mentoring', 'materials', 'assessment'],
        description: 'Advanced training delivery and mentoring'
    },
    'mid-trainer': {
        name: 'Mid-Level Trainer',
        level: 2,
        permissions: ['training', 'progress', 'lab-assistance', 'evaluation'],
        description: 'Training delivery and student support'
    },
    mentor: {
        name: 'Delivery Group Mentor',
        level: 1,
        permissions: ['mentoring', 'guidance', 'projects', 'insights'],
        description: 'Student guidance and support'
    }
};

// Sample users data
const usersData = [
    {
        id: 1,
        name: "John Doe",
        email: "john.doe@company.com",
        role: "admin",
        domainExpertise: ["generative-ai", "devops"],
        status: "active",
        lastLogin: "2025-08-13T10:30:00Z",
        createdAt: "2025-08-01T09:00:00Z",
        permissions: ROLES.admin.permissions
    },
    {
        id: 2,
        name: "Sarah Johnson",
        email: "sarah.johnson@company.com",
        role: "coordinator",
        domainExpertise: ["all"],
        status: "active",
        lastLogin: "2025-08-13T09:15:00Z",
        createdAt: "2025-08-01T09:00:00Z",
        permissions: ROLES.coordinator.permissions
    },
    {
        id: 3,
        name: "Dr. Michael Chen",
        email: "michael.chen@company.com",
        role: "senior-trainer",
        domainExpertise: ["containerization", "devops"],
        status: "active",
        lastLogin: "2025-08-13T08:45:00Z",
        createdAt: "2025-08-01T09:00:00Z",
        permissions: ROLES['senior-trainer'].permissions
    },
    {
        id: 4,
        name: "Jennifer Smith",
        email: "jennifer.smith@company.com",
        role: "mid-trainer",
        domainExpertise: ["generative-ai"],
        status: "active",
        lastLogin: "2025-08-12T16:20:00Z",
        createdAt: "2025-08-01T09:00:00Z",
        permissions: ROLES['mid-trainer'].permissions
    },
    {
        id: 5,
        name: "David Wilson",
        email: "david.wilson@company.com",
        role: "mentor",
        domainExpertise: ["test-automation"],
        status: "inactive",
        lastLogin: "2025-08-10T14:30:00Z",
        createdAt: "2025-08-01T09:00:00Z",
        permissions: ROLES.mentor.permissions
    }
];

// Current user session
let currentUser = usersData[0]; // Default to admin for demo

// Initialize access control system
function initializeAccessControl() {
    loadUsers();
    setupRoleBasedUI();
    updateCurrentUserRole();
}

// Load and display users table
function loadUsers() {
    const tableBody = document.getElementById('usersTableBody');
    if (!tableBody) return;

    tableBody.innerHTML = usersData.map(user => `
        <tr data-user-id="${user.id}">
            <td>
                <div class="user-info">
                    <i class="untitledui-user-circle user-avatar"></i>
                    <span>${user.name}</span>
                </div>
            </td>
            <td>${user.email}</td>
            <td>
                <span class="role-badge ${user.role}">${ROLES[user.role].name}</span>
            </td>
            <td>
                <div class="domain-tags">
                    ${user.domainExpertise.map(domain => 
                        `<span class="domain-tag ${domain}">${formatDomainName(domain)}</span>`
                    ).join('')}
                </div>
            </td>
            <td>
                <span class="status-badge ${user.status}">
                    <i class="untitledui-${user.status === 'active' ? 'check-circle' : 'x-circle'}"></i>
                    ${user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                </span>
            </td>
            <td>${formatDateTime(user.lastLogin)}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-sm btn-primary" onclick="editUser(${user.id})" 
                            ${!hasPermission('user-management') ? 'disabled' : ''}>
                        <i class="untitledui-edit-01"></i>
                    </button>
                    <button class="btn btn-sm btn-secondary" onclick="viewUserDetails(${user.id})">
                        <i class="untitledui-eye"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteUser(${user.id})" 
                            ${!hasPermission('user-management') || user.id === currentUser.id ? 'disabled' : ''}>
                        <i class="untitledui-trash-01"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

// Setup role-based UI visibility and permissions
function setupRoleBasedUI() {
    const userRole = currentUser.role;
    const userLevel = ROLES[userRole].level;

    // Hide/show navigation items based on role
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        const link = item.querySelector('a');
        const href = link?.getAttribute('href');
        
        switch (href) {
            case '#access-control':
                item.style.display = userLevel >= 4 ? 'block' : 'none';
                break;
            case '#trainer-management':
                item.style.display = userLevel >= 3 ? 'block' : 'none';
                break;
            case '#reports':
                item.style.display = userLevel >= 2 ? 'block' : 'none';
                break;
        }
    });

    // Hide/show action buttons based on permissions
    const addButtons = document.querySelectorAll('[onclick*="add"], [onclick*="create"]');
    addButtons.forEach(button => {
        if (!hasPermission('content-management')) {
            button.style.display = 'none';
        }
    });
}

// Check if current user has specific permission
function hasPermission(permission) {
    if (currentUser.role === 'admin') return true;
    
    const rolePermissions = ROLES[currentUser.role].permissions;
    const permissionMap = {
        'user-management': ['admin'],
        'content-management': ['admin', 'coordinator', 'senior-trainer'],
        'trainer-assignment': ['admin', 'coordinator'],
        'progress-tracking': ['admin', 'coordinator', 'senior-trainer', 'mid-trainer'],
        'reports-access': ['admin', 'coordinator', 'senior-trainer'],
        'lab-management': ['admin', 'coordinator', 'senior-trainer', 'mid-trainer']
    };
    
    const allowedRoles = permissionMap[permission] || [];
    return allowedRoles.includes(currentUser.role);
}

// Update user role from dropdown
function updateUserRole(newRole) {
    if (!newRole) return;
    
    // In a real application, this would update the session
    const user = usersData.find(u => u.id === currentUser.id);
    if (user) {
        user.role = newRole;
        currentUser = user;
        setupRoleBasedUI();
        showMessage('Role Updated', `Your role has been changed to ${ROLES[newRole].name}`, 'info');
    }
}

// Update current user role display
function updateCurrentUserRole() {
    const roleSelector = document.getElementById('userRole');
    if (roleSelector) {
        roleSelector.value = currentUser.role;
    }
}

// Add new user
function addUser() {
    const modalContent = `
        <div class="add-user-form">
            <h3>Add New User</h3>
            <form id="addUserForm">
                <div class="form-group">
                    <label for="userName">Full Name:</label>
                    <input type="text" id="userName" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="userEmail">Email Address:</label>
                    <input type="email" id="userEmail" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="userRole">Role:</label>
                    <select id="userRole" class="form-control" required>
                        ${Object.entries(ROLES).map(([key, role]) => 
                            `<option value="${key}">${role.name}</option>`
                        ).join('')}
                    </select>
                </div>
                <div class="form-group">
                    <label for="userDomains">Domain Expertise:</label>
                    <div class="checkbox-group">
                        <label><input type="checkbox" value="generative-ai"> Generative AI</label>
                        <label><input type="checkbox" value="containerization"> Containerization</label>
                        <label><input type="checkbox" value="devops"> DevOps</label>
                        <label><input type="checkbox" value="test-automation"> Test Automation</label>
                        <label><input type="checkbox" value="all"> All Domains</label>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="untitledui-save-01"></i> Add User
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                </div>
            </form>
        </div>
    `;
    
    showModal('Add New User', modalContent);
    
    // Setup form submission
    document.getElementById('addUserForm').addEventListener('submit', function(e) {
        e.preventDefault();
        saveNewUser();
    });
}

// Save new user
function saveNewUser() {
    const name = document.getElementById('userName').value;
    const email = document.getElementById('userEmail').value;
    const role = document.getElementById('userRole').value;
    const domains = Array.from(document.querySelectorAll('#userDomains input:checked')).map(cb => cb.value);
    
    if (!name || !email || !role) {
        showMessage('Error', 'Please fill in all required fields', 'error');
        return;
    }
    
    const newUser = {
        id: Math.max(...usersData.map(u => u.id)) + 1,
        name,
        email,
        role,
        domainExpertise: domains,
        status: 'active',
        lastLogin: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        permissions: ROLES[role].permissions
    };
    
    usersData.push(newUser);
    loadUsers();
    closeModal();
    showMessage('Success', `User ${name} has been added successfully`, 'success');
}

// Edit user
function editUser(userId) {
    const user = usersData.find(u => u.id === userId);
    if (!user) return;
    
    const modalContent = `
        <div class="edit-user-form">
            <h3>Edit User: ${user.name}</h3>
            <form id="editUserForm">
                <div class="form-group">
                    <label for="editUserName">Full Name:</label>
                    <input type="text" id="editUserName" class="form-control" value="${user.name}" required>
                </div>
                <div class="form-group">
                    <label for="editUserEmail">Email Address:</label>
                    <input type="email" id="editUserEmail" class="form-control" value="${user.email}" required>
                </div>
                <div class="form-group">
                    <label for="editUserRole">Role:</label>
                    <select id="editUserRole" class="form-control" required>
                        ${Object.entries(ROLES).map(([key, role]) => 
                            `<option value="${key}" ${user.role === key ? 'selected' : ''}>${role.name}</option>`
                        ).join('')}
                    </select>
                </div>
                <div class="form-group">
                    <label for="editUserStatus">Status:</label>
                    <select id="editUserStatus" class="form-control" required>
                        <option value="active" ${user.status === 'active' ? 'selected' : ''}>Active</option>
                        <option value="inactive" ${user.status === 'inactive' ? 'selected' : ''}>Inactive</option>
                    </select>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="untitledui-save-01"></i> Update User
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                </div>
            </form>
        </div>
    `;
    
    showModal('Edit User', modalContent);
    
    // Setup form submission
    document.getElementById('editUserForm').addEventListener('submit', function(e) {
        e.preventDefault();
        saveUserEdits(userId);
    });
}

// Save user edits
function saveUserEdits(userId) {
    const user = usersData.find(u => u.id === userId);
    if (!user) return;
    
    user.name = document.getElementById('editUserName').value;
    user.email = document.getElementById('editUserEmail').value;
    user.role = document.getElementById('editUserRole').value;
    user.status = document.getElementById('editUserStatus').value;
    user.permissions = ROLES[user.role].permissions;
    
    loadUsers();
    closeModal();
    showMessage('Success', `User ${user.name} has been updated successfully`, 'success');
}

// View user details
function viewUserDetails(userId) {
    const user = usersData.find(u => u.id === userId);
    if (!user) return;
    
    const modalContent = `
        <div class="user-details">
            <div class="user-header">
                <i class="untitledui-user-circle user-avatar-large"></i>
                <div class="user-info">
                    <h2>${user.name}</h2>
                    <p class="user-role">${ROLES[user.role].name}</p>
                    <p class="user-email">${user.email}</p>
                </div>
                <div class="user-status ${user.status}">
                    <i class="untitledui-${user.status === 'active' ? 'check-circle' : 'x-circle'}"></i>
                    ${user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                </div>
            </div>
            
            <div class="user-details-content">
                <div class="detail-section">
                    <h3>Role & Permissions</h3>
                    <div class="role-info">
                        <p><strong>Role Level:</strong> ${ROLES[user.role].level}</p>
                        <p><strong>Description:</strong> ${ROLES[user.role].description}</p>
                        <div class="permissions-list">
                            <strong>Permissions:</strong>
                            <ul>
                                ${user.permissions.map(permission => 
                                    `<li><i class="untitledui-check"></i> ${permission}</li>`
                                ).join('')}
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h3>Domain Expertise</h3>
                    <div class="domain-tags">
                        ${user.domainExpertise.map(domain => 
                            `<span class="domain-tag ${domain}">${formatDomainName(domain)}</span>`
                        ).join('')}
                    </div>
                </div>
                
                <div class="detail-section">
                    <h3>Activity Information</h3>
                    <p><strong>Last Login:</strong> ${formatDateTime(user.lastLogin)}</p>
                    <p><strong>Account Created:</strong> ${formatDateTime(user.createdAt)}</p>
                </div>
            </div>
        </div>
    `;
    
    showModal('User Details', modalContent);
}

// Delete user
function deleteUser(userId) {
    const user = usersData.find(u => u.id === userId);
    if (!user) return;
    
    if (confirm(`Are you sure you want to delete user ${user.name}? This action cannot be undone.`)) {
        const index = usersData.findIndex(u => u.id === userId);
        if (index > -1) {
            usersData.splice(index, 1);
            loadUsers();
            showMessage('Success', `User ${user.name} has been deleted`, 'success');
        }
    }
}

// Utility functions
function formatDomainName(domain) {
    const names = {
        'generative-ai': 'Generative AI',
        'containerization': 'Containerization',
        'devops': 'DevOps',
        'test-automation': 'Test Automation',
        'all': 'All Domains'
    };
    return names[domain] || domain;
}

function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('usersTable')) {
        initializeAccessControl();
    }
});
