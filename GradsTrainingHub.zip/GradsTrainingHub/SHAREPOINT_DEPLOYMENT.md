# SharePoint Deployment Guide

## Quick Deployment Steps

### Option 1: Site Assets Library (Recommended)

1. **Navigate to your SharePoint site**
   - Go to your SharePoint site where you want to deploy the portal

2. **Access Site Assets**
   ```
   Site Contents → Site Assets (or _layouts/15/viewlsts.aspx)
   ```

3. **Upload Files**
   - Upload `index.html` to the root of Site Assets
   - Create `css` folder and upload `styles.css`
   - Create `js` folder and upload all JavaScript files
   - Maintain the exact folder structure

4. **Set Permissions**
   - Ensure all users have Read access to Site Assets
   - Grant appropriate permissions based on user roles

5. **Access the Portal**
   ```
   https://[your-tenant].sharepoint.com/sites/[site-name]/SiteAssets/index.html
   ```

### Option 2: Document Library

1. **Create Document Library**
   ```
   Site Contents → New → Document Library → "TrainingPortal"
   ```

2. **Configure Library Settings**
   - Allow all file types
   - Enable versioning
   - Set appropriate permissions

3. **Upload Files**
   - Upload maintaining folder structure
   - Enable sharing for the library

4. **Create Landing Page**
   - Create a new SharePoint page
   - Add "File viewer" web part
   - Point to your index.html file

### Option 3: SharePoint Framework (Advanced)

1. **Prerequisites**
   ```bash
   npm install -g @microsoft/generator-sharepoint
   ```

2. **Create SPFx Solution**
   ```bash
   yo @microsoft/sharepoint
   # Choose: WebPart
   # Name: TrainingPortal
   # Framework: No Framework
   ```

3. **Copy Files**
   - Copy HTML content to the web part render method
   - Add CSS to the web part styles
   - Include JavaScript in the web part

4. **Build and Deploy**
   ```bash
   gulp bundle --ship
   gulp package-solution --ship
   # Upload .sppkg to App Catalog
   ```

## SharePoint Integration Features

### 1. SharePoint Lists Setup

Create the following lists in your SharePoint site:

#### Training Sessions List
```
Columns:
- Title (Single line of text)
- Domain (Choice: Generative AI, Containerization, DevOps, Test Automation)
- Session Date (Date/Time)
- Start Time (Single line of text)
- End Time (Single line of text)
- Trainer (Person/Group)
- WebEx Link (Hyperlink)
- Materials (Attachments)
- Session Status (Choice: Scheduled, Completed, Cancelled)
```

#### Attendance List
```
Columns:
- Title (Single line of text - Student Name)
- Session (Lookup to Training Sessions)
- Student (Person/Group)
- Attendance Status (Choice: Present, Absent, Excused)
- Timestamp (Date/Time)
- Method (Choice: WebEx Auto, Manual, Override)
- Notes (Multiple lines of text)
```

#### Student Progress List
```
Columns:
- Title (Single line of text - Student Name)
- Student (Person/Group)
- Domain (Choice: Generative AI, Containerization, DevOps, Test Automation)
- Week Number (Number: 1-6)
- Progress Percentage (Number: 0-100)
- Assignments Completed (Number)
- Quiz Scores (Number)
- Last Updated (Date/Time)
- Remarks (Multiple lines of text)
```

#### Trainer Availability List
```
Columns:
- Title (Single line of text - Date)
- Trainer (Person/Group)
- Date (Date/Time)
- Status (Choice: Available, Busy, Out of Office, On Leave)
- Start Time (Single line of text)
- End Time (Single line of text)
- Notes (Multiple lines of text)
```

#### Assignments List
```
Columns:
- Title (Single line of text)
- Domain (Choice: Generative AI, Containerization, DevOps, Test Automation)
- Assignment Type (Choice: Assignment, Quiz, Project, Hackathon)
- Description (Multiple lines of text)
- Due Date (Date/Time)
- Attachments (Attachments)
- Max Score (Number)
- Instructions (Multiple lines of text)
- Created By (Person/Group)
- Created Date (Date/Time)
```

#### Assignment Submissions List
```
Columns:
- Title (Single line of text)
- Assignment (Lookup to Assignments)
- Student (Person/Group)
- Submission Date (Date/Time)
- Submission Text (Multiple lines of text)
- Attachments (Attachments)
- Score (Number)
- Feedback (Multiple lines of text)
- Status (Choice: Submitted, Graded, Late, Missing)
```

### 2. Permissions Setup

#### Site-Level Permissions
```
1. Site Owners (Full Control):
   - Program administrators
   - IT administrators

2. Site Members (Contribute):
   - Senior trainers
   - Program coordinators

3. Site Visitors (Read):
   - Students
   - Mid-level trainers (view only)
```

#### List-Level Permissions
```
Training Sessions List:
- Owners: Full Control
- Trainers: Contribute (own items only)
- Students: Read

Attendance List:
- Owners: Full Control
- Trainers: Contribute
- Students: Read (own records only)

Student Progress List:
- Owners: Full Control
- Trainers: Read
- Students: Read (own records only)

Assignments List:
- Owners: Full Control
- Trainers: Contribute
- Students: Read

Submissions List:
- Owners: Full Control
- Trainers: Read/Write
- Students: Contribute (own items only)
```

### 3. Integration Code

Update your JavaScript files to integrate with SharePoint REST API:

#### In js/app.js - Add SharePoint integration:
```javascript
// SharePoint REST API Configuration
const spConfig = {
    siteUrl: _spPageContextInfo.webAbsoluteUrl,
    listNames: {
        sessions: 'Training Sessions',
        attendance: 'Attendance',
        progress: 'Student Progress',
        trainers: 'Trainer Availability',
        assignments: 'Assignments',
        submissions: 'Assignment Submissions'
    }
};

// Function to get data from SharePoint list
async function getSharePointData(listName, query = '') {
    const url = `${spConfig.siteUrl}/_api/web/lists/getbytitle('${listName}')/items${query}`;
    
    try {
        const response = await fetch(url, {
            headers: {
                'Accept': 'application/json;odata=verbose',
                'X-RequestDigest': document.getElementById('__REQUESTDIGEST').value
            }
        });
        
        const data = await response.json();
        return data.d.results;
    } catch (error) {
        console.error('Error fetching SharePoint data:', error);
        return [];
    }
}

// Function to create item in SharePoint list
async function createSharePointItem(listName, itemData) {
    const url = `${spConfig.siteUrl}/_api/web/lists/getbytitle('${listName}')/items`;
    
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Accept': 'application/json;odata=verbose',
                'Content-Type': 'application/json;odata=verbose',
                'X-RequestDigest': document.getElementById('__REQUESTDIGEST').value
            },
            body: JSON.stringify({
                __metadata: { type: `SP.Data.${listName.replace(/\s/g, '')}ListItem` },
                ...itemData
            })
        });
        
        return await response.json();
    } catch (error) {
        console.error('Error creating SharePoint item:', error);
        throw error;
    }
}
```

### 4. WebEx Integration

For automatic attendance tracking, integrate with WebEx APIs:

```javascript
// WebEx API Configuration
const webexConfig = {
    accessToken: 'YOUR_WEBEX_ACCESS_TOKEN',
    baseURL: 'https://webexapis.com/v1'
};

// Function to get meeting participants
async function getWebexParticipants(meetingId) {
    const url = `${webexConfig.baseURL}/meetings/${meetingId}/participants`;
    
    try {
        const response = await fetch(url, {
            headers: {
                'Authorization': `Bearer ${webexConfig.accessToken}`,
                'Content-Type': 'application/json'
            }
        });
        
        const data = await response.json();
        return data.items;
    } catch (error) {
        console.error('Error fetching WebEx participants:', error);
        return [];
    }
}

// Function to auto-mark attendance from WebEx
async function autoMarkAttendance(sessionId, meetingId) {
    const participants = await getWebexParticipants(meetingId);
    
    participants.forEach(async (participant) => {
        const attendanceData = {
            Title: participant.displayName,
            SessionId: sessionId,
            AttendanceStatus: 'Present',
            Timestamp: new Date().toISOString(),
            Method: 'WebEx Auto'
        };
        
        await createSharePointItem('Attendance', attendanceData);
    });
}
```

## Security Configuration

### 1. Content Security Policy
Add to SharePoint master page or web part:
```html
<meta http-equiv="Content-Security-Policy" content="
    default-src 'self' *.sharepoint.com *.office.com;
    script-src 'self' 'unsafe-inline' cdnjs.cloudflare.com;
    style-src 'self' 'unsafe-inline' cdnjs.cloudflare.com;
    font-src 'self' cdnjs.cloudflare.com;
    img-src 'self' data: *.sharepoint.com;
">
```

### 2. SharePoint App Permissions
If using SPFx or SharePoint Apps:
```xml
<AppPermissionRequests AllowAppOnlyPolicy="false">
  <AppPermissionRequest Scope="http://sharepoint/content/sitecollection/web/list" Right="FullControl" />
  <AppPermissionRequest Scope="http://sharepoint/content/sitecollection/web" Right="Read" />
</AppPermissionRequests>
```

## Troubleshooting

### Common SharePoint Issues

1. **CORS Errors**
   ```
   Solution: Use SharePoint's built-in authentication
   Ensure all API calls include proper headers
   ```

2. **Permission Denied**
   ```
   Solution: Check SharePoint list permissions
   Verify user has appropriate access levels
   ```

3. **Script Loading Issues**
   ```
   Solution: Check custom script settings in SharePoint admin
   Enable custom scripts if disabled
   ```

4. **File Type Blocking**
   ```
   Solution: Add .html, .css, .js to allowed file types
   Update SharePoint file type restrictions
   ```

### Performance Optimization

1. **Enable CDN**
   ```
   Use SharePoint Online CDN for static files
   Configure public CDN endpoints
   ```

2. **Minimize API Calls**
   ```
   Implement caching for SharePoint data
   Use batch requests where possible
   ```

3. **Optimize Load Times**
   ```
   Minimize and compress CSS/JS files
   Use SharePoint's built-in compression
   ```

## Go-Live Checklist

- [ ] All SharePoint lists created with correct columns
- [ ] Permissions configured for all user roles
- [ ] Files uploaded to Site Assets or Document Library
- [ ] WebEx integration configured (if applicable)
- [ ] User accounts added to appropriate SharePoint groups
- [ ] Testing completed with sample data
- [ ] Training materials prepared for end users
- [ ] Backup and recovery procedures established
- [ ] Performance monitoring configured
- [ ] Support procedures documented

## Post-Deployment

1. **Monitor Usage**
   - Review SharePoint analytics
   - Monitor error logs
   - Track user adoption

2. **Regular Maintenance**
   - Update data regularly
   - Review and adjust permissions
   - Apply security updates

3. **User Support**
   - Provide training sessions
   - Create user documentation
   - Establish support channels

---

**Need Help?** Contact your SharePoint administrator or refer to Microsoft's SharePoint documentation for additional configuration options.
