// Utility to generate master data for Resource Onboarding Tracker

const firstNames = ['John', 'Maria', 'Michael', 'Sarah', 'Alex', 'Emily', 'David', 'Lisa', 'James', 'Anna', 'Robert', 'Jennifer', 'William', 'Jessica', 'Christopher', 'Ashley', 'Daniel', 'Amanda', 'Matthew', 'Stephanie', 'Anthony', 'Melissa', 'Mark', 'Nicole', 'Donald', 'Elizabeth', 'Steven', 'Helen', 'Paul', 'Sandra', 'Andrew', 'Donna', 'Joshua', 'Carol', 'Kenneth', 'Ruth', 'Kevin', 'Sharon', 'Brian', 'Michelle', 'George', 'Laura', 'Timothy', 'Sarah', 'Ronald', 'Kimberly', 'Edward', 'Deborah', 'Jason', 'Dorothy', 'Jeffrey', 'Amy', 'Ryan', 'Angela', 'Jacob', 'Brenda', 'Gary', 'Emma', 'Nicholas', 'Olivia', 'Eric', 'Cynthia', 'Jonathan', 'Marie', 'Stephen', 'Janet', 'Larry', 'Catherine', 'Justin', 'Frances', 'Scott', 'Christine', 'Brandon', 'Samantha', 'Benjamin', 'Debra', 'Samuel', 'Rachel', 'Gregory', 'Carolyn', 'Alexander', 'Janet', 'Patrick', 'Virginia', 'Jack', 'Maria', 'Dennis', 'Heather', 'Jerry', 'Diane', 'Tyler', 'Julie', 'Aaron', 'Joyce', 'Jose', 'Victoria', 'Henry', 'Kelly', 'Adam', 'Christina', 'Douglas', 'Joan', 'Nathan', 'Evelyn', 'Peter', 'Lauren', 'Zachary', 'Judith', 'Kyle', 'Megan', 'Noah', 'Andrea', 'Alan', 'Cheryl', 'Carl', 'Hannah', 'Wayne', 'Jacqueline', 'Arthur', 'Martha', 'Gerald', 'Gloria', 'Harold', 'Teresa', 'Jordan', 'Sara', 'Jesse', 'Janice', 'Bryan', 'Marie', 'Lawrence', 'Julia', 'Arthur', 'Heather', 'Gabriel', 'Diane', 'Bruce', 'Ruth', 'Logan', 'Anna', 'Billy', 'Jean', 'Willie', 'Alice', 'Joe', 'Kathryn', 'Ralph', 'Gloria', 'Roy', 'Teresa', 'Eugene', 'Sara', 'Bobby', 'Janice', 'Louis', 'Marie', 'Philip', 'Julia', 'Johnny', 'Heather'];

const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin', 'Lee', 'Perez', 'Thompson', 'White', 'Harris', 'Sanchez', 'Clark', 'Ramirez', 'Lewis', 'Robinson', 'Walker', 'Young', 'Allen', 'King', 'Wright', 'Scott', 'Torres', 'Nguyen', 'Hill', 'Flores', 'Green', 'Adams', 'Nelson', 'Baker', 'Hall', 'Rivera', 'Campbell', 'Mitchell', 'Carter', 'Roberts', 'Gomez', 'Phillips', 'Evans', 'Turner', 'Diaz', 'Parker', 'Cruz', 'Edwards', 'Collins', 'Reyes', 'Stewart', 'Morris', 'Morales', 'Murphy', 'Cook', 'Rogers', 'Gutierrez', 'Ortiz', 'Morgan', 'Cooper', 'Peterson', 'Bailey', 'Reed', 'Kelly', 'Howard', 'Ramos', 'Kim', 'Cox', 'Ward', 'Richardson', 'Watson', 'Brooks', 'Chavez', 'Wood', 'James', 'Bennett', 'Gray', 'Mendoza', 'Ruiz', 'Hughes', 'Price', 'Alvarez', 'Castillo', 'Sanders', 'Patel', 'Myers', 'Long', 'Ross', 'Foster', 'Jimenez'];

const btgNames = ['BTG-Development', 'BTG-QA', 'BTG-DevOps', 'BTG-UI', 'BTG-BA', 'BTG-DataScience', 'BTG-Cloud', 'BTG-Security', 'BTG-Mobile', 'BTG-Backend'];
const locations = ['Chennai', 'Hyderabad', 'Mumbai', 'Gift City', 'Pune'];
const hiringEntities = ['EY', 'Wipro'];
const waves = [1, 2];
const clusters = [1, 2, 3, 4, 5, 6];
const bands = ['Band 1', 'Band 2', 'Band 3', 'Band 4', 'Band 5'];
const teams = ['Development Team', 'QA Team', 'DevOps Team', 'UI/UX Team', 'Business Analysis Team', 'Data Science Team', 'Cloud Team', 'Security Team', 'Mobile Team', 'Backend Team'];
const hiringTypes = ['Regular', 'Contract', 'Intern'];
const statuses = ['Active', 'On-Hold', 'Onboarding', 'Resigned', 'Terminated', 'BGV', 'Open Requirement'];
const skillsets = [
  'React, Node.js, JavaScript, Python',
  'Manual Testing, Automation, Selenium',
  'AWS, Docker, Kubernetes, Jenkins',
  'Figma, Adobe XD, HTML, CSS, JavaScript',
  'Business Analysis, Requirements Gathering, SQL',
  'Python, Machine Learning, TensorFlow, Data Analysis',
  'Azure, Cloud Architecture, Terraform',
  'Cybersecurity, Penetration Testing, SIEM',
  'React Native, Flutter, iOS, Android',
  'Java, Spring Boot, Microservices, PostgreSQL',
  'Angular, TypeScript, RxJS, NGRX',
  'API Testing, Performance Testing, JMeter',
  'Terraform, Ansible, CI/CD, GitLab',
  'Vue.js, Nuxt.js, SCSS, Webpack',
  'Agile, Scrum, JIRA, Confluence',
  'Tableau, Power BI, ETL, Data Warehousing',
  'GCP, Serverless, Firebase',
  'Ethical Hacking, Security Auditing, Compliance',
  'Swift, Kotlin, Xamarin, Ionic',
  'C#, .NET Core, Entity Framework, SQL Server'
];

const workstations = ['Laptop-DEL-', 'Laptop-HP-', 'Laptop-LEN-', 'Laptop-MAC-', 'Desktop-DEL-', 'Desktop-HP-'];

function getRandomElement(array) {
  return array[Math.floor(Math.random() * array.length)];
}

function getRandomDate(start, end) {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

function formatDate(date) {
  return date.toISOString().split('T')[0];
}

export function generateMasterData(count = 200) {
  const data = [];
  
  // Status distribution to match realistic scenarios
  const statusDistribution = {
    'Active': 80,        // 40% - Most resources are active
    'Onboarding': 30,    // 15% - Currently being onboarded
    'BGV': 25,           // 12.5% - Background verification
    'On-Hold': 20,       // 10% - Temporarily on hold
    'Resigned': 25,      // 12.5% - Have resigned
    'Terminated': 15,    // 7.5% - Terminated
    'Open Requirement': 5 // 2.5% - Open positions
  };

  let currentId = 1;
  
  for (const [status, count] of Object.entries(statusDistribution)) {
    for (let i = 0; i < count; i++) {
      const firstName = getRandomElement(firstNames);
      const lastName = getRandomElement(lastNames);
      const resourceName = `${firstName} ${lastName}`;
      const id = `RES${String(currentId).padStart(3, '0')}`;
      
      const expectedDOJ = getRandomDate(new Date('2024-01-01'), new Date('2024-12-31'));
      const createdDate = getRandomDate(new Date('2024-01-01'), expectedDOJ);
      const modifiedDate = getRandomDate(createdDate, new Date());
      
      let actualDOJ = '';
      let aesBillingDate = '';
      let offBoardDate = '';
      
      if (status === 'Active' || status === 'Onboarding') {
        actualDOJ = formatDate(expectedDOJ);
        aesBillingDate = formatDate(expectedDOJ);
      }
      
      if (status === 'Resigned' || status === 'Terminated') {
        actualDOJ = formatDate(expectedDOJ);
        aesBillingDate = formatDate(expectedDOJ);
        offBoardDate = formatDate(getRandomDate(expectedDOJ, new Date()));
      }
      
      const record = {
        id: id,
        resourceName: resourceName,
        wmp: `WMP${String(currentId).padStart(3, '0')}`,
        workdayId: `WD${12345 + currentId}`,
        btgName: getRandomElement(btgNames),
        managerName: `${getRandomElement(firstNames)} ${getRandomElement(lastNames)}`,
        aesOnboardingWave: getRandomElement(waves),
        aesOnboardingCluster: getRandomElement(clusters),
        location: getRandomElement(locations),
        hiringEntity: getRandomElement(hiringEntities),
        updatedExpectedDOJ: formatDate(expectedDOJ),
        personNo: `P${String(currentId).padStart(3, '0')}`,
        rbkId: `RBK${String(currentId).padStart(3, '0')}`,
        resourceEmailId: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@example.com`,
        currentBand: getRandomElement(bands),
        targetBand: getRandomElement(bands),
        previousManagerName: Math.random() > 0.3 ? `${getRandomElement(firstNames)} ${getRandomElement(lastNames)}` : '',
        previousManagerEmail: Math.random() > 0.3 ? `${getRandomElement(firstNames).toLowerCase()}.${getRandomElement(lastNames).toLowerCase()}@example.com` : '',
        gbsTypeOfHiring: getRandomElement(hiringTypes),
        onboardingStatus: status,
        team: getRandomElement(teams),
        assignedBuddy: `${getRandomElement(firstNames)} ${getRandomElement(lastNames)}`,
        assignedBuddyEmail: `${getRandomElement(firstNames).toLowerCase()}.${getRandomElement(lastNames).toLowerCase()}@example.com`,
        applicantWorkstationDetails: `${getRandomElement(workstations)}${String(currentId).padStart(3, '0')}`,
        offBoardDate: offBoardDate,
        skillset: getRandomElement(skillsets),
        comments: getStatusComment(status),
        itemType: 'Employee',
        path: `/resources/${getRandomElement(btgNames).toLowerCase().replace('btg-', '')}`,
        mobileNumber: `+91-${Math.floor(Math.random() * 9000000000) + 1000000000}`,
        expectedDOJ: formatDate(expectedDOJ),
        actualDOJ: actualDOJ,
        aesBillingDate: aesBillingDate,
        modified: formatDate(modifiedDate),
        created: formatDate(createdDate),
        modifiedBy: 'HR Admin',
        createdBy: 'Recruiter'
      };
      
      data.push(record);
      currentId++;
    }
  }
  
  return data;
}

function getStatusComment(status) {
  const comments = {
    'Active': [
      'High performer, quick learner',
      'Excellent team player',
      'Strong technical skills',
      'Good communication skills',
      'Proactive and reliable',
      'Meeting all expectations'
    ],
    'Onboarding': [
      'Onboarding in progress',
      'Completing initial training',
      'System access being setup',
      'Buddy assignment completed',
      'Documentation review ongoing',
      'First week orientation'
    ],
    'BGV': [
      'Background verification in progress',
      'Documents submitted for verification',
      'Reference check ongoing',
      'Education verification pending',
      'Previous employment verification',
      'Final BGV report awaited'
    ],
    'On-Hold': [
      'Project allocation pending',
      'Client approval awaited',
      'Budget approval pending',
      'Visa processing delays',
      'Training completion required',
      'Temporary hold due to restructuring'
    ],
    'Resigned': [
      'Better opportunity elsewhere',
      'Personal reasons',
      'Career growth opportunity',
      'Relocation requirements',
      'Higher education pursuit',
      'Family commitments'
    ],
    'Terminated': [
      'Performance issues',
      'Policy violation',
      'Attendance concerns',
      'Project completion failure',
      'Skill mismatch',
      'Behavioral issues'
    ],
    'Open Requirement': [
      'Position not yet filled',
      'Recruitment in progress',
      'Candidate screening ongoing',
      'Interview process initiated',
      'Offer negotiation stage',
      'Awaiting candidate acceptance'
    ]
  };
  
  return getRandomElement(comments[status] || ['Standard onboarding process']);
}
