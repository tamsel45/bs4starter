import React, { useState } from 'react';
import ProgressCircle from './ProgressCircle';
import MetricsCards from './MetricsCards';
import ResourceTables from './ResourceTables';
import OnboardingSummaryTables from './OnboardingSummaryTables';
import OnboardingDialog from './OnboardingDialog';
import { generateMasterData } from '../utils/generateMasterData';
import './Dashboard.css';
import { Button } from 'primereact/button';
import { Card } from 'primereact/card';
import { Badge } from 'primereact/badge';
import { TabView, TabPanel } from 'primereact/tabview';


function Dashboard() {
  const [dialogVisible, setDialogVisible] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editingResource, setEditingResource] = useState(null);
  const [activeTab, setActiveTab] = useState(0);
  const [statusFilter, setStatusFilter] = useState(null);
  const [filterType, setFilterType] = useState(null); // 'status', 'wave', 'cluster', 'location', 'hiring'
  const [filterValue, setFilterValue] = useState(null);
  const [tableData, setTableData] = useState({
    EYRegular: [
      {
        requireDate: '2024-01-15',
        team: 'Development',
        wave1: 25,
        wave2: 20,
        total: 45,
        totalSelected: 42,
        dropOuts: 3,
        r1YetToSchedule: 5,
        r1Schedule: 15,
        r1Reject: 3,
        r2YetToSchedule: 8,
        r2Schedule: 12,
        r2Reject: 2,
        r2Select: 10,
        wave1Completed: '85%',
        wave2Completed: '78%'
      },
      {
        requireDate: '2024-02-01',
        team: 'QA Testing',
        wave1: 18,
        wave2: 15,
        total: 33,
        totalSelected: 30,
        dropOuts: 2,
        r1YetToSchedule: 3,
        r1Schedule: 12,
        r1Reject: 1,
        r2YetToSchedule: 6,
        r2Schedule: 9,
        r2Reject: 1,
        r2Select: 8,
        wave1Completed: '92%',
        wave2Completed: '88%'
      },
      {
        requireDate: '2024-02-15',
        team: 'DevOps',
        wave1: 12,
        wave2: 10,
        total: 22,
        totalSelected: 20,
        dropOuts: 1,
        r1YetToSchedule: 2,
        r1Schedule: 8,
        r1Reject: 1,
        r2YetToSchedule: 4,
        r2Schedule: 6,
        r2Reject: 0,
        r2Select: 6,
        wave1Completed: '95%',
        wave2Completed: '90%'
      },
      {
        requireDate: '2024-03-01',
        team: 'UI/UX',
        wave1: 8,
        wave2: 7,
        total: 15,
        totalSelected: 14,
        dropOuts: 1,
        r1YetToSchedule: 1,
        r1Schedule: 6,
        r1Reject: 0,
        r2YetToSchedule: 3,
        r2Schedule: 4,
        r2Reject: 0,
        r2Select: 4,
        wave1Completed: '98%',
        wave2Completed: '94%'
      },
      {
        requireDate: '2024-03-15',
        team: 'Business Analysis',
        wave1: 15,
        wave2: 12,
        total: 27,
        totalSelected: 25,
        dropOuts: 2,
        r1YetToSchedule: 3,
        r1Schedule: 10,
        r1Reject: 1,
        r2YetToSchedule: 5,
        r2Schedule: 7,
        r2Reject: 1,
        r2Select: 6,
        wave1Completed: '88%',
        wave2Completed: '82%'
      }
    ],
    EYAdditional: [],
    WiproRegular: [],
    masterData: generateMasterData(200)
  });

  // Global function to clear all filters (accessible from child components)
  React.useEffect(() => {
    window.clearAllFilters = () => {
      setFilterType(null);
      setFilterValue(null);
      setStatusFilter(null);
    };
    
    // Cleanup function
    return () => {
      delete window.clearAllFilters;
    };
  }, []);

  const handleCardClick = (cardLabel) => {
    // Define different filter categories
    const statusMetrics = ['Active', 'On-Hold', 'Onboarding', 'Open Requirement', 'Resigned', 'Terminated', 'BGV'];
    const waveMetrics = ['Wave 1', 'Wave 2'];
    const clusterMetrics = ['Cluster 1', 'Cluster 2', 'Cluster 3', 'Cluster 4', 'Cluster 5', 'Cluster 6'];
    const locationMetrics = ['Chennai', 'Hyderabad', 'Mumbai', 'Gift City', 'Pune'];
    const hiringMetrics = ['Regular', 'Contract', 'Intern'];
    
    if (statusMetrics.includes(cardLabel)) {
      setFilterType('status');
      setFilterValue(cardLabel);
      setStatusFilter(cardLabel); // Keep for backward compatibility
    } else if (waveMetrics.includes(cardLabel)) {
      setFilterType('wave');
      // Convert "Wave 1" to 1, "Wave 2" to 2
      const waveNumber = parseInt(cardLabel.split(' ')[1]);
      setFilterValue(waveNumber);
      setStatusFilter(null);
    } else if (clusterMetrics.includes(cardLabel)) {
      setFilterType('cluster');
      // Convert "Cluster 1" to 1, etc.
      const clusterNumber = parseInt(cardLabel.split(' ')[1]);
      setFilterValue(clusterNumber);
      setStatusFilter(null);
    } else if (locationMetrics.includes(cardLabel)) {
      setFilterType('location');
      setFilterValue(cardLabel);
      setStatusFilter(null);
    } else if (hiringMetrics.includes(cardLabel)) {
      setFilterType('hiring');
      setFilterValue(cardLabel);
      setStatusFilter(null);
    } else {
      // Clear all filters
      setFilterType(null);
      setFilterValue(null);
      setStatusFilter(null);
    }
    
    setActiveTab(1); // Always switch to Resources tab
  };

  const handleEditResource = (resource) => {
    setEditingResource(resource);
    setEditMode(true);
    setDialogVisible(true);
  };

  const handleDialogSubmitEdit = (updatedRecord) => {
    if (editMode && editingResource) {
      // Update existing record
      setTableData(prev => ({
        ...prev,
        masterData: prev.masterData.map(item => 
          item.id === editingResource.id ? { ...updatedRecord, id: editingResource.id } : item
        )
      }));
      console.log('Resource updated successfully:', updatedRecord);
    } else {
      // Add new record (existing functionality)
      const maxId = Math.max(...tableData.masterData.map(item => item.id || 0));
      const newRecordWithId = {
        ...updatedRecord,
        id: maxId + 1
      };

      setTableData(prev => ({
        ...prev,
        masterData: [...prev.masterData, newRecordWithId]
      }));
      console.log('New resource added successfully:', newRecordWithId);
    }
    
    // Reset edit state
    setDialogVisible(false);
    setEditMode(false);
    setEditingResource(null);
  };

  const handleDialogHide = () => {
    setDialogVisible(false);
    setEditMode(false);
    setEditingResource(null);
  };

  return (
    <div className="modern-layout">
      {/* Top Navigation Header */}
      <header className="top-navbar">
        <div className="navbar-content">
          <div className="navbar-left">
            <div className="brand">
              <div className="brand-icon">
                <i className="pi pi-chart-pie"></i>
              </div>
              <div className="brand-text">
                <h2>Resource Tracker</h2>
                <span>Onboarding Management</span>
              </div>
            </div>
            {/* Navigation moved to TabView tabs below */}
          </div>
          
          <div className="navbar-right">
            <div className="user-profile">
              <Badge value="3" className="notification-badge">
                <i className="pi pi-bell notification-icon"></i>
              </Badge>
              <div className="user-info">
                <span className="user-name">Admin User</span>
                <span className="user-role">System Administrator</span>
              </div>
              <div className="user-avatar">
                <i className="pi pi-user"></i>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}

      <main className="main-content">
        <div className="page-content">
          <div className="tab-header-container">
            <TabView 
              activeIndex={activeTab} 
              onTabChange={e => setActiveTab(e.index)} 
              className="dashboard-tabs"
            >
              <TabPanel header={<span><i className="pi pi-home"></i> Dashboard</span>}>
              <div className="grid">
                <MetricsCards onCardClick={handleCardClick} masterData={tableData.masterData} />
                <div className="col-12">
                  <div className="grid">
                    <div className="col-12 lg:col-8">
                      <ProgressCircle masterData={tableData.masterData} />
                    </div>
                    <div className="col-12 lg:col-4">
                      <div className="activity-card h-full">
                        <div className="card-header">
                          <h3>Recent Activities</h3>
                        </div>
                        <div className="activity-list">
                          <div className="activity-item">
                            <div className="activity-icon success">
                              <i className="pi pi-check"></i>
                            </div>
                            <div className="activity-content">
                              <h4>John Smith onboarded successfully</h4>
                              <p>Completed Wave 1 requirements</p>
                              <span className="activity-time">2 hours ago</span>
                            </div>
                          </div>
                          <div className="activity-item">
                            <div className="activity-icon warning">
                              <i className="pi pi-exclamation-triangle"></i>
                            </div>
                            <div className="activity-content">
                              <h4>BGV pending for 3 candidates</h4>
                              <p>Background verification in progress</p>
                              <span className="activity-time">4 hours ago</span>
                            </div>
                          </div>
                          <div className="activity-item">
                            <div className="activity-icon info">
                              <i className="pi pi-info-circle"></i>
                            </div>
                            <div className="activity-content">
                              <h4>New batch assigned to Wave 2</h4>
                              <p>15 resources moved to next phase</p>
                              <span className="activity-time">6 hours ago</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-12">
                    <ResourceTables 
                      masterData={tableData.masterData}
                      statusFilter={null}
                      onEditResource={handleEditResource}
                    />
                </div>
              </div>
            </TabPanel>
            <TabPanel header={<span><i className="pi pi-users"></i> Resources</span>}>
              <div className="grid">
                <div className="col-12">
                    <ResourceTables 
                      masterData={tableData.masterData}
                      statusFilter={statusFilter}
                      filterType={filterType}
                      filterValue={filterValue}
                      onEditResource={handleEditResource}
                    />
                </div>
              </div>
            </TabPanel>
            <TabPanel header={<span><i className="pi pi-chart-bar"></i> Summary Tables</span>}>
              <div className="grid">
                <div className="col-12">
                    <OnboardingSummaryTables 
                      masterData={tableData.masterData}
                    />
                </div>
              </div>
            </TabPanel>
          </TabView>
          <Button
            label="Add Resource"
            icon="pi pi-plus"
            className="add-resource-btn tab-action-btn"
            onClick={() => setDialogVisible(true)}
            size="small"
          />
          </div>
        </div>
      </main>

      <OnboardingDialog 
        visible={dialogVisible} 
        onHide={handleDialogHide} 
        onSubmit={handleDialogSubmitEdit}
        masterData={tableData.masterData}
        editMode={editMode}
        editData={editingResource}
      />
    </div>
  );
}

export default Dashboard;
