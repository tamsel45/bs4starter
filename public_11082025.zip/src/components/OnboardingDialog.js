import React, { useState } from 'react';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Dropdown } from 'primereact/dropdown';
import { Calendar } from 'primereact/calendar';
import PropTypes from 'prop-types';
import './OnboardingDialog.css';

const dropdownOptions = {
  btgName: ['BTG-Development', 'BTG-QA', 'BTG-DevOps', 'BTG-UI', 'BTG-BA', 'BTG-DataScience', 'BTG-Cloud', 'BTG-Security', 'BTG-Mobile', 'BTG-Backend'],
  team: ['Development Team', 'QA Team', 'DevOps Team', 'UI/UX Team', 'Business Analysis Team', 'Data Science Team', 'Cloud Team', 'Security Team', 'Mobile Team', 'Backend Team'],
  managerName: ['John Smith', 'Sarah Johnson', 'Mike Wilson', 'Emily Davis', 'David Brown', 'Lisa Anderson', 'James Wilson', 'Anna Garcia'],
  hiringEntity: ['EY', 'Wipro'],
  location: ['Chennai', 'Hyderabad', 'Mumbai', 'Gift City', 'Pune'],
  onboardingStatus: ['Active', 'On-Hold', 'Onboarding', 'Resigned', 'Terminated', 'BGV', 'Open Requirement', 'Completed'],
  currentBand: ['Band 1', 'Band 2', 'Band 3', 'Band 4', 'Band 5'],
  targetBand: ['Band 1', 'Band 2', 'Band 3', 'Band 4', 'Band 5'],
  gbsTypeOfHiring: ['Regular', 'Contract', 'Intern'],
  aesOnboardingWave: ['1', '2'],
  aesOnboardingCluster: ['1', '2', '3', '4', '5', '6'],
  role: ['Developer', 'Tester', 'Business Analyst', 'Project Manager', 'DevOps Engineer', 'UI/UX Designer', 'Data Scientist', 'Cloud Architect']
};

const fields = [
  { name: 'resourceName', label: 'Resource Name', type: 'input', required: true, tooltip: 'Full name of the resource' },
  { name: 'skillset', label: 'Skillset', type: 'textarea', required: true, tooltip: 'Technical skills and expertise' },
  { name: 'btgName', label: 'BTG Name', type: 'dropdown', required: true, tooltip: 'Business Technology Group assignment' },
  { name: 'wmp', label: 'WMP', type: 'input', required: true, tooltip: 'Workforce Management Program identifier' },
  { name: 'workdayId', label: 'Workday ID', type: 'input', required: true, tooltip: 'Unique Workday system identifier' },
  { name: 'team', label: 'Team', type: 'dropdown', required: true, tooltip: 'Assigned team for the resource' },
  { name: 'managerName', label: 'Manager Name', type: 'dropdown', required: true, tooltip: 'Direct reporting manager' },
  { name: 'aesOnboardingWave', label: 'AES Onboarding Wave', type: 'dropdown', required: true, tooltip: 'Onboarding wave assignment (1 or 2)' },
  { name: 'aesOnboardingCluster', label: 'AES Onboarding Cluster', type: 'dropdown', required: true, tooltip: 'Onboarding cluster assignment' },
  { name: 'hiringEntity', label: 'Hiring Entity', type: 'dropdown', required: true, tooltip: 'Organization handling the hiring (EY or Wipro)' },
  { name: 'location', label: 'Location', type: 'dropdown', required: true, tooltip: 'Work location assignment' },
  { name: 'onboardingStatus', label: 'Onboarding Status', type: 'dropdown', required: true, tooltip: 'Current onboarding progress status' },
  { name: 'currentBand', label: 'Current Band', type: 'dropdown', required: true, tooltip: 'Current job band level' },
  { name: 'targetBand', label: 'Target Band', type: 'dropdown', required: true, tooltip: 'Target job band level' },
  { name: 'gbsTypeOfHiring', label: 'GBS Type of Hiring', type: 'dropdown', required: true, tooltip: 'Global Business Services hiring classification' },
  { name: 'previousManagerName', label: 'Previous Manager Name', type: 'input', required: false, tooltip: 'Name of previous manager (if applicable)' },
  { name: 'previousManagerEmail', label: 'Previous Manager Email', type: 'input', required: false, tooltip: 'Contact email for previous manager' },
  { name: 'assignedBuddy', label: 'Assigned Buddy', type: 'input', required: false, tooltip: 'Onboarding buddy assigned to resource' },
  { name: 'assignedBuddyEmail', label: 'Assigned Buddy Email', type: 'input', required: false, tooltip: 'Contact email for assigned buddy' },
  { name: 'rbkId', label: 'RBK ID', type: 'input', required: false, tooltip: 'RBK Information System identifier' },
  { name: 'personNo', label: 'Person No', type: 'input', required: false, tooltip: 'Person number identifier' },
  { name: 'resourceEmailId', label: 'Resource Email ID', type: 'input', required: true, tooltip: 'Official email address of resource' },
  { name: 'applicantWorkstationDetails', label: 'Applicant Workstation Details', type: 'input', required: false, tooltip: 'Workstation setup information' },
  { name: 'offBoardDate', label: 'Off-Board Date', type: 'calendar', required: false, tooltip: 'Expected or actual off-boarding date' },
  { name: 'updatedExpectedDOJ', label: 'Updated Expected DOJ', type: 'calendar', required: false, tooltip: 'Revised date of joining' },
  { name: 'expectedDOJ', label: 'Expected DOJ', type: 'calendar', required: false, tooltip: 'Expected date of joining' },
  { name: 'actualDOJ', label: 'Actual DOJ', type: 'calendar', required: false, tooltip: 'Actual date of joining' },
  { name: 'aesBillingDate', label: 'AES Billing Date', type: 'calendar', required: false, tooltip: 'AES billing details completion date' },
  { name: 'mobileNumber', label: 'Mobile Number', type: 'input', required: false, tooltip: 'Contact mobile number' },
  { name: 'comments', label: 'Comments', type: 'textarea', required: false, tooltip: 'Additional comments or notes' }
];

function OnboardingDialog({ visible, onHide, onSubmit, masterData = [], editMode = false, editData = null }) {
  const [form, setForm] = useState({});
  const [errors, setErrors] = useState({});

  // Generate dynamic dropdown options from master data
  const getDynamicDropdownOptions = () => {
    const dynamicOptions = { ...dropdownOptions };
    
    if (masterData.length > 0) {
      // Extract unique values from master data for certain fields
      const uniqueManagers = [...new Set(masterData.map(item => item.managerName).filter(Boolean))];
      const uniqueBTGs = [...new Set(masterData.map(item => item.btgName).filter(Boolean))];
      const uniqueTeams = [...new Set(masterData.map(item => item.team).filter(Boolean))];
      
      // Update dropdown options with existing data + defaults
      if (uniqueManagers.length > 0) {
        dynamicOptions.managerName = [...new Set([...dropdownOptions.managerName, ...uniqueManagers])];
      }
      if (uniqueBTGs.length > 0) {
        dynamicOptions.btgName = [...new Set([...dropdownOptions.btgName, ...uniqueBTGs])];
      }
      if (uniqueTeams.length > 0) {
        dynamicOptions.team = [...new Set([...dropdownOptions.team, ...uniqueTeams])];
      }
    }
    
    return dynamicOptions;
  };

  // Clear form and errors when dialog opens, or populate when editing
  React.useEffect(() => {
    if (visible) {
      if (editMode && editData) {
        // Populate form with edit data
        const populatedForm = {};
        fields.forEach(field => {
          if (editData[field.name] !== undefined) {
            // Handle date fields - convert string dates back to Date objects
            if (field.type === 'calendar' && editData[field.name]) {
              populatedForm[field.name] = new Date(editData[field.name]);
            } else {
              populatedForm[field.name] = editData[field.name];
            }
          }
        });
        setForm(populatedForm);
      } else {
        // Clear form for new entry
        setForm({});
      }
      setErrors({});
    }
  }, [visible, editMode, editData]);

  const handleChange = (name, value) => {
    setForm(prev => ({ ...prev, [name]: value }));
    // Clear error when user starts typing/selecting
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: false }));
    }
  };

  const validate = () => {
    const newErrors = {};
    fields.forEach(f => {
      if (f.required && !form[f.name]) {
        newErrors[f.name] = true;
      }
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) {
      // Create a master data record with all required fields
      const currentDate = new Date();
      const masterDataRecord = {
        id: Date.now(), // Temporary ID generation
        resourceName: form.resourceName || '',
        wmp: form.wmp || '',
        workdayId: form.workdayId || '',
        btgName: form.btgName || '',
        managerName: form.managerName || '',
        aesOnboardingWave: parseInt(form.aesOnboardingWave) || 1,
        aesOnboardingCluster: parseInt(form.aesOnboardingCluster) || 1,
        location: form.location || '',
        hiringEntity: form.hiringEntity || '',
        updatedExpectedDOJ: form.updatedExpectedDOJ ? form.updatedExpectedDOJ.toISOString().split('T')[0] : currentDate.toISOString().split('T')[0],
        personNo: form.personNo || `P${String(Date.now()).slice(-3)}`,
        rbkId: form.rbkId || `RBK${String(Date.now()).slice(-3)}`,
        resourceEmailId: form.resourceEmailId || '',
        currentBand: form.currentBand || '',
        targetBand: form.targetBand || '',
        previousManagerName: form.previousManagerName || '',
        previousManagerEmail: form.previousManagerEmail || '',
        gbsTypeOfHiring: form.gbsTypeOfHiring || 'Regular',
        onboardingStatus: form.onboardingStatus || 'Onboarding',
        team: form.team || '',
        assignedBuddy: form.assignedBuddy || '',
        assignedBuddyEmail: form.assignedBuddyEmail || '',
        applicantWorkstationDetails: form.applicantWorkstationDetails || '',
        offBoardDate: form.offBoardDate ? form.offBoardDate.toISOString().split('T')[0] : '',
        skillset: form.skillset || '',
        comments: form.comments || 'New resource added via dialog',
        itemType: 'Employee',
        path: `/resources/${(form.btgName || 'default').toLowerCase().replace('btg-', '')}`,
        mobileNumber: form.mobileNumber || '',
        expectedDOJ: form.expectedDOJ ? form.expectedDOJ.toISOString().split('T')[0] : currentDate.toISOString().split('T')[0],
        actualDOJ: form.actualDOJ ? form.actualDOJ.toISOString().split('T')[0] : '',
        aesBillingDate: form.aesBillingDate ? form.aesBillingDate.toISOString().split('T')[0] : '',
        modified: currentDate.toISOString().split('T')[0],
        created: currentDate.toISOString().split('T')[0],
        modifiedBy: 'User',
        createdBy: 'User'
      };

      // Submit the record
      onSubmit(masterDataRecord);
      setForm({});
      setErrors({});
    }
  };

  const handleCancel = () => {
    setForm({});
    setErrors({});
    onHide();
  };

  const renderField = (field) => {
    const commonProps = {
      id: field.name,
      className: errors[field.name] ? 'p-invalid' : '',
      'aria-required': field.required
    };

    switch (field.type) {
      case 'input':
        return (
          <InputText
            {...commonProps}
            value={form[field.name] || ''}
            onChange={e => handleChange(field.name, e.target.value)}
            placeholder={`Enter ${field.label}`}
          />
        );
      case 'textarea':
        return (
          <InputTextarea
            {...commonProps}
            value={form[field.name] || ''}
            onChange={e => handleChange(field.name, e.target.value)}
            placeholder={`Enter ${field.label}`}
            rows={3}
          />
        );
      case 'dropdown': {
        const currentOptions = getDynamicDropdownOptions();
        return (
          <Dropdown
            {...commonProps}
            value={form[field.name] || null}
            options={currentOptions[field.name]?.map(opt => ({ label: opt, value: opt })) || []}
            onChange={e => handleChange(field.name, e.value)}
            placeholder={`Select ${field.label}`}
            filter
            showClear
          />
        );
      }
      case 'calendar':
        return (
          <Calendar
            {...commonProps}
            value={form[field.name] || null}
            onChange={e => handleChange(field.name, e.value)}
            showIcon
            placeholder={`Select ${field.label}`}
            dateFormat="dd/mm/yy"
          />
        );
      default:
        return null;
    }
  };

  const footer = (
    <div className="dialog-footer">
      <Button 
        label={editMode ? "Update" : "Submit"} 
        icon={editMode ? "pi pi-save" : "pi pi-check"} 
        className="p-button-success submit-btn" 
        onClick={handleSubmit}
        loading={false}
      />
      <Button 
        label="Cancel" 
        icon="pi pi-times" 
        className="p-button-secondary cancel-btn" 
        onClick={handleCancel} 
      />
    </div>
  );

  return (
    <Dialog 
      header={
        <div className="dialog-header-custom">
          <i className="pi pi-users dialog-header-icon"></i>
          <span>{editMode ? 'Edit Resource Details' : 'Team Onboarding Tracker'}</span>
        </div>
      }
      visible={visible} 
      style={{ width: '80vw', maxWidth: '1200px' }} 
      onHide={handleCancel} 
      footer={footer} 
      modal
      className="onboarding-dialog"
      maximizable
    >
      <div className="dialog-content">
        <div className="form-section">
          <h4 className="section-title">
            <i className="pi pi-user"></i>
            Basic Information
          </h4>
          <div className="form-grid">
            {fields.slice(0, 8).map(field => (
              <div key={field.name} className="form-field">
                <label htmlFor={field.name} className={field.required ? 'required' : ''}>
                  {field.label}
                  <i className="pi pi-info-circle help-icon" title={field.tooltip}></i>
                </label>
                {renderField(field)}
                {errors[field.name] && <small className="p-error">{field.label} is required.</small>}
              </div>
            ))}
          </div>
        </div>

        <div className="form-section">
          <h4 className="section-title">
            <i className="pi pi-briefcase"></i>
            Employment Details
          </h4>
          <div className="form-grid">
            {fields.slice(8, 16).map(field => (
              <div key={field.name} className="form-field">
                <label htmlFor={field.name} className={field.required ? 'required' : ''}>
                  {field.label}
                  <i className="pi pi-info-circle help-icon" title={field.tooltip}></i>
                </label>
                {renderField(field)}
                {errors[field.name] && <small className="p-error">{field.label} is required.</small>}
              </div>
            ))}
          </div>
        </div>

        <div className="form-section">
          <h4 className="section-title">
            <i className="pi pi-cog"></i>
            Additional Information
          </h4>
          <div className="form-grid">
            {fields.slice(16).map(field => (
              <div key={field.name} className="form-field">
                <label htmlFor={field.name} className={field.required ? 'required' : ''}>
                  {field.label}
                  <i className="pi pi-info-circle help-icon" title={field.tooltip}></i>
                </label>
                {renderField(field)}
                {errors[field.name] && <small className="p-error">{field.label} is required.</small>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </Dialog>
  );
}

OnboardingDialog.propTypes = {
  visible: PropTypes.bool.isRequired,
  onHide: PropTypes.func.isRequired,
  onSubmit: PropTypes.func.isRequired,
  masterData: PropTypes.array,
  editMode: PropTypes.bool,
  editData: PropTypes.object
};

export default OnboardingDialog;
