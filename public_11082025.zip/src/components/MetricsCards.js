import React from 'react';
import PropTypes from 'prop-types';
import { Card } from 'primereact/card';
import './MetricsCards.css';

function MetricsCards({ onCardClick, masterData = [] }) {
  const handleCardClick = (status) => {
    if (onCardClick) {
      onCardClick(status);
    }
  };

  // Calculate actual counts from masterData
  const getStatusCount = (status) => {
    return masterData.filter(item => item.onboardingStatus === status).length;
  };

  // Helper functions for other metrics
  const getWaveCount = (wave) => {
    return masterData.filter(item => item.aesOnboardingWave === wave).length;
  };

  const getClusterCount = (cluster) => {
    return masterData.filter(item => item.aesOnboardingCluster === cluster).length;
  };

  const getLocationCount = (location) => {
    return masterData.filter(item => item.location === location).length;
  };

  const getHiringTypeCount = (type) => {
    return masterData.filter(item => item.gbsTypeOfHiring === type).length;
  };

  const metrics = [
    { 
      label: 'Active', 
      value: getStatusCount('Active'), 
      icon: 'pi pi-check', 
      color: '#E31837',
      description: 'Currently active resources'
    },
    { 
      label: 'On-Hold', 
      value: getStatusCount('On-Hold'), 
      icon: 'pi pi-clock', 
      color: '#F54145',
      description: 'Resources on temporary hold'
    },
    { 
      label: 'Onboarding', 
      value: getStatusCount('Onboarding'), 
      icon: 'pi pi-user-plus', 
      color: '#012169',
      description: 'In onboarding process'
    },
    { 
      label: 'BGV', 
      value: getStatusCount('BGV'), 
      icon: 'pi pi-shield', 
      color: '#1D2ECF',
      description: 'Background verification'
    },
    { 
      label: 'Wave 1', 
      value: getWaveCount(1), 
      icon: 'pi pi-chart-line', 
      color: '#C41230',
      description: 'AES Onboarding Wave 1'
    },
    { 
      label: 'Wave 2', 
      value: getWaveCount(2), 
      icon: 'pi pi-chart-bar', 
      color: '#94002B',
      description: 'AES Onboarding Wave 2'
    },
    { 
      label: 'Cluster 1', 
      value: getClusterCount(1), 
      icon: 'pi pi-th-large', 
      color: '#4873FF',
      description: 'Resources in Cluster 1'
    },
    { 
      label: 'Cluster 2', 
      value: getClusterCount(2), 
      icon: 'pi pi-th-large', 
      color: '#7BA0FF',
      description: 'Resources in Cluster 2'
    },
    { 
      label: 'Chennai', 
      value: getLocationCount('Chennai'), 
      icon: 'pi pi-map-marker', 
      color: '#780032',
      description: 'Resources in Chennai'
    },
    { 
      label: 'Hyderabad', 
      value: getLocationCount('Hyderabad'), 
      icon: 'pi pi-map-marker', 
      color: '#FF786E',
      description: 'Resources in Hyderabad'
    },
    { 
      label: 'Mumbai', 
      value: getLocationCount('Mumbai'), 
      icon: 'pi pi-map-marker', 
      color: '#2F42FF',
      description: 'Resources in Mumbai'
    },
    { 
      label: 'Gift City', 
      value: getLocationCount('Gift City'), 
      icon: 'pi pi-map-marker', 
      color: '#FFA099',
      description: 'Resources in Gift City'
    },
    // { 
    //   label: 'Pune', 
    //   value: getLocationCount('Pune'), 
    //   icon: 'pi pi-map-marker', 
    //   color: '#95B3FF',
    //   description: 'Resources in Pune'
    // },
    // { 
    //   label: 'Cluster 3', 
    //   value: getClusterCount(3), 
    //   icon: 'pi pi-th-large', 
    //   color: '#0D1BA7',
    //   description: 'Resources in Cluster 3'
    // },
    // { 
    //   label: 'Regular', 
    //   value: getHiringTypeCount('Regular'), 
    //   icon: 'pi pi-users', 
    //   color: '#E31837',
    //   description: 'Regular employees'
    // },
    // { 
    //   label: 'Contract', 
    //   value: getHiringTypeCount('Contract'), 
    //   icon: 'pi pi-file-edit', 
    //   color: '#001543',
    //   description: 'Contract employees'
    // },
    // { 
    //   label: 'Intern', 
    //   value: getHiringTypeCount('Intern'), 
    //   icon: 'pi pi-graduation-cap', 
    //   color: '#BDD2FF',
    //   description: 'Intern resources'
    // }
  ];

  return (
    < >
      {metrics.map((metric, idx) => (
        <div key={metric.label} className="col-12 sm:col-6 md:col-4 lg:col-3 xl:col-2">
          <Card 
            className="metric-card h-full cursor-pointer" 
            style={{'--card-color': metric.color}}
            onClick={() => handleCardClick(metric.label)}
          >
            <div className="metric-content">
              <div className="metric-header">
                <div className="metric-icon-wrapper">
                  <i className={`${metric.icon} metric-icon`} style={{fontSize: '1.5rem', color: 'white'}}></i>
                </div>
              </div>
              
              <div className="metric-body">
                <div className="metric-value">{metric.value}</div>
                <div className="metric-label">{metric.label}</div>
                <div className="metric-description">{metric.description}</div>
              </div>
              
              <div className="metric-footer">
                <div className="metric-progress-bar">
                  <div 
                    className="metric-progress-fill" 
                    style={{width: `${Math.min((metric.value / Math.max(masterData.length * 0.3, 30)) * 100, 100)}%`}}
                  ></div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      ))}
    </ >
  );
}

MetricsCards.propTypes = {
  onCardClick: PropTypes.func,
  masterData: PropTypes.array
};

export default MetricsCards;
