import React, { useState, useRef } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { MultiSelect } from 'primereact/multiselect';
import { Tag } from 'primereact/tag';
import { Badge } from 'primereact/badge';
import { Tooltip } from 'primereact/tooltip';
import { Dialog } from 'primereact/dialog';
import { FilterMatchMode } from 'primereact/api';
import PropTypes from 'prop-types';
import './ResourceTables.css';

const columns = [
  { field: 'id', header: 'ID', sortable: true, filter: true },
  { field: 'resourceName', header: 'Resource Name', sortable: true, filter: true },
  { field: 'wmp', header: 'WMP', sortable: true, filter: true },
  { field: 'workdayId', header: 'Workday ID', sortable: true, filter: true },
  { field: 'btgName', header: 'BTG Name', sortable: true, filter: true },
  { field: 'managerName', header: 'Manager Name', sortable: true, filter: true },
  { field: 'aesOnboardingWave', header: 'AES Onboarding Wave', sortable: true, filter: true },
  { field: 'aesOnboardingCluster', header: 'AES Onboarding Cluster', sortable: true, filter: true },
  { field: 'location', header: 'Location', sortable: true, filter: true },
  { field: 'hiringEntity', header: 'Hiring Entity', sortable: true, filter: true },
  { field: 'updatedExpectedDOJ', header: 'Updated Expected DOJ', sortable: true, filter: true },
  { field: 'personNo', header: 'Person No', sortable: true, filter: true },
  { field: 'rbkId', header: 'RBK ID', sortable: true, filter: true },
  { field: 'resourceEmailId', header: 'Resource Email ID', sortable: true, filter: true },
  { field: 'currentBand', header: 'Current Band', sortable: true, filter: true },
  { field: 'targetBand', header: 'Target Band', sortable: true, filter: true },
  { field: 'previousManagerName', header: 'Previous Manager Name', sortable: true, filter: true },
  { field: 'previousManagerEmail', header: 'Previous Manager Email', sortable: true, filter: true },
  { field: 'gbsTypeOfHiring', header: 'GBS Type Of Hiring', sortable: true, filter: true },
  { field: 'onboardingStatus', header: 'Onboarding Status', sortable: true, filter: true },
  { field: 'team', header: 'Team', sortable: true, filter: true },
  { field: 'assignedBuddy', header: 'Assigned Buddy', sortable: true, filter: true },
  { field: 'assignedBuddyEmail', header: 'Assigned Buddy Email', sortable: true, filter: true },
  { field: 'applicantWorkstationDetails', header: 'Applicant Workstation Details', sortable: true, filter: true },
  { field: 'offBoardDate', header: 'Off Board Date', sortable: true, filter: true },
  { field: 'skillset', header: 'Skillset', sortable: true, filter: true },
  { field: 'comments', header: 'Comments', sortable: true, filter: true },
  { field: 'itemType', header: 'Item Type', sortable: true, filter: true },
  { field: 'path', header: 'Path', sortable: true, filter: true },
  { field: 'mobileNumber', header: 'Mobile Number', sortable: true, filter: true },
  { field: 'expectedDOJ', header: 'Expected DOJ', sortable: true, filter: true },
  { field: 'actualDOJ', header: 'Actual DOJ', sortable: true, filter: true },
  { field: 'aesBillingDate', header: 'AES Billing Date', sortable: true, filter: true },
  { field: 'modified', header: 'Modified', sortable: true, filter: true },
  { field: 'created', header: 'Created', sortable: true, filter: true },
  { field: 'modifiedBy', header: 'Modified By', sortable: true, filter: true },
  { field: 'createdBy', header: 'Created By', sortable: true, filter: true }
];

function ResourceTables({ masterData, statusFilter, filterType, filterValue, onEditResource }) {
  const dt = useRef(null);
  
  // State for selection, filtering, and pagination
  const [selectedResources, setSelectedResources] = useState([]);
  const [globalFilterValue, setGlobalFilterValue] = useState('');
  const [viewDialogVisible, setViewDialogVisible] = useState(false);
  const [selectedResourceView, setSelectedResourceView] = useState(null);
  const [filters, setFilters] = useState({
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    resourceName: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    location: { value: null, matchMode: FilterMatchMode.EQUALS },
    hiringEntity: { value: null, matchMode: FilterMatchMode.EQUALS },
    onboardingStatus: { value: null, matchMode: FilterMatchMode.EQUALS },
    team: { value: null, matchMode: FilterMatchMode.EQUALS },
    btgName: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    aesOnboardingWave: { value: null, matchMode: FilterMatchMode.EQUALS },
    aesOnboardingCluster: { value: null, matchMode: FilterMatchMode.EQUALS },
    gbsTypeOfHiring: { value: null, matchMode: FilterMatchMode.EQUALS }
  });
  
  // Column visibility state
  const [selectedColumns, setSelectedColumns] = useState(() => {
    return columns; // Show all columns by default
  });

  // Apply filters based on filter type
  const filteredData = React.useMemo(() => {
    let data = masterData || [];
    
    if (filterType && filterValue) {
      switch (filterType) {
        case 'status':
          data = data.filter(item => item.onboardingStatus === filterValue);
          break;
        case 'wave':
          data = data.filter(item => item.aesOnboardingWave === filterValue);
          break;
        case 'cluster':
          data = data.filter(item => item.aesOnboardingCluster === filterValue);
          break;
        case 'location':
          data = data.filter(item => item.location === filterValue);
          break;
        case 'hiring':
          data = data.filter(item => item.gbsTypeOfHiring === filterValue);
          break;
        default:
          break;
      }
    } else if (statusFilter) {
      // Fallback for backward compatibility
      data = data.filter(item => item.onboardingStatus === statusFilter);
    }
    
    return data;
  }, [masterData, filterType, filterValue, statusFilter]);

  // Update filters when filter changes
  React.useEffect(() => {
    // Preserve existing manual filters and only update external filter fields
    setFilters(prevFilters => {
      // Ensure prevFilters exists and has all required properties
      const safeFilters = prevFilters || {};
      const newFilters = { 
        global: safeFilters.global || { value: null, matchMode: FilterMatchMode.CONTAINS },
        resourceName: safeFilters.resourceName || { value: null, matchMode: FilterMatchMode.STARTS_WITH },
        location: safeFilters.location || { value: null, matchMode: FilterMatchMode.EQUALS },
        hiringEntity: safeFilters.hiringEntity || { value: null, matchMode: FilterMatchMode.EQUALS },
        onboardingStatus: safeFilters.onboardingStatus || { value: null, matchMode: FilterMatchMode.EQUALS },
        team: safeFilters.team || { value: null, matchMode: FilterMatchMode.EQUALS },
        btgName: safeFilters.btgName || { value: null, matchMode: FilterMatchMode.STARTS_WITH },
        aesOnboardingWave: safeFilters.aesOnboardingWave || { value: null, matchMode: FilterMatchMode.EQUALS },
        aesOnboardingCluster: safeFilters.aesOnboardingCluster || { value: null, matchMode: FilterMatchMode.EQUALS },
        gbsTypeOfHiring: safeFilters.gbsTypeOfHiring || { value: null, matchMode: FilterMatchMode.EQUALS }
      };
      
      // Clear external filter fields first
      newFilters.onboardingStatus = { value: null, matchMode: FilterMatchMode.EQUALS };
      newFilters.aesOnboardingWave = { value: null, matchMode: FilterMatchMode.EQUALS };
      newFilters.aesOnboardingCluster = { value: null, matchMode: FilterMatchMode.EQUALS };
      newFilters.location = { value: null, matchMode: FilterMatchMode.EQUALS };
      newFilters.gbsTypeOfHiring = { value: null, matchMode: FilterMatchMode.EQUALS };
      
      if (filterType && filterValue) {
        // Apply new filter based on type
        switch (filterType) {
          case 'status':
            newFilters.onboardingStatus = { value: filterValue, matchMode: FilterMatchMode.EQUALS };
            break;
          case 'wave':
            newFilters.aesOnboardingWave = { value: filterValue, matchMode: FilterMatchMode.EQUALS };
            break;
          case 'cluster':
            newFilters.aesOnboardingCluster = { value: filterValue, matchMode: FilterMatchMode.EQUALS };
            break;
          case 'location':
            newFilters.location = { value: filterValue, matchMode: FilterMatchMode.EQUALS };
            break;
          case 'hiring':
            newFilters.gbsTypeOfHiring = { value: filterValue, matchMode: FilterMatchMode.EQUALS };
            break;
          default:
            break;
        }
      } else if (statusFilter) {
        // Fallback for backward compatibility
        newFilters.onboardingStatus = { value: statusFilter, matchMode: FilterMatchMode.EQUALS };
      }
      
      return newFilters;
    });
  }, [filterType, filterValue, statusFilter]);

  // Global filter function
  const onGlobalFilterChange = (e) => {
    const value = e.target.value;
    let _filters = { ...filters };
    
    // Ensure the global filter object exists
    if (!_filters['global']) {
      _filters['global'] = { value: null, matchMode: FilterMatchMode.CONTAINS };
    }
    
    _filters['global'].value = value;
    setFilters(_filters);
    setGlobalFilterValue(value);
  };

  // Clear all filters
  const clearFilter = () => {
    initFilters();
    // Also notify parent component to clear external filters
    if (typeof window !== 'undefined' && window.clearAllFilters) {
      window.clearAllFilters();
    }
  };

  const initFilters = () => {
    setFilters({
      global: { value: null, matchMode: FilterMatchMode.CONTAINS },
      resourceName: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
      location: { value: null, matchMode: FilterMatchMode.EQUALS },
      hiringEntity: { value: null, matchMode: FilterMatchMode.EQUALS },
      onboardingStatus: { value: null, matchMode: FilterMatchMode.EQUALS },
      team: { value: null, matchMode: FilterMatchMode.EQUALS },
      btgName: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
      aesOnboardingWave: { value: null, matchMode: FilterMatchMode.EQUALS },
      aesOnboardingCluster: { value: null, matchMode: FilterMatchMode.EQUALS },
      gbsTypeOfHiring: { value: null, matchMode: FilterMatchMode.EQUALS }
    });
    setGlobalFilterValue('');
  };

  // Export selected data
  const exportCSV = (selectionOnly) => {
    if (dt.current) {
      dt.current.exportCSV({ selectionOnly });
    }
  };

  // Template functions for custom column rendering
  const statusBodyTemplate = (rowData) => {
    const getStatusSeverity = (status) => {
      switch (status) {
        case 'Active': return 'success';
        case 'Onboarding': return 'info';
        case 'On-Hold': return 'warning';
        case 'BGV': return 'info';
        case 'Resigned': return 'danger';
        case 'Terminated': return 'danger';
        case 'Open Requirement': return 'secondary';
        default: return 'secondary';
      }
    };

    return <Tag value={rowData.onboardingStatus} severity={getStatusSeverity(rowData.onboardingStatus)} />;
  };

  const emailBodyTemplate = (rowData) => {
    return (
      <span className="p-text-truncate" style={{ maxWidth: '200px', display: 'inline-block' }}>
        <a href={`mailto:${rowData.resourceEmailId}`} className="text-primary no-underline">
          {rowData.resourceEmailId}
        </a>
      </span>
    );
  };

  const phoneBodyTemplate = (rowData) => {
    return (
      <span className="font-medium">
        <a href={`tel:${rowData.mobileNumber}`} className="text-primary no-underline">
          {rowData.mobileNumber}
        </a>
      </span>
    );
  };

  const dateBodyTemplate = (field) => (rowData) => {
    const date = rowData[field];
    return date ? new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: '2-digit'
    }) : '-';
  };

  const hiringEntityBodyTemplate = (rowData) => {
    const getEntityColor = (entity) => {
      return entity === 'EY' ? '#2A9D8F' : '#E76F51';
    };

    return (
      <Badge 
        value={rowData.hiringEntity} 
        style={{ backgroundColor: getEntityColor(rowData.hiringEntity) }}
      />
    );
  };

  const skillsetBodyTemplate = (rowData) => {
    const skills = rowData.skillset ? rowData.skillset.split(',').slice(0, 3) : [];
    return (
      <div className="flex flex-wrap gap-1">
        {skills.map((skill) => (
          <Tag key={skill.trim()} value={skill.trim()} className="p-tag-sm" />
        ))}
        {rowData.skillset && rowData.skillset.split(',').length > 3 && (
          <Tag value={`+${rowData.skillset.split(',').length - 3} more`} className="p-tag-sm" severity="secondary" />
        )}
      </div>
    );
  };

  // Action handlers
  const handleView = (rowData) => {
    setSelectedResourceView(rowData);
    setViewDialogVisible(true);
  };

  const handleEdit = (rowData) => {
    if (onEditResource) {
      onEditResource(rowData);
    } else {
      alert('Edit functionality is not available');
    }
  };

  const handleDownload = (rowData) => {
    // Generate and download resource data as JSON/CSV
    const dataStr = JSON.stringify(rowData, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${rowData.resourceName.replace(/\s+/g, '_')}_${rowData.wmp}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const actionBodyTemplate = (rowData) => {
    return (
      <div className="flex gap-2">
        <Button 
          icon="pi pi-eye" 
          className="p-button-rounded p-button-text p-button-sm" 
          tooltip="View Details"
          tooltipOptions={{position: 'bottom'}}
          onClick={() => handleView(rowData)}
        />
        <Button 
          icon="pi pi-pencil" 
          className="p-button-rounded p-button-text p-button-sm" 
          tooltip="Edit"
          tooltipOptions={{position: 'bottom'}}
          onClick={() => handleEdit(rowData)}
        />
        <Button 
          icon="pi pi-download" 
          className="p-button-rounded p-button-text p-button-sm" 
          tooltip="Download"
          tooltipOptions={{position: 'bottom'}}
          onClick={() => handleDownload(rowData)}
        />
      </div>
    );
  };

  // Table header with controls
  const renderHeader = () => {
    return (
      <div className="flex flex-wrap gap-3 align-items-center justify-content-between">
        <div className="flex flex-wrap gap-2 align-items-center">
          <span className="p-input-icon-left">
            <i className="pi pi-search" />
            <InputText 
              value={globalFilterValue} 
              onChange={onGlobalFilterChange} 
              placeholder="Global Search..." 
              className="p-inputtext-sm"
            />
          </span>
          <Button 
            type="button" 
            icon="pi pi-filter-slash" 
            label="Clear Filters" 
            className="p-button-outlined p-button-sm" 
            onClick={clearFilter} 
          />
          <div className="flex align-items-center gap-2">
            <i className="pi pi-users text-primary"></i>
            <span className="font-semibold">
              {selectedResources.length} of {filteredData.length} selected
            </span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2 align-items-center">
          <MultiSelect 
            value={selectedColumns} 
            options={columns} 
            optionLabel="header" 
            onChange={(e) => setSelectedColumns(e.value)}
            placeholder="Choose Columns"
            maxSelectedLabels={3}
            className="w-full md:w-20rem"
            display="chip"
          />
          <Button 
            type="button" 
            icon="pi pi-file-excel" 
            label="Export All" 
            className="p-button-success p-button-sm" 
            onClick={() => exportCSV(false)} 
          />
          <Button 
            type="button" 
            icon="pi pi-file-excel" 
            label="Export Selected" 
            className="p-button-help p-button-sm" 
            onClick={() => exportCSV(true)} 
            disabled={!selectedResources || selectedResources.length === 0}
          />
        </div>
      </div>
    );
  };

  return (
    <div className="resource-tables-container">
      <Tooltip target=".p-button" />
      
      <div className="card">
        <h5 className="mb-4 flex align-items-center gap-2">
          <i className="pi pi-database text-primary"></i>
          Resource Onboarding Master Data
          <Badge value={filteredData.length} className="ml-2" />
          {(filterType && filterValue) && (
            <Tag value={`Filtered by ${filterType}: ${filterValue}`} severity="info" className="ml-2" />
          )}
          {(statusFilter && !filterType) && (
            <Tag value={`Filtered by: ${statusFilter}`} severity="info" className="ml-2" />
          )}
        </h5>
        
        <DataTable 
          ref={dt}
          value={filteredData}
          selection={selectedResources}
          onSelectionChange={(e) => setSelectedResources(e.value)}
          dataKey="id"
          paginator 
          rows={10} 
          rowsPerPageOptions={[5, 10, 25, 50]}
          paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
          currentPageReportTemplate="Showing {first} to {last} of {totalRecords} resources"
          filters={filters}
          onFilter={(e) => setFilters(e.filters)}
          filterDisplay="row"
          globalFilterFields={['resourceName', 'location', 'hiringEntity', 'onboardingStatus', 'team', 'btgName', 'skillset', 'comments']}
          header={renderHeader()}
          emptyMessage="No resources found."
          stripedRows
          showGridlines
          scrollable
          scrollHeight="600px"
          className="resource-data-table"
          selectionMode="multiple"
          metaKeySelection={false}
          removableSort
          reorderableColumns
          resizableColumns
          columnResizeMode="expand"
          loading={false}
        >
          <Column selectionMode="multiple" headerStyle={{ width: '3rem' }} frozen></Column>
          
          {selectedColumns.map((col) => {
            let body = null;
            
            // Apply custom templates for specific columns
            if (col.field === 'onboardingStatus') {
              body = statusBodyTemplate;
            } else if (col.field === 'resourceEmailId') {
              body = emailBodyTemplate;
            } else if (col.field === 'mobileNumber') {
              body = phoneBodyTemplate;
            } else if (col.field === 'hiringEntity') {
              body = hiringEntityBodyTemplate;
            } else if (col.field === 'skillset') {
              body = skillsetBodyTemplate;
            } else if (['expectedDOJ', 'actualDOJ', 'aesBillingDate', 'created', 'modified', 'offBoardDate', 'updatedExpectedDOJ'].includes(col.field)) {
              body = dateBodyTemplate(col.field);
            }
            
            return (
              <Column 
                key={col.field} 
                field={col.field} 
                header={col.header} 
                sortable={col.sortable}
                filter={col.filter}
                filterPlaceholder={`Search by ${col.header}`}
                body={body}
                style={{ minWidth: '150px' }}
                showFilterMatchModes={false}
                showClearButton={true}
                showApplyButton={false}
                showFilterMenuOptions={false}
                filterDisplay="row"
              />
            );
          })}
          
          <Column 
            field="actions" 
            header="Actions" 
            body={actionBodyTemplate} 
            headerStyle={{ width: '10rem' }} 
            frozen
            alignFrozen="right"
          ></Column>
        </DataTable>
      </div>

      {/* Modern Detailed View Dialog */}
      <Dialog
        header={
          <div className="modern-dialog-header">
            <div className="header-icon-wrapper">
              <i className="pi pi-id-card"></i>
            </div>
            <div className="header-content">
              <h3>Resource Profile</h3>
              <p>{selectedResourceView?.resourceName}</p>
            </div>
            <div className="header-status">
              {selectedResourceView && (
                <Tag 
                  value={selectedResourceView.onboardingStatus} 
                  severity={
                    selectedResourceView.onboardingStatus === 'Active' ? 'success' :
                    selectedResourceView.onboardingStatus === 'Onboarding' ? 'info' :
                    selectedResourceView.onboardingStatus === 'On-Hold' ? 'warning' : 'danger'
                  }
                  className="status-tag-modern"
                />
              )}
            </div>
          </div>
        }
        visible={viewDialogVisible}
        style={{ width: '85vw', maxWidth: '1200px' }}
        onHide={() => setViewDialogVisible(false)}
        modal
        className="modern-resource-view-dialog"
        maximizable
      >
        {selectedResourceView && (
          <div className="modern-dialog-content">
            {/* Resource Summary Card */}
            <div className="resource-summary-card">
              <div className="summary-avatar">
                <i className="pi pi-user"></i>
              </div>
              <div className="summary-info">
                <h4>{selectedResourceView.resourceName}</h4>
                <div className="summary-meta">
                  <span className="meta-item">
                    <i className="pi pi-id-card"></i>
                    {selectedResourceView.wmp}
                  </span>
                  <span className="meta-item">
                    <i className="pi pi-envelope"></i>
                    {selectedResourceView.resourceEmailId}
                  </span>
                  <span className="meta-item">
                    <i className="pi pi-phone"></i>
                    {selectedResourceView.mobileNumber || 'Not Provided'}
                  </span>
                </div>
              </div>
              <div className="summary-badges">
                <Badge value={selectedResourceView.hiringEntity} severity="info" size="large" />
                <Badge value={selectedResourceView.location} severity="secondary" size="large" />
              </div>
            </div>

            {/* Information Tabs */}
            <div className="info-grid">
              {/* Personal Information */}
              <div className="modern-info-card">
                <div className="card-header">
                  <div className="card-icon personal">
                    <i className="pi pi-user"></i>
                  </div>
                  <h5>Personal Information</h5>
                </div>
                <div className="card-content">
                  <div className="info-row">
                    <span className="label">Full Name</span>
                    <span className="value">{selectedResourceView.resourceName}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">WMP ID</span>
                    <span className="value">{selectedResourceView.wmp}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Workday ID</span>
                    <span className="value">{selectedResourceView.workdayId}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Person No</span>
                    <span className="value">{selectedResourceView.personNo || 'N/A'}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">RBK ID</span>
                    <span className="value">{selectedResourceView.rbkId || 'N/A'}</span>
                  </div>
                </div>
              </div>

              {/* Professional Information */}
              <div className="modern-info-card">
                <div className="card-header">
                  <div className="card-icon professional">
                    <i className="pi pi-briefcase"></i>
                  </div>
                  <h5>Professional Details</h5>
                </div>
                <div className="card-content">
                  <div className="info-row">
                    <span className="label">Hiring Entity</span>
                    <span className="value">{selectedResourceView.hiringEntity}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Location</span>
                    <span className="value">{selectedResourceView.location}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Manager</span>
                    <span className="value">{selectedResourceView.managerName}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Team</span>
                    <span className="value">{selectedResourceView.team}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">BTG</span>
                    <span className="value">{selectedResourceView.btgName}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Current Band</span>
                    <span className="value">{selectedResourceView.currentBand}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Target Band</span>
                    <span className="value">{selectedResourceView.targetBand}</span>
                  </div>
                </div>
              </div>

              {/* Onboarding Information */}
              <div className="modern-info-card">
                <div className="card-header">
                  <div className="card-icon onboarding">
                    <i className="pi pi-calendar"></i>
                  </div>
                  <h5>Onboarding Timeline</h5>
                </div>
                <div className="card-content">
                  <div className="info-row">
                    <span className="label">AES Wave</span>
                    <span className="value">
                      <Badge value={`Wave ${selectedResourceView.aesOnboardingWave}`} severity="info" />
                    </span>
                  </div>
                  <div className="info-row">
                    <span className="label">AES Cluster</span>
                    <span className="value">
                      <Badge value={`Cluster ${selectedResourceView.aesOnboardingCluster}`} severity="secondary" />
                    </span>
                  </div>
                  <div className="info-row">
                    <span className="label">Expected DOJ</span>
                    <span className="value">{selectedResourceView.expectedDOJ || 'Not Set'}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Actual DOJ</span>
                    <span className="value">{selectedResourceView.actualDOJ || 'Pending'}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Updated Expected DOJ</span>
                    <span className="value">{selectedResourceView.updatedExpectedDOJ || 'N/A'}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">AES Billing Date</span>
                    <span className="value">{selectedResourceView.aesBillingDate || 'Not Set'}</span>
                  </div>
                </div>
              </div>

              {/* Skills Section */}
              <div className="modern-info-card skills-card">
                <div className="card-header">
                  <div className="card-icon skills">
                    <i className="pi pi-star"></i>
                  </div>
                  <h5>Technical Skills</h5>
                </div>
                <div className="card-content">
                  <div className="skills-container">
                    {selectedResourceView.skillset && selectedResourceView.skillset.split(',').map((skill, index) => (
                      <div key={index} className="skill-chip">
                        <i className="pi pi-check-circle"></i>
                        <span>{skill.trim()}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Comments Section */}
              {selectedResourceView.comments && (
                <div className="modern-info-card comments-card">
                  <div className="card-header">
                    <div className="card-icon comments">
                      <i className="pi pi-comment"></i>
                    </div>
                    <h5>Additional Comments</h5>
                  </div>
                  <div className="card-content">
                    <div className="comments-content">
                      <p>{selectedResourceView.comments}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Additional Information */}
              <div className="modern-info-card">
                <div className="card-header">
                  <div className="card-icon additional">
                    <i className="pi pi-info-circle"></i>
                  </div>
                  <h5>Additional Information</h5>
                </div>
                <div className="card-content">
                  <div className="info-row">
                    <span className="label">GBS Type of Hiring</span>
                    <span className="value">{selectedResourceView.gbsTypeOfHiring}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Assigned Buddy</span>
                    <span className="value">{selectedResourceView.assignedBuddy || 'Not Assigned'}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Buddy Email</span>
                    <span className="value">{selectedResourceView.assignedBuddyEmail || 'N/A'}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Workstation Details</span>
                    <span className="value">{selectedResourceView.applicantWorkstationDetails || 'Not Provided'}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Created</span>
                    <span className="value">{selectedResourceView.created}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Last Modified</span>
                    <span className="value">{selectedResourceView.modified}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </Dialog>
    </div>
  );
}

ResourceTables.propTypes = {
  masterData: PropTypes.array,
  statusFilter: PropTypes.string,
  filterType: PropTypes.string,
  filterValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  onEditResource: PropTypes.func
};

export default ResourceTables;
