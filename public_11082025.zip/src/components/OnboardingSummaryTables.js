import React, { useMemo, useState } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Tag } from 'primereact/tag';
import { Badge } from 'primereact/badge';
import { ProgressBar } from 'primereact/progressbar';
import { TabView, TabPanel } from 'primereact/tabview';
import PropTypes from 'prop-types';
import './OnboardingSummaryTables.css';

const OnboardingSummaryTables = ({ masterData = [] }) => {
  const [activeTabIndex, setActiveTabIndex] = useState(0);

  // Generate summary data based on master data
  const generateSummaryData = useMemo(() => {
    const generateTableData = (hiringEntity, tableType = 'Regular') => {
      // Filter data based on hiring entity
      let filteredData = masterData.filter(item => item.hiringEntity === hiringEntity);
      
      // Apply additional filtering based on table type
      if (tableType === 'Regular') {
        // For "Regular" tables, show all records for the hiring entity
        // Don't filter by gbsTypeOfHiring to show all employees
        // The "Regular" refers to the main employee table, not hiring type
        filteredData = filteredData; // Keep all records for the entity
      } else if (tableType === 'Additional') {
        // For EY Additional 40, take a subset to simulate additional hiring
        // Focus on newer or special status records
        filteredData = filteredData.filter(item => 
          item.gbsTypeOfHiring === 'Contract' || 
          item.gbsTypeOfHiring === 'Intern' ||
          item.onboardingStatus === 'Onboarding' || 
          item.onboardingStatus === 'BGV' ||
          item.onboardingStatus === 'Open Requirement'
        );
        // Limit to simulate "Additional 40" concept
        filteredData = filteredData.slice(0, Math.min(40, filteredData.length));
      }

      // Group by team and calculate statistics
      const teamStats = {};
      
      filteredData.forEach(resource => {
        const team = resource.team || 'Unassigned Team';
        
        if (!teamStats[team]) {
          teamStats[team] = {
            requireDate: resource.updatedExpectedDOJ || resource.expectedDOJ || new Date().toISOString().split('T')[0],
            team: team,
            wave1Resources: [],
            wave2Resources: [],
            allResources: []
          };
        }
        
        teamStats[team].allResources.push(resource);
        
        // Handle wave assignments properly
        if (resource.aesOnboardingWave === 1 || resource.aesOnboardingWave === '1') {
          teamStats[team].wave1Resources.push(resource);
        } else if (resource.aesOnboardingWave === 2 || resource.aesOnboardingWave === '2') {
          teamStats[team].wave2Resources.push(resource);
        }
      });

      // Convert to table format
      return Object.values(teamStats).map(team => {
        const wave1Count = team.wave1Resources.length;
        const wave2Count = team.wave2Resources.length;
        const totalCount = team.allResources.length;
        
        // Calculate status-based metrics from actual master data
        const activeResources = team.allResources.filter(r => r.onboardingStatus === 'Active').length;
        const onboardingResources = team.allResources.filter(r => r.onboardingStatus === 'Onboarding').length;
        const bgvResources = team.allResources.filter(r => r.onboardingStatus === 'BGV').length;
        const resignedResources = team.allResources.filter(r => r.onboardingStatus === 'Resigned').length;
        const terminatedResources = team.allResources.filter(r => r.onboardingStatus === 'Terminated').length;
        const onHoldResources = team.allResources.filter(r => r.onboardingStatus === 'On-Hold').length;
        const completedResources = team.allResources.filter(r => r.onboardingStatus === 'Completed').length;
        const openRequirements = team.allResources.filter(r => r.onboardingStatus === 'Open Requirement').length;
        
        // Use actual counts from master data - no simulation
        const totalSelected = activeResources + onboardingResources + completedResources;
        const dropOuts = resignedResources + terminatedResources;
        
        // Map actual status counts to interview pipeline columns
        const r1YetToSchedule = openRequirements; // Open positions
        const r1Schedule = onboardingResources; // Currently onboarding
        const r1Reject = resignedResources; // Resigned during process
        
        const r2YetToSchedule = onHoldResources; // On hold status
        const r2Schedule = bgvResources; // Background verification in progress
        const r2Reject = terminatedResources; // Terminated
        const r2Select = activeResources + completedResources; // Successfully active/completed
        
        // Calculate completion percentages based on actual wave data and status
        const wave1CompletedCount = team.wave1Resources.filter(r => 
          r.onboardingStatus === 'Active' || r.onboardingStatus === 'Completed'
        ).length;
        const wave2CompletedCount = team.wave2Resources.filter(r => 
          r.onboardingStatus === 'Active' || r.onboardingStatus === 'Completed'
        ).length;
        
        const wave1Completed = wave1Count > 0 ? Math.round((wave1CompletedCount / wave1Count) * 100) : 0;
        const wave2Completed = wave2Count > 0 ? Math.round((wave2CompletedCount / wave2Count) * 100) : 0;

        return {
          id: `${hiringEntity}-${tableType}-${team.team}`.replace(/\s+/g, '-').toLowerCase(),
          requireDate: team.requireDate,
          team: team.team,
          wave1: wave1Count,
          wave2: wave2Count,
          total: totalCount,
          totalSelected: totalSelected,
          dropOuts: dropOuts,
          r1YetToSchedule: r1YetToSchedule,
          r1Schedule: r1Schedule,
          r1Reject: r1Reject,
          r2YetToSchedule: r2YetToSchedule,
          r2Schedule: r2Schedule,
          r2Reject: r2Reject,
          r2Select: r2Select,
          wave1Completed: wave1Completed,
          wave2Completed: wave2Completed,
          // Additional metadata for debugging
          _metadata: {
            activeCount: activeResources,
            onboardingCount: onboardingResources,
            bgvCount: bgvResources,
            resignedCount: resignedResources,
            terminatedCount: terminatedResources,
            onHoldCount: onHoldResources,
            completedCount: completedResources,
            openReqCount: openRequirements
          }
        };
      }).filter(team => team.total > 0); // Only include teams with actual resources
    };

    // Generate data for each table with proper filtering
    const eyRegularData = generateTableData('EY', 'Regular');
    const eyAdditionalData = generateTableData('EY', 'Additional');
    const wiproRegularData = generateTableData('Wipro', 'Regular');

    return {
      eyRegular: eyRegularData,
      eyAdditional: eyAdditionalData,
      wiproRegular: wiproRegularData
    };
  }, [masterData]);

  // Column definitions for summary tables
  const summaryColumns = [
    { field: 'requireDate', header: 'Require Date', sortable: true },
    { field: 'team', header: 'Team', sortable: true },
    { field: 'wave1', header: 'Wave 1', sortable: true },
    { field: 'wave2', header: 'Wave 2', sortable: true },
    { field: 'total', header: 'Total', sortable: true },
    { field: 'totalSelected', header: 'Total Selected', sortable: true },
    { field: 'dropOuts', header: 'Drop-Outs', sortable: true },
    { field: 'r1YetToSchedule', header: 'R1-Yet to Schedule', sortable: true },
    { field: 'r1Schedule', header: 'R1-Schedule', sortable: true },
    { field: 'r1Reject', header: 'R1 Reject', sortable: true },
    { field: 'r2YetToSchedule', header: 'R2-Yet to Schedule', sortable: true },
    { field: 'r2Schedule', header: 'R2-Schedule', sortable: true },
    { field: 'r2Reject', header: 'R2 Reject', sortable: true },
    { field: 'r2Select', header: 'R2 Select', sortable: true },
    { field: 'wave1Completed', header: 'Wave1 Completed %', sortable: true },
    { field: 'wave2Completed', header: 'Wave2 Completed %', sortable: true }
  ];

  // Template functions for custom rendering
  const dateBodyTemplate = (rowData) => {
    return new Date(rowData.requireDate).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: '2-digit'
    });
  };

  const numberBodyTemplate = (field) => (rowData) => {
    const value = rowData[field];
    return (
      <Badge 
        value={value} 
        severity={value > 0 ? 'info' : 'secondary'}
        className="number-badge"
      />
    );
  };

  const percentageBodyTemplate = (field) => (rowData) => {
    const percentage = rowData[field];
    const getSeverity = (percent) => {
      if (percent >= 80) return 'success';
      if (percent >= 60) return 'warning';
      return 'danger';
    };

    return (
      <div className="percentage-container">
        <Tag 
          value={`${percentage}%`} 
          severity={getSeverity(percentage)}
          className="percentage-tag"
        />
        <ProgressBar 
          value={percentage} 
          className="percentage-progress"
          style={{ height: '4px', marginTop: '4px' }}
        />
      </div>
    );
  };

  const teamBodyTemplate = (rowData) => {
    return (
      <div className="team-cell">
        <i className="pi pi-users team-icon"></i>
        <span className="team-name">{rowData.team}</span>
      </div>
    );
  };

  const renderSummaryTable = (data, title, description) => {
    return (
      <div className="summary-table-container">
        <div className="table-header">
          <h4 className="table-title">
            <i className="pi pi-chart-bar"></i>
            {title}
          </h4>
          <p className="table-description">{description}</p>
          <Badge value={data.length} className="record-count" />
        </div>
        
        <DataTable 
          value={data}
          paginator 
          rows={10} 
          rowsPerPageOptions={[5, 10, 15]}
          className="summary-data-table"
          stripedRows
          showGridlines
          emptyMessage={`No ${title.toLowerCase()} data found.`}
          scrollable
          scrollHeight="400px"
        >
          {summaryColumns.map((col) => {
            let body = null;
            
            if (col.field === 'requireDate') {
              body = dateBodyTemplate;
            } else if (col.field === 'team') {
              body = teamBodyTemplate;
            } else if (col.field === 'wave1Completed' || col.field === 'wave2Completed') {
              body = percentageBodyTemplate(col.field);
            } else if (typeof data[0]?.[col.field] === 'number' && col.field !== 'requireDate') {
              body = numberBodyTemplate(col.field);
            }
            
            return (
              <Column 
                key={col.field} 
                field={col.field} 
                header={col.header} 
                sortable={col.sortable}
                body={body}
                style={{ minWidth: '120px' }}
                headerStyle={{ 
                  backgroundColor: '#f8f9fa', 
                  fontWeight: '600',
                  fontSize: '0.875rem'
                }}
              />
            );
          })}
        </DataTable>
      </div>
    );
  };

  return (
    <div className="onboarding-summary-tables">
      <div className="summary-header">
        <h3 className="section-title">
          <i className="pi pi-chart-pie"></i>
          Onboarding Summary by Hiring Entity
        </h3>
        <p className="section-description">
          Detailed breakdown of recruitment pipeline and onboarding progress
        </p>
      </div>

      <TabView 
        activeIndex={activeTabIndex} 
        onTabChange={(e) => setActiveTabIndex(e.index)}
        className="summary-tabs"
      >
        <TabPanel 
          header={
            <span>
              <i className="pi pi-building"></i>
              EY (Regular)
              <Badge value={generateSummaryData.eyRegular.length} className="tab-badge" />
            </span>
          }
        >
          {renderSummaryTable(
            generateSummaryData.eyRegular, 
            'EY Regular Employees',
            `All EY employees in the onboarding pipeline (Total: ${masterData.filter(item => item.hiringEntity === 'EY').length} records)`
          )}
        </TabPanel>
        
        <TabPanel 
          header={
            <span>
              <i className="pi pi-plus-circle"></i>
              EY (Additional 40)
              <Badge value={generateSummaryData.eyAdditional.length} className="tab-badge" />
            </span>
          }
        >
          {renderSummaryTable(
            generateSummaryData.eyAdditional, 
            'EY Additional Resources',
            `Additional/Special hiring pipeline for EY (Contract, Intern, and special cases)`
          )}
        </TabPanel>
        
        <TabPanel 
          header={
            <span>
              <i className="pi pi-sitemap"></i>
              Wipro (Regular)
              <Badge value={generateSummaryData.wiproRegular.length} className="tab-badge" />
            </span>
          }
        >
          {renderSummaryTable(
            generateSummaryData.wiproRegular, 
            'Wipro Regular Employees',
            `All Wipro employees in the onboarding pipeline (Total: ${masterData.filter(item => item.hiringEntity === 'Wipro').length} records)`
          )}
        </TabPanel>
      </TabView>
    </div>
  );
};

OnboardingSummaryTables.propTypes = {
  masterData: PropTypes.array
};

export default OnboardingSummaryTables;
