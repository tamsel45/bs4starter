import React, { useState } from 'react';
import { Chart } from 'primereact/chart';
import { ProgressBar } from 'primereact/progressbar';
import { Button } from 'primereact/button';
import PropTypes from 'prop-types';
import './ProgressCircle.css';

function ProgressCircle({ masterData = [] }) {
  const [selectedWave, setSelectedWave] = useState(1);

  // Calculate actual data from masterData
  const calculateWaveData = (waveNumber) => {
    const waveResources = masterData.filter(item => item.aesOnboardingWave === waveNumber);
    const totalWaveResources = waveResources.length;
    
    // Count different statuses for this wave
    const activeCount = waveResources.filter(item => item.onboardingStatus === 'Active').length;
    const onboardingCount = waveResources.filter(item => item.onboardingStatus === 'Onboarding').length;
    const bgvCount = waveResources.filter(item => item.onboardingStatus === 'BGV').length;
    
    // Completed = Active resources (fully onboarded)
    const completed = activeCount;
    
    // In Progress = Onboarding + BGV
    const inProgress = onboardingCount + bgvCount;
    
    // Not Started = Total - (Completed + In Progress)
    const notStarted = Math.max(0, totalWaveResources - completed - inProgress);
    
    // Set a reasonable target (we'll use current total as minimum, but set target higher if completion rate is high)
    const target = Math.max(totalWaveResources, Math.ceil(totalWaveResources * 1.2));
    
    // Calculate percentage of completion
    const percentage = totalWaveResources > 0 ? Math.round((completed / totalWaveResources) * 100) : 0;
    
    return {
      completed,
      inProgress, 
      notStarted,
      total: totalWaveResources,
      target,
      percentage,
      remaining: target - completed
    };
  };

  const wave1Data = calculateWaveData(1);
  const wave2Data = calculateWaveData(2);

  const progressData = selectedWave === 1 ? wave1Data : wave2Data;

  const chartData = {
    labels: ['Completed', 'In Progress', 'Not Started'],
    datasets: [
      {
        data: [progressData.completed, progressData.inProgress, progressData.notStarted],
        backgroundColor: ['#012169', '#1D2ECF', '#e9ecef'],
        borderWidth: 0,
        cutout: '75%'
      }
    ]
  };

  const chartOptions = {
    plugins: {
      legend: { display: false },
      tooltip: {
        callbacks: {
          label: function(context) {
            return context.label + ': ' + context.parsed + '%';
          }
        }
      }
    },
    maintainAspectRatio: false,
    responsive: true
  };

  return (
    <div className="chart-card">
      <div className="card-header">
        <h3>Onboarding Progress</h3>
        <div className="wave-selector">
          <Button
            label="Wave 1"
            className={`p-button-sm ${selectedWave === 1 ? 'p-button-raised' : 'p-button-outlined'}`}
            onClick={() => setSelectedWave(1)}
            style={{ 
              fontSize: '0.75rem', 
              padding: '0.375rem 0.75rem',
              backgroundColor: selectedWave === 1 ? '#012169' : 'transparent',
              borderColor: '#012169',
              color: selectedWave === 1 ? '#fff' : '#012169'
            }}
          />
          <Button
            label="Wave 2"
            className={`p-button-sm ${selectedWave === 2 ? 'p-button-raised' : 'p-button-outlined'}`}
            onClick={() => setSelectedWave(2)}
            style={{ 
              fontSize: '0.75rem', 
              padding: '0.375rem 0.75rem',
              backgroundColor: selectedWave === 2 ? '#012169' : 'transparent',
              borderColor: '#012169',
              color: selectedWave === 2 ? '#fff' : '#012169'
            }}
          />
        </div>
      </div>
      
      <div style={{ padding: '1.5rem' }}>
        <div className="progress-content">
          <div className="chart-container">
            <Chart type="doughnut" data={chartData} options={chartOptions} className="progress-chart" />
            <div className="chart-overlay">
              <div className="progress-center">
                <span className="progress-value">{progressData.percentage}%</span>
                <span className="progress-label">Completed</span>
              </div>
            </div>
          </div>
          
          <div className="progress-stats">
            <div className="stat-card completed">
              <div className="stat-icon">
                <i className="pi pi-check-circle"></i>
              </div>
              <div className="stat-content">
                <h4>Completed</h4>
                <div className="stat-value">{progressData.completed}</div>
                <ProgressBar value={progressData.percentage} className="stat-progress" />
              </div>
            </div>
            
            <div className="stat-card in-progress">
              <div className="stat-icon">
                <i className="pi pi-clock"></i>
              </div>
              <div className="stat-content">
                <h4>In Progress</h4>
                <div className="stat-value">{progressData.inProgress}</div>
                <ProgressBar value={progressData.total > 0 ? (progressData.inProgress / progressData.total) * 100 : 0} className="stat-progress in-progress-bar" />
              </div>
            </div>
            
            <div className="stat-card total">
              <div className="stat-icon">
                <i className="pi pi-users"></i>
              </div>
              <div className="stat-content">
                <h4>Total Resources</h4>
                <div className="stat-value">{progressData.total}</div>
                <ProgressBar value={100} className="stat-progress total-progress" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

ProgressCircle.propTypes = {
  masterData: PropTypes.array
};

export default ProgressCircle;
